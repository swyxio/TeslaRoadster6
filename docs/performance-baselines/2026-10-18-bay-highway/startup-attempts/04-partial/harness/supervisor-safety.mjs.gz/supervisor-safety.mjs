/**
 * UNREVIEWED DRAFT. For the startup supervisor only.
 * These mechanisms are practical polling guards, not kernel confinement.
 * The entry point remains blocked pending coordinator reservation and review.
 */
import { execFile, spawn } from 'node:child_process';
import { appendFileSync, closeSync, fsyncSync, openSync } from 'node:fs';
import { lstat, readdir, realpath, statfs } from 'node:fs/promises';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
export const GIB = 1024 ** 3;
export const MIB = 1024 ** 2;
export const delay = ms => new Promise(resolveDelay => setTimeout(resolveDelay, ms));

// Output is deliberately sanitized: subprocess output and exception text are
// not written to the journal, because they may contain the stage secret.
export class Journal {
  constructor(path) {
    this.fd = openSync(path, 'wx', 0o600);
    this.broken = false;
  }
  mark(event, fields = {}) {
    const line = JSON.stringify({ event, atEpochMs: Date.now(), atMonotonicMs: performance.now(), ...fields }) + '\n';
    try {
      if (this.broken) throw new Error('journal previously failed');
      appendFileSync(this.fd, line);
      fsyncSync(this.fd);
    } catch {
      this.broken = true;
      // May also fail on a broken pipe. No secret or raw exception is printed.
      try { process.stderr.write(`startup-probe journal-unavailable ${event}\n`); } catch {}
      throw new Error('journal-unavailable');
    }
  }
  close() { try { closeSync(this.fd); } catch {} }
}

// Count all regular files in the controlled tree, including copied source,
// both builds, logs, temporary files, profiles, and local Worker storage.
// Symlinks are never followed. Sockets and FIFOs are endpoints, not regular
// files with persistent contents. A file disappearing during a scan fails the
// run closed rather than returning a falsely small count. This is a periodic
// check, not a filesystem quota, and cannot bound writes between samples.
export async function treeBytes(root, journal) {
  const seen = new Set();
  let bytes = 0, sockets = 0, fifos = 0;
  async function visit(path) {
    const st = await lstat(path);
    if (st.isSymbolicLink()) return;
    if (st.isDirectory()) {
      for (const name of await readdir(path)) await visit(join(path, name));
      return;
    }
    if (st.isSocket()) { sockets++; return; }
    if (st.isFIFO()) { fifos++; return; }
    if (!st.isFile()) {
      const type = st.isCharacterDevice() ? 'character-device' : st.isBlockDevice() ? 'block-device' : 'unknown';
      // Filenames are untrusted; do not write a literal 32-byte hex secret.
      const safePath = (relative(root, path) || '.').replace(/[0-9a-f]{64}/gi, '[redacted]');
      journal?.mark('resource-unexpected-output-type', { type, path: safePath.slice(0, 512), pathTruncated: safePath.length > 512 });
      throw new Error('unexpected-output-file-type');
    }
    const inode = `${st.dev}:${st.ino}`;
    if (!seen.has(inode)) { seen.add(inode); bytes += st.size; }
  }
  await visit(root);
  return { bytes, sockets, fifos };
}

export class Resources {
  constructor({ paths, output, journal, abort, signal }) {
    this.paths = paths.map(path => resolve(path));
    this.output = output;
    this.journal = journal;
    this.abort = abort;
    this.signal = signal;
    this.timer = undefined;
    this.busy = false;
    this.lastStart = undefined;
    this.error = undefined;
  }
  async sample(phase, minimumFree) {
    if (this.signal?.aborted) throw new Error('aborted');
    const sampleStart = performance.now();
    if (this.lastStart !== undefined && phase === 'active' && sampleStart - this.lastStart > 4500)
      throw new Error('resource-sample-gap');
    if (phase === 'active') this.lastStart = sampleStart;
    const volumes = new Map();
    for (const suppliedPath of this.paths) {
      if (this.signal?.aborted) throw new Error('aborted');
      const path = await realpath(suppliedPath);
      const st = await lstat(path);
      const space = await statfs(path, { bigint: true });
      const free = space.bavail * space.bsize;
      const device = String(st.dev);
      const existing = volumes.get(device);
      if (!existing || free < existing.free) volumes.set(device, { device, free, paths: [path] });
      else existing.paths.push(path);
    }
    const { bytes, sockets, fifos } = await treeBytes(this.output, this.journal);
    this.journal.mark('resource-sample', { phase, bytes, sockets, fifos, volumes: [...volumes.values()].map(v => ({ ...v, free: String(v.free) })) });
    if ([...volumes.values()].some(v => v.free < BigInt(minimumFree))) throw new Error(`free-space-below-${minimumFree}`);
    if (bytes > 200 * MIB) throw new Error('output-above-200MiB');
    if (performance.now() - sampleStart > 3000) throw new Error('resource-sample-took-over-3s');
    return { bytes, volumes };
  }
  async stableStart() {
    // 21 checks at least 3 seconds apart span at least 60 seconds.
    for (let sample = 0; sample < 21; sample++) {
      if (sample) await delay(3000);
      await this.sample('initial', 2.5 * GIB);
    }
  }
  async beforeLeg() { await this.sample('before-leg', 1.5 * GIB); }
  start() {
    this.lastStart = performance.now();
    this.timer = setInterval(async () => {
      if (this.busy || this.error) return;
      this.busy = true;
      try { await this.sample('active', 1 * GIB); }
      catch (error) {
        this.error = error;
        const reason = error instanceof Error && /^[a-zA-Z0-9:-]{1,100}$/.test(error.message)
          ? error.message.replace(/[0-9a-f]{64}/gi, '[redacted]') : 'resource-check-failed';
        const errno = typeof error?.code === 'string' && /^E[A-Z0-9]{1,32}$/.test(error.code) ? error.code : undefined;
        try { this.journal.mark('resource-stop', { reason, ...(errno ? { errno } : {}) }); } catch {}
        this.abort(error);
      } finally { this.busy = false; }
    }, 3000);
  }
  stop() { if (this.timer) clearInterval(this.timer); this.timer = undefined; }
}

// Poll process ancestry and group membership while each registered group
// leader is alive. An uncertain cleanup is a hard failure.
async function census() {
  const { stdout } = await execFileAsync('/bin/ps', ['-axww', '-o', 'pid=,ppid=,pgid=,lstart=,comm='], { maxBuffer: 8 * MIB, timeout: 5000 });
  const rows = [];
  for (const line of stdout.split('\n')) {
    const m = line.match(/^\s*(\d+)\s+(\d+)\s+(\d+)\s+(\S+\s+\S+\s+\d+\s+\d+:\d+:\d+\s+\d{4})\s*(.*)$/);
    if (m) rows.push({ pid: Number(m[1]), ppid: Number(m[2]), pgid: Number(m[3]), start: m[4], command: m[5] });
  }
  if (!rows.some(row => row.pid === process.pid)) throw new Error('process-census-incomplete');
  return rows;
}

export class ProcessRegistry {
  constructor(journal, abort) { this.journal = journal; this.abort = abort; this.roots = new Map(); this.known = new Map(); this.timer = undefined; this.pendingScan = undefined; this.scanGeneration = 0; this.stopped = false; }
  spawn(label, executable, args, options, captureLimit = 0, ipc = false) {
    if (this.stopped) throw new Error('process-registry-stopped');
    const child = spawn(executable, args, { ...options, detached: true, stdio: ipc ? ['ignore', 'pipe', 'pipe', 'ipc'] : ['ignore', 'pipe', 'pipe'] });
    if (!child.pid) throw new Error(`spawn-failed-${label}`);
    const root = { label, child, pid: child.pid, exited: false, closed: false, code: null, signal: null, bytesOut: 0, bytesErr: 0, captured: [], captureBytes: 0, captureOverflow: false, messages: [], messageOverflow: false };
    this.roots.set(root.pid, root);
    const outputEnd = stream => new Promise(resolve => {
      stream.once('end', resolve);
      stream.once('error', () => { root.outputError = true; resolve(); });
    });
    root.outputDone = Promise.all([outputEnd(child.stdout), outputEnd(child.stderr)]);
    // Drain but never persist raw child output; do not risk exposing secrets.
    child.stdout.on('data', data => {
      root.bytesOut += data.length;
      if (captureLimit && !root.captureOverflow) {
        const part = Buffer.from(data), remaining = captureLimit - root.captureBytes;
        if (part.length > remaining) { root.captured.push(part.subarray(0, remaining)); root.captureBytes += remaining; root.captureOverflow = true; }
        else { root.captured.push(part); root.captureBytes += part.length; }
      }
    });
    child.stderr.on('data', data => { root.bytesErr += data.length; });
    if (ipc) child.on('message', message => {
      if (root.messages.length >= 100) { root.messageOverflow = true; this.abort(new Error('leg-message-overflow')); return; }
      root.messages.push(message);
      // Persist recorder lifecycle as it arrives, even if the supervisor fails
      // while observing the short-lived recorder. Never log child output.
      try {
        if (message?.type === 'child-start' && message.role === 'recorder') {
          if (!Number.isSafeInteger(message.pid) || message.pid <= 1) throw new Error('recorder-start-invalid');
          this.journal.mark('recorder-child-start', { label, pid: message.pid });
        } else if (message?.type === 'child-exit' && message.role === 'recorder') {
          const capture = message.stderrCapture;
          const nonnegative = value => Number.isSafeInteger(value) && value >= 0;
          if (!(message.code === null || Number.isSafeInteger(message.code)) ||
              !(message.signal === null || (typeof message.signal === 'string' && /^SIG[A-Z0-9]+$/.test(message.signal))) ||
              typeof message.error !== 'boolean' || typeof message.stderrCaptureError !== 'boolean' ||
              !nonnegative(message.stdoutBytes) || !nonnegative(message.stderrBytes) ||
              !capture || !nonnegative(capture.capturedBytes) || capture.capturedBytes > 64 * 1024 ||
              typeof capture.truncated !== 'boolean' || !nonnegative(capture.redactions)) throw new Error('recorder-exit-invalid');
          this.journal.mark('recorder-child-exit', { label, code: message.code, signal: message.signal, error: message.error,
            stdoutBytes: message.stdoutBytes, stderrBytes: message.stderrBytes, stderrCaptureError: message.stderrCaptureError,
            stderrCapture: { capturedBytes: capture.capturedBytes, truncated: capture.truncated, redactions: capture.redactions } });
          if (message.stderrCaptureError) this.abort(new Error('recorder-stderr-capture-failed'));
        } else if (message?.type === 'recorder-start-failed') {
          this.journal.mark('recorder-start-failed', { label, code: null, signal: null });
        } else if (message?.type === 'recorder-stderr-capture-failed') {
          this.journal.mark('recorder-stderr-capture-failed', { label });
          this.abort(new Error('recorder-stderr-capture-failed'));
        }
      } catch { this.abort(new Error('recorder-lifecycle-or-journal-failed')); }
    });
    root.done = new Promise(resolveDone => {
      child.once('error', () => { root.error = true; });
      child.once('exit', () => { root.exited = true; });
      child.once('close', (code, signal) => { root.closed = true; root.code = code; root.signal = signal; resolveDone(root); });
    });
    this.journal.mark('process-start', { label, pid: root.pid });
    return root;
  }
  async scan() {
    if (this.pendingScan) return this.pendingScan;
    const generation = ++this.scanGeneration;
    this.pendingScan = (async () => {
      const rows = await census(), ids = new Set();
      // A closed root may have already been recycled; never freshly adopt a
      // PID or process group solely because it once matched a closed root.
      for (const root of this.roots.values()) if (!root.exited) ids.add(root.pid);
      for (const row of rows) if (this.roots.has(row.pgid) && !this.roots.get(row.pgid).exited) ids.add(row.pid);
      for (const row of rows) if (this.known.get(row.pid)?.start === row.start) ids.add(row.pid);
      let changed = true;
      while (changed) {
        changed = false;
        for (const row of rows) if (ids.has(row.ppid) && !ids.has(row.pid)) { ids.add(row.pid); changed = true; }
      }
      for (const row of rows) if (ids.has(row.pid)) this.known.set(row.pid, { ...row, scanGeneration: generation });
    })();
    try {
      await this.pendingScan;
    } finally { this.pendingScan = undefined; }
  }
  // A shared in-flight census may predate a newly spawned root. Retry until
  // a later census observes that live anchor in its own group; never accept
  // an unobserved or mismatched group, and stop promptly on abort or exit.
  async observeRoot(root, signal, timeoutMs = 5000) {
    const afterGeneration = this.scanGeneration;
    const deadline = performance.now() + timeoutMs;
    let observedPgid = null;
    const fail = reason => {
      this.journal.mark('process-group-observation-failure', { label: root.label, pid: root.pid, reason, observedPgid });
      throw new Error(reason);
    };
    while (performance.now() < deadline) {
      if (signal?.aborted || this.stopped) throw new Error('aborted');
      if (root.exited || root.error) fail('spawned-process-exited-before-observation');
      await this.scan();
      if (signal?.aborted || this.stopped) throw new Error('aborted');
      if (root.exited || root.error) fail('spawned-process-exited-before-observation');
      const row = this.known.get(root.pid);
      if (row && row.scanGeneration > afterGeneration) {
        observedPgid = row.pgid;
        if (row.pgid === root.pid) {
          this.journal.mark('process-group-observed', { label: root.label, pid: root.pid, pgid: row.pgid, scanGeneration: row.scanGeneration });
          return row;
        }
      }
      await delay(50);
    }
    fail(observedPgid === null ? 'spawned-process-not-observed' : 'spawned-process-group-mismatch');
  }
  start() {
    this.timer = setInterval(() => this.scan().catch(() => {
      try { this.journal.mark('process-census-failed'); } catch {}
      this.stopped = true;
      this.abort(new Error('process-census-failed'));
    }), 250);
  }
  async browserProfile(temp) {
    await this.scan();
    const tempRoot = await realpath(temp);
    for (const row of this.known.values()) {
      if (!/chrom(e|ium)/i.test(row.command)) continue;
      let command;
      try { ({ stdout: command } = await execFileAsync('/bin/ps', ['-p', String(row.pid), '-o', 'command='], { timeout: 3000, maxBuffer: MIB })); }
      catch { continue; }
      const match = command.match(/(?:^|\s)--user-data-dir=(?:"([^"]+)"|'([^']+)'|(\S+))/);
      if (!match) continue;
      let profile;
      try { profile = await realpath(match[1] ?? match[2] ?? match[3]); } catch { continue; }
      const rel = relative(tempRoot, profile);
      if (rel && !rel.startsWith('..') && !isAbsolute(rel)) return { pid: row.pid, insideTemp: true };
      throw new Error('browser-profile-outside-temp');
    }
    return null;
  }
  async stop(reason) {
    this.stopped = true;
    if (this.timer) clearInterval(this.timer);
    try { await this.scan(); } catch { try { this.journal.mark('process-census-failed-at-stop'); } catch {} }
    try { this.journal.mark('process-cleanup-start', { reason }); } catch {}
    let survivors = ['unknown'];
    try {
      for (const signal of ['SIGTERM', 'SIGKILL']) {
        await this.scan();
        const current = await census(), byId = new Map(current.map(row => [row.pid, row]));
        // Each root was started in its own verified process group. Signal a
        // group only when at least one member still has a recorded identity.
        for (const root of this.roots.values()) {
          const anchored = current.some(row => row.pgid === root.pid && this.known.get(row.pid)?.start === row.start);
          if (anchored) { try { process.kill(-root.pid, signal); } catch {} }
        }
        // Also clean any observed child which subsequently left its group.
        for (const old of [...this.known.values()].reverse()) {
          const now = byId.get(old.pid);
          if (!now || now.start !== old.start || this.roots.has(now.pgid)) continue;
          try { process.kill(old.pid, signal); } catch {}
        }
        const deadline = performance.now() + (signal === 'SIGTERM' ? 4000 : 2000);
        let emptyChecks = 0;
        while (performance.now() < deadline) {
          await delay(200);
          await this.scan();
          const rows = await census(), indexed = new Map(rows.map(row => [row.pid, row]));
          const knownAlive = [...this.known.values()].filter(old => indexed.get(old.pid)?.start === old.start).map(old => old.pid);
          const groupsAlive = rows.filter(row => this.roots.has(row.pgid)).map(row => `group:${row.pgid}:pid:${row.pid}`);
          survivors = [...new Set([...knownAlive, ...groupsAlive])];
          if (!survivors.length && ++emptyChecks >= 2) break;
          if (survivors.length) emptyChecks = 0;
        }
        if (!survivors.length) break;
      }
    } catch { survivors = ['unknown']; }
    try { this.journal.mark('process-cleanup-end', { survivors }); } catch {}
    return survivors;
  }
  report(root) { return { label: root.label, pid: root.pid, code: root.code, signal: root.signal, error: !!root.error, stdoutBytes: root.bytesOut, stderrBytes: root.bytesErr }; }
}

