// Coordinator reservation and independent harness review completed.

import { createHash, randomBytes } from 'node:crypto';
import { execFile } from 'node:child_process';
import { createServer } from 'node:net';
import { lstat, mkdir, readFile, readdir, readlink, realpath, rm, stat, symlink, writeFile } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { performance } from 'node:perf_hooks';
import os from 'node:os';
import { promisify } from 'node:util';
import { Journal, ProcessRegistry, Resources, delay } from './supervisor-safety.mjs';

const execFileAsync = promisify(execFile);
const here = dirname(fileURLToPath(import.meta.url));
const targets = {
  A: { root: '/private/tmp/tesland-highway-pair-final-a', ref: '1b7b18bf44cb049b0f3b1b61bd1135bdd7d015fc', protocol: 52 },
  B: { root: '/private/tmp/tesland-highway-pair-final-b', ref: 'f40a86ed22f1eb2846d0404451190d1d47b3321e', protocol: 53 },
};
const order = ['A', 'B'];
const expectedLock = '06bf1e2d3aa16bfc9fd14dfd6c168b93f6ec6d3a448d6464dd64b6c8b1bd4b29';
const expectedPackageManager = 'pnpm@10.33.1';
const pnpmRoot = '/Users/swyx/.local/share/fnm/node-versions/v22.22.2/installation/lib/node_modules/pnpm';
const pnpmPath = join(pnpmRoot, 'bin/pnpm.cjs');
const fixturePaths = [
  'package.json',
  'scripts/playtest-record.ts', 'scripts/playtest-capture.ts', 'scripts/playtest-audio-capture.js',
  'scripts/playtests/startup.json', 'tests/fixtures/playtest-stage-worker.ts',
  'tests/fixtures/wrangler.playtest-stage.jsonc', 'analyze.mjs', 'supervisor.mjs', 'supervisor-safety.mjs', 'leg-runner.mjs', 'command-runner.mjs',
];
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const inside = (root, path) => { const rel = relative(root, path); return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel)); };
async function hashFile(path) {
  const h = createHash('sha256');
  for await (const chunk of createReadStream(path)) h.update(chunk);
  return h.digest('hex');
}
async function git(root, args) {
  // Explicit --work-tree supports these local worktrees' nonstandard Git config.
  const { stdout } = await execFileAsync('git', [`--work-tree=${root}`, ...args], { cwd: root, maxBuffer: 20 * 1024 * 1024, timeout: 30000 });
  return stdout;
}
async function assertSource(target) {
  const root = await realpath(target.root);
  if (root !== target.root) throw new Error('target-root-not-exact-realpath');
  if ((await git(root, ['rev-parse', 'HEAD'])).trim() !== target.ref) throw new Error('target-head-mismatch');
  try {
    await git(root, ['symbolic-ref', '-q', 'HEAD']);
    throw new Error('target-not-detached');
  } catch (error) {
    if (error.message === 'target-not-detached' || error.code !== 1) throw error;
  }
  if ((await git(root, ['rev-parse', '--show-object-format'])).trim() !== 'sha1') throw new Error('unsupported-git-object-format');
  if ((await git(root, ['status', '--porcelain=v1', '-z', '--untracked-files=all'])).length) throw new Error('target-not-clean');
  if (sha(await readFile(join(root, 'pnpm-lock.yaml'))) !== expectedLock) throw new Error('lockfile-mismatch');
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  if (pkg.packageManager !== expectedPackageManager) throw new Error('package-manager-mismatch');
  const game = await readFile(join(root, 'shared/game.ts'), 'utf8');
  const matches = [...game.matchAll(/\bPROTOCOL_VERSION\s*=\s*(\d+)\s*;/g)];
  if (matches.length !== 1 || Number(matches[0][1]) !== target.protocol) throw new Error('source-protocol-mismatch');
  const tree = (await git(root, ['rev-parse', 'HEAD^{tree}'])).trim();
  const listing = await git(root, ['ls-tree', '-rz', '--full-tree', 'HEAD']);
  return { root, ref: target.ref, protocol: target.protocol, tree, listing, packageVersion: pkg.version, packageJson: pkg };
}

// Reconstruct explicit build inputs from byte-verified tracked files; docs and
// screenshots are deliberately excluded to stay within the run output budget.
// A tracked symlink or submodule is rejected, not silently followed. Git SHA-1
// is checked for each raw worktree file against its exact commit-tree blob.
async function mirrorSource(source, out, signal) {
  await mkdir(out, { recursive: false, mode: 0o700 });
  const roots = new Set(['package.json', 'pnpm-lock.yaml', 'index.html', 'vite.config.ts', 'wrangler.jsonc', 'tsconfig.json', 'tsconfig.worker.json', 'tsconfig.playtest.json', 'tsconfig.playtest-worker.json']);
  const prefixes = ['src/', 'shared/', 'worker/', 'public/', 'content/', 'scripts/', 'tests/'];
  const items = source.listing.split('\0').filter(Boolean).map(item => {
    const match = item.match(/^(\d{6}) (\w+) ([0-9a-f]{40})\t(.+)$/s);
    if (!match || match[2] !== 'blob' || !['100644', '100755'].includes(match[1])) throw new Error('unsupported-git-tree-entry');
    const path = match[4];
    if (path.includes('\0') || !inside(out, resolve(out, path)) || !inside(source.root, resolve(source.root, path))) throw new Error('unsafe-git-path');
    return { mode: match[1], oid: match[3], path };
  }).filter(item => roots.has(item.path) || prefixes.some(prefix => item.path.startsWith(prefix)));
  if (![...roots].every(path => items.some(item => item.path === path)) || !prefixes.every(prefix => items.some(item => item.path.startsWith(prefix)))) throw new Error('build-input-allowlist-incomplete');
  const provenance = [];
  for (const item of items) {
    if (signal.aborted) throw new Error('aborted');
    const input = join(source.root, item.path), output = join(out, item.path), st = await lstat(input);
    if (!st.isFile() || st.isSymbolicLink()) throw new Error('source-file-not-regular');
    const bytes = await readFile(input);
    const object = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
    if (object !== item.oid) throw new Error('source-blob-mismatch');
    await mkdir(dirname(output), { recursive: true, mode: 0o700 });
    await writeFile(output, bytes, { flag: 'wx', mode: item.mode === '100755' ? 0o755 : 0o644 });
    provenance.push({ path: item.path, gitBlob: object, sha256: sha(bytes), bytes: bytes.length, mode: item.mode });
  }
  return { count: provenance.length, sha256: sha(Buffer.from(JSON.stringify(provenance))), files: provenance };
}

// Hash a complete tree, including file paths, modes, contents, and symbolic
// link text, but never traverse symlinks. Used for build and source inputs.
async function treeFingerprint(root, signal) {
  const hash = createHash('sha256');
  let files = 0, bytes = 0;
  async function walk(path, rel) {
    if (signal?.aborted) throw new Error('aborted');
    const st = await lstat(path);
    if (st.isSymbolicLink()) { hash.update(`L\0${rel}\0${await readlink(path)}\0`); return; }
    if (st.isDirectory()) {
      hash.update(`D\0${rel}\0`);
      for (const name of (await readdir(path)).sort()) await walk(join(path, name), rel ? `${rel}/${name}` : name);
      return;
    }
    if (!st.isFile()) throw new Error('fingerprint-unsupported-file');
    hash.update(`F\0${rel}\0${st.mode & 0o777}\0${st.size}\0`);
    for await (const chunk of createReadStream(path)) { if (signal?.aborted) throw new Error('aborted'); hash.update(chunk); }
    hash.update('\0'); files++; bytes += st.size;
  }
  await walk(root, '');
  return { sha256: hash.digest('hex'), files, bytes };
}

async function dependencyIdentity(a, b) {
  const declared = p => ({ ...p.dependencies, ...p.devDependencies });
  const versionsA = declared(a.packageJson), versionsB = declared(b.packageJson);
  if (JSON.stringify(versionsA) !== JSON.stringify(versionsB)) throw new Error('direct-dependency-declarations-differ');
  const lock = await readFile(join(a.root, 'pnpm-lock.yaml'), 'utf8');
  const importer = lock.split(/\npackages:\s*\n/)[0];
  if (!/^importers:\s*$/m.test(importer) || !/^  \.:\s*$/m.test(importer)) throw new Error('unexpected-lockfile-importer');
  const locked = {}; let current;
  for (const line of importer.split('\n')) {
    const name = line.match(/^      (?:'([^']+)'|([^\s:]+)):\s*$/);
    if (name) { current = name[1] ?? name[2]; continue; }
    const version = line.match(/^        version: (\S+)\s*$/);
    if (version && current) {
      if (locked[current]) throw new Error('duplicate-lockfile-direct-dependency');
      locked[current] = version[1].split('(')[0]; current = undefined;
    }
  }
  const names = ['.pnpm', '.bin', ...Object.keys(versionsA).sort()];
  const roots = {};
  for (const name of names) {
    const first = await realpath(join(a.root, 'node_modules', name));
    const second = await realpath(join(b.root, 'node_modules', name));
    if (first !== second) throw new Error('dependency-realpaths-differ');
    roots[name] = first;
  }
  const modA = sha(await readFile(join(a.root, 'node_modules/.modules.yaml')));
  const modB = sha(await readFile(join(b.root, 'node_modules/.modules.yaml')));
  if (modA !== modB) throw new Error('dependency-metadata-differs');
  const direct = {};
  for (const name of Object.keys(versionsA).sort()) {
    const pkg = JSON.parse(await readFile(join(roots[name], 'package.json'), 'utf8'));
    if (!locked[name] || pkg.name !== name || pkg.version !== locked[name]) throw new Error('installed-direct-dependency-version-mismatch');
    direct[name] = { path: roots[name], version: pkg.version, lockVersion: locked[name] };
  }
  // Resolved direct packages are recorded, not independently integrity checked.
  return { roots, modulesYaml: modA, direct };
}

async function snapshotHarness(out, dependencies) {
  const hashes = {}, copies = {};
  for (const path of fixturePaths) {
    const bytes = await readFile(join(here, path)); hashes[path] = sha(bytes); copies[path] = bytes;
    const destination = join(out, path);
    await mkdir(dirname(destination), { recursive: true, mode: 0o700 });
    await writeFile(destination, bytes, { flag: 'wx', mode: 0o600 });
  }
  await symlink(await realpath(join(targets.A.root, 'node_modules')), join(out, 'node_modules'), 'dir');
  // The recorder imports Playwright from this copied harness. Verify it is
  // exactly the same resolved dependency used by both source targets.
  if (await realpath(join(out, 'node_modules/playwright')) !== dependencies.roots.playwright) throw new Error('harness-dependency-mismatch');
  return hashes;
}
async function verifyHarness(out, hashes) {
  for (const [path, expected] of Object.entries(hashes)) {
    if (sha(await readFile(join(out, path))) !== expected || sha(await readFile(join(here, path))) !== expected) throw new Error('harness-changed');
  }
}

function childEnvironment(temp) {
  // HOME remains inherited. Temp/profile/XDG cache paths are per leg.
  const env = {};
  for (const name of ['PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'TZ', 'PLAYWRIGHT_BROWSERS_PATH']) {
    if (process.env[name] !== undefined) env[name] = process.env[name];
  }
  // The build script invokes pnpm recursively; resolve that executable to the
  // same explicitly checked package manager, not the Homebrew 10.33.0 one.
  env.PATH = `${resolve(pnpmRoot, '../../../bin')}:${env.PATH ?? ''}`;
  env.TMPDIR = temp;
  env.XDG_CACHE_HOME = join(temp, 'cache');
  env.XDG_CONFIG_HOME = join(temp, 'config');
  env.CLOUDFLARE_LOAD_DEV_VARS_FROM_DOT_ENV = 'true';
  env.CLOUDFLARE_INCLUDE_PROCESS_ENV = 'false';
  return env;
}
async function freePort() {
  const server = createServer();
  await new Promise((ok, fail) => { server.once('error', fail); server.listen(0, '127.0.0.1', ok); });
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('port-reservation-failed');
  await new Promise((ok, fail) => server.close(error => error ? fail(error) : ok()));
  return address.port; // Not a reservation after close; validate Worker readiness.
}
async function awaitChild(root, timeoutMs, signal, label, journal, acceptedCodes = [0]) {
  let timer, onAbort;
  try {
    const resultAfterOutput = async () => {
      const message = await waitMessage(root, 'command-result', undefined, timeoutMs, signal);
      if (!(message.code === null || Number.isSafeInteger(message.code)) ||
          !(message.signal === null || typeof message.signal === 'string') || typeof message.error !== 'boolean') throw new Error('command-result-invalid');
      await root.outputDone;
      if (root.outputError) throw new Error('command-output-error');
      root.commandResult = { code: message.code, signal: message.signal, error: message.error };
      return { ...root.commandResult, bytesOut: root.bytesOut, bytesErr: root.bytesErr };
    };
    const result = await Promise.race([
      resultAfterOutput(),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label}-timeout`)), timeoutMs); }),
      new Promise((_, reject) => { onAbort = () => reject(new Error('aborted')); if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true }); }),
    ]);
    journal.mark('process-exit', { label, code: result.code, signal: result.signal, error: !!result.error, stdoutBytes: result.bytesOut, stderrBytes: result.bytesErr });
    if (result.error || !acceptedCodes.includes(result.code) || result.signal) throw new Error(`${label}-failed`);
    return result;
  } catch (error) {
    try { journal.mark('process-failure', { label, reason: /^[a-zA-Z0-9:-]{1,100}$/.test(error.message) ? error.message : 'internal-error' }); } catch {}
    throw error;
  } finally { if (timer) clearTimeout(timer); if (onAbort) signal.removeEventListener('abort', onAbort); }
}
async function health(port, worker, expectedVersion, signal, journal) {
  const deadline = performance.now() + 90000;
  while (performance.now() < deadline) {
    if (signal.aborted) throw new Error('aborted');
    if (worker.closed || worker.messages.some(m => m?.type === 'child-exit' && m.role === 'worker')) throw new Error('worker-exited-before-health');
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2000) });
      if (response.ok) {
        const body = await response.json();
        if (body.version !== expectedVersion) throw new Error('worker-protocol-mismatch');
        journal.mark('worker-health', { protocol: body.version }); return;
      }
    } catch (error) { if (error.message === 'worker-protocol-mismatch') throw error; }
    await delay(500);
  }
  throw new Error('worker-health-timeout');
}
async function closeRegistry(registry, journal, reason) {
  const survivors = await registry.stop(reason);
  if (survivors.length) { journal.mark('cleanup-incomplete', { survivors }); throw new Error('cleanup-incomplete'); }
}
async function spawnObserved(registry, label, executable, args, options, captureLimit = 0, ipc = false, signal) {
  const root = registry.spawn(label, executable, args, options, captureLimit, ipc);
  await registry.observeRoot(root, signal);
  return root;
}
async function spawnCommand(registry, harness, label, executable, args, options, captureLimit = 0, signal) {
  return spawnObserved(registry, label, process.execPath, [join(harness, 'command-runner.mjs'), executable, ...args], options, captureLimit, true, signal);
}
async function waitMessage(root, type, role, timeoutMs, signal) {
  const deadline = performance.now() + timeoutMs;
  while (performance.now() < deadline) {
    if (signal.aborted) throw new Error('aborted');
    if (root.messageOverflow || root.messages.some(m => m?.type === 'runner-failed')) throw new Error('leg-runner-failed');
    if (root.messages.some(m => m?.type === 'recorder-stderr-capture-failed' || (m?.type === 'child-exit' && m.role === 'recorder' && m.stderrCaptureError))) throw new Error('recorder-stderr-capture-failed');
    if (root.messages.some(m => m?.type === 'child-exit' && m.role === 'worker')) throw new Error('worker-exited-during-leg');
    const matching = root.messages.filter(m => m?.type === type && (!role || m.role === role));
    if (matching.length > 1) throw new Error('duplicate-leg-message');
    if (matching.length === 1) return matching[0];
    if (root.exited || !root.child.connected) throw new Error('leg-runner-exited');
    await delay(50);
  }
  throw new Error('leg-message-timeout');
}
async function verifyMember(registry, root, message, role, journal) {
  if (!Number.isSafeInteger(message.pid) || message.pid <= 1) throw new Error('invalid-leg-child-pid');
  const deadline = performance.now() + 5000;
  while (performance.now() < deadline) {
    if (root.messages.some(m => m?.type === 'child-exit' && m.role === role)) throw new Error(`${role}-exited-before-observation`);
    await registry.scan();
    if (root.messages.some(m => m?.type === 'child-exit' && m.role === role)) throw new Error(`${role}-exited-before-observation`);
    const row = registry.known.get(message.pid);
    if (row) {
      if (row.ppid !== root.pid || row.pgid !== root.pid) throw new Error('leg-child-process-group-mismatch');
      journal.mark('child-group-verified', { role, pid: message.pid }); return;
    }
    if (root.exited) throw new Error('leg-runner-exited');
    await delay(100);
  }
  throw new Error('leg-child-not-observed');
}
async function verifyBrowserProfile(registry, temp, root, signal, journal) {
  const deadline = performance.now() + 30000;
  while (performance.now() < deadline) {
    if (signal.aborted) throw new Error('aborted');
    const profile = await registry.browserProfile(temp);
    if (profile) { journal.mark('browser-profile-verified', profile); return; }
    if (root.exited || root.messages.some(m => m?.type === 'capture-finished')) throw new Error('browser-profile-not-observed');
    await delay(250);
  }
  throw new Error('browser-profile-timeout');
}
async function verifyServedAssets(port, dist, journal) {
  const html = await readFile(join(dist, 'index.html'));
  const tags = [...html.toString('utf8').matchAll(/<(script|link)\b[^>]*>/gi)].map(m => m[0]);
  const references = [];
  for (const tag of tags) {
    const script = /^<script\b/i.test(tag);
    const style = /^<link\b/i.test(tag) && /\brel\s*=\s*["']stylesheet["']/i.test(tag);
    if (!script && !style) continue;
    const attr = tag.match(script ? /\bsrc\s*=\s*["']([^"']+)["']/i : /\bhref\s*=\s*["']([^"']+)["']/i);
    if (!attr || !/^\/assets\/[a-zA-Z0-9._-]+$/.test(attr[1])) throw new Error('unexpected-entry-asset');
    references.push({ path: attr[1], kind: script ? 'script' : 'style' });
  }
  if (!references.some(x => x.kind === 'script') || !references.some(x => x.kind === 'style')) throw new Error('missing-entry-assets');
  const results = [];
  for (const path of ['/', ...new Set(references.map(x => x.path))]) {
    const expected = path === '/' ? html : await readFile(join(dist, path.slice(1)));
    if (expected.length > 16 * 1024 * 1024) throw new Error('entry-asset-too-large');
    const response = await fetch(`http://127.0.0.1:${port}${path}`, { redirect: 'error', signal: AbortSignal.timeout(10000) });
    if (!response.ok) throw new Error('entry-asset-fetch-failed');
    const length = Number(response.headers.get('content-length'));
    if (Number.isFinite(length) && length > 16 * 1024 * 1024) throw new Error('served-entry-asset-too-large');
    const actual = Buffer.from(await response.arrayBuffer());
    if (actual.length !== expected.length || sha(actual) !== sha(expected)) throw new Error('served-entry-asset-mismatch');
    results.push({ path, bytes: actual.length, sha256: sha(actual) });
  }
  journal.mark('served-client-assets', { assets: results });
  return results;
}
async function verifyWelcome(path, protocol) {
  const text = await readFile(path, 'utf8');
  const rows = text.split('\n').filter(Boolean).map(line => JSON.parse(line));
  const welcomes = rows.filter(row => row.kind === 'welcome');
  if (welcomes.length !== 1 || welcomes[0].version !== protocol) throw new Error('welcome-protocol-mismatch');
}
function watchRecorder(root, path, journal, abort) {
  let stopped = false, busy = false, startSeenAt, failedAt, timeoutMarked = false;
  const timer = setInterval(async () => {
    if (stopped || busy || root.closed) return;
    busy = true;
    try {
      let bytes;
      try {
        const st = await stat(path);
        if (st.size > 5 * 1024 * 1024) throw new Error('live-trace-too-large');
        bytes = await readFile(path, 'utf8');
      } catch (error) { if (error.code === 'ENOENT') return; throw error; }
      // Only complete NDJSON lines are considered; do not journal contents.
      const lines = bytes.split('\n'); lines.pop();
      const rows = lines.filter(Boolean).map(line => JSON.parse(line));
      if (startSeenAt === undefined && rows.some(row => row.kind === 'key-command-start')) startSeenAt = performance.now();
      const outcome = rows.find(row => row.kind === 'key-command-outcome');
      if (outcome && outcome.status !== 'completed' && !timeoutMarked) {
        timeoutMarked = true; failedAt = performance.now();
        journal.mark('key-command-failed-page-data-censored', { status: outcome.status === 'timeout' ? 'timeout' : 'failed' });
      }
      if (failedAt !== undefined && performance.now() - failedAt > 3000) abort(new Error('recorder-key-timeout'));
      if (startSeenAt !== undefined && !outcome && performance.now() - startSeenAt > 12000) {
        journal.mark('key-command-outcome-missing-page-data-censored');
        abort(new Error('recorder-key-timeout'));
      }
    } catch {
      try { journal.mark('recorder-watch-failed'); } catch {}
      abort(new Error('recorder-watch-failed'));
    } finally { busy = false; }
  }, 1000);
  return () => { stopped = true; clearInterval(timer); };
}
async function runAnalyzer({ index, leg, temp, harness, expectedSha, journal, signal, abort }) {
  const analyzer = join(harness, 'analyze.mjs');
  const label = `analyzer-${index}`;
  const registry = new ProcessRegistry(journal, abort);
  let root, issue = null;
  registry.start();
  try {
    if (sha(await readFile(analyzer)) !== expectedSha) throw new Error('analyzer-hash-mismatch');
    root = await spawnCommand(registry, harness, label, process.execPath, [analyzer, join(leg, 'browser')],
      { cwd: harness, env: childEnvironment(temp) }, 2 * 1024 * 1024, signal);
    await awaitChild(root, 30000, signal, label, journal, [0, 2]);
    if (sha(await readFile(analyzer)) !== expectedSha) throw new Error('analyzer-changed-during-run');
  } catch (error) { issue = error instanceof Error && /^[a-zA-Z0-9:-]{1,100}$/.test(error.message) ? error.message : 'analyzer-error'; }
  finally {
    try { await closeRegistry(registry, journal, `${label}-finished`); }
    catch { issue ??= 'analyzer-cleanup-incomplete'; }
  }
  // Preserve partial output even if setup or cleanup failed.
  root ??= [...registry.roots.values()].find(entry => entry.label === label);
  const raw = root ? Buffer.concat(root.captured) : Buffer.alloc(0);
  const rawPath = root?.captureOverflow ? 'analysis.raw.partial' : 'analysis.raw.json';
  await writeFile(join(leg, rawPath), raw, { flag: 'wx', mode: 0o600 });
  let parsed;
  try { parsed = JSON.parse(raw.toString('utf8')); } catch { issue ??= 'analyzer-malformed-json'; }
  const reasonsValid = Array.isArray(parsed?.reasons) && parsed.reasons.every(reason => typeof reason === 'string');
  const command = root?.commandResult;
  const accepted = !issue && !root?.captureOverflow && !command?.error && !command?.signal && root?.bytesErr === 0 && reasonsValid &&
    ((command?.code === 0 && parsed.status === 'evidence-complete' && parsed.reasons.length === 0) ||
     (command?.code === 2 && parsed.status === 'censored' && parsed.reasons.length > 0));
  const status = accepted && parsed.status === 'evidence-complete' ? 'evidence-complete' : 'censored';
  const result = { status, analyzerSha256: expectedSha, analyzerExit: command?.code ?? null, analyzerSignal: command?.signal ?? null,
    analyzerOutput: rawPath, stderrBytes: root?.bytesErr ?? null, truncated: !!root?.captureOverflow, reason: issue ?? (accepted ? null : 'analyzer-contract-invalid') };
  await writeFile(join(leg, 'analysis-status.json'), JSON.stringify(result) + '\n', { flag: 'wx', mode: 0o600 });
  journal.mark('leg-analysis', { index, ...result });
  return result;
}

async function main() {
  const run = `/private/tmp/tesland-highway-startup-${Date.now()}-${randomBytes(5).toString('hex')}`;
  await mkdir(run, { mode: 0o700 });
  const journal = new Journal(join(run, 'supervisor-events.ndjson'));
  const controller = new AbortController();
  let resources, registry, firstFailure;
  const secretFiles = new Set();
  const abort = reason => {
    if (controller.signal.aborted) return;
    firstFailure = reason;
    const message = reason instanceof Error && /^[a-zA-Z0-9:-]{1,100}$/.test(reason.message) ? reason.message : 'internal-error';
    try { journal.mark('abort', { reason: message }); } catch {}
    controller.abort();
  };
  const onInterrupt = () => abort(new Error('signal-SIGINT'));
  const onTerminate = () => abort(new Error('signal-SIGTERM'));
  process.once('SIGINT', onInterrupt); process.once('SIGTERM', onTerminate);
  try {
    journal.mark('start', { order, platform: process.platform, arch: process.arch, os: os.release(), hostLoad: os.loadavg() });
    const sources = { A: await assertSource(targets.A), B: await assertSource(targets.B) };
    const deps = await dependencyIdentity(sources.A, sources.B);
    // Monitor the volumes used by known inputs, output, executable and caches.
    const originalReq = createRequire(join(here, 'scripts/playtest-record.ts'));
    const browserExecutable = await realpath(originalReq('playwright').chromium.executablePath());
    const pnpmMetadata = JSON.parse(await readFile(join(pnpmRoot, 'package.json'), 'utf8'));
    if (pnpmMetadata.name !== 'pnpm' || pnpmMetadata.version !== '10.33.1') throw new Error('pnpm-package-version-mismatch');
    if (await realpath(resolve(pnpmRoot, '../../../bin/pnpm')) !== await realpath(pnpmPath)) throw new Error('recursive-pnpm-path-mismatch');
    const paths = [run, here, sources.A.root, sources.B.root, deps.roots['.pnpm'], deps.roots['.bin'], process.execPath,
      await realpath(pnpmPath), browserExecutable, os.homedir(), join(os.homedir(), 'Library/Caches')];
    resources = new Resources({ paths, output: run, journal, abort, signal: controller.signal });
    await resources.stableStart();
    if (controller.signal.aborted) throw new Error('aborted');
    resources.start();
    const harness = join(run, 'harness');
    const fixture = await snapshotHarness(harness, deps);
    if (controller.signal.aborted) throw new Error('aborted');
    const req = createRequire(join(harness, 'scripts/playtest-record.ts'));
    const toolchain = { nodePath: process.execPath, nodeVersion: process.version, nodeSha256: await hashFile(process.execPath),
      pnpmPath: await realpath(pnpmPath), pnpmSha256: await hashFile(await realpath(pnpmPath)), browserExecutable,
      browserExecutableSha256: await hashFile(browserExecutable), playwrightVersion: req('playwright/package.json').version,
      pnpmMetadataSha256: await hashFile(join(pnpmRoot, 'package.json')) };
    journal.mark('provenance', { lockSha256: expectedLock, fixture, dependencies: deps, toolchain });

    const prepared = {};
    for (const id of ['A', 'B']) {
      if (controller.signal.aborted) throw new Error('aborted');
      const mirror = join(run, `source-${id}`);
      const sourceFiles = await mirrorSource(sources[id], mirror, controller.signal);
      await symlink(await realpath(join(sources[id].root, 'node_modules')), join(mirror, 'node_modules'), 'dir');
      const tmp = join(run, `build-temp-${id}`); await mkdir(tmp, { mode: 0o700 });
      registry = new ProcessRegistry(journal, abort); registry.start();
      try {
        const version = await spawnCommand(registry, harness, `pnpm-version-${id}`, process.execPath, [pnpmPath, '--version'], { cwd: mirror, env: childEnvironment(tmp) }, 256, controller.signal);
        await awaitChild(version, 30000, controller.signal, `pnpm-version-${id}`, journal);
        if (version.captureOverflow || Buffer.concat(version.captured).toString('utf8').trim() !== '10.33.1') throw new Error('executed-pnpm-version-mismatch');
        journal.mark('package-manager-version', { target: id, version: '10.33.1' });
        const build = await spawnCommand(registry, harness, `build-${id}`, process.execPath, [pnpmPath, 'build'], { cwd: mirror, env: childEnvironment(tmp) }, 0, controller.signal);
        await awaitChild(build, 300000, controller.signal, `build-${id}`, journal);
      } finally { await closeRegistry(registry, journal, `build-${id}-finished`); registry = undefined; }
      const build = await treeFingerprint(join(mirror, 'dist'), controller.signal);
      const mirrorTree = await treeFingerprint(mirror, controller.signal);
      const worker = await treeFingerprint(join(mirror, 'worker'), controller.signal);
      const shared = await treeFingerprint(join(mirror, 'shared'), controller.signal);
      await assertSource(targets[id]);
      if (JSON.stringify(await dependencyIdentity(sources.A, sources.B)) !== JSON.stringify(deps)) throw new Error('direct-dependencies-changed-during-build');
      prepared[id] = { mirror, sourceFiles, build, mirrorTree, worker, shared };
      await writeFile(join(run, `source-${id}-provenance.json`), JSON.stringify(sourceFiles) + '\n', { flag: 'wx', mode: 0o600 });
      journal.mark('build-provenance', { target: id, ref: sources[id].ref, tree: sources[id].tree, protocol: sources[id].protocol,
        sourceFiles: { count: sourceFiles.count, sha256: sourceFiles.sha256 }, build, mirrorTree, worker, shared, packageVersion: sources[id].packageVersion });
    }

    for (let index = 0; index < order.length; index++) {
      if (controller.signal.aborted) throw new Error('aborted');
      const id = order[index], source = sources[id], build = prepared[id];
      await resources.beforeLeg(); await assertSource(targets[id]); await verifyHarness(harness, fixture);
      if ((await treeFingerprint(build.mirror, controller.signal)).sha256 !== build.mirrorTree.sha256) throw new Error('source-or-client-changed');
      if (JSON.stringify(await dependencyIdentity(sources.A, sources.B)) !== JSON.stringify(deps)) throw new Error('direct-dependencies-changed');
      if (await hashFile(await realpath(pnpmPath)) !== toolchain.pnpmSha256 || await hashFile(join(pnpmRoot, 'package.json')) !== toolchain.pnpmMetadataSha256) throw new Error('package-manager-changed');
      const leg = join(run, `leg-${index + 1}-${id}`), temp = join(leg, 'tmp');
      await mkdir(temp, { recursive: true, mode: 0o700 });
      const stage = await readFile(join(harness, 'tests/fixtures/playtest-stage-worker.ts'), 'utf8');
      let replacements = 0;
      const mountedStage = stage.replace(/(['"])\.\.\/\.\.\/(worker|shared)\/([^'"]+)\1/g, (_all, _quote, directory, module) => {
        replacements++; return JSON.stringify(join(build.mirror, directory, `${module}.ts`));
      });
      if (!replacements || /(['"])\.\.\/\.\.\/(worker|shared)\//.test(mountedStage)) throw new Error('stage-mount-failed');
      const stagePath = join(temp, 'playtest-stage-worker.ts'), configPath = join(temp, 'wrangler.json');
      const configText = await readFile(join(harness, 'tests/fixtures/wrangler.playtest-stage.jsonc'), 'utf8');
      const config = JSON.parse(configText.replace(/^\s*\/\/.*$/gm, ''));
      config.main = stagePath; config.assets.directory = join(build.mirror, 'dist');
      const configBytes = Buffer.from(JSON.stringify(config));
      await writeFile(stagePath, mountedStage, { flag: 'wx', mode: 0o600 });
      await writeFile(configPath, configBytes, { flag: 'wx', mode: 0o600 });
      const port = await freePort(); let inspectorPort = await freePort(); while (port === inspectorPort) inspectorPort = await freePort();
      const room = `startup-${randomBytes(7).toString('hex')}`, secret = randomBytes(32).toString('hex');
      const secretFile = join(temp, 'stage.env');
      await writeFile(secretFile, `PLAYTEST_STAGE_SECRET=${secret}\n`, { flag: 'wx', mode: 0o600 });
      secretFiles.add(secretFile);
      const legMeta = { index: index + 1, id, ref: source.ref, gitTree: source.tree, protocol: source.protocol, lockSha256: expectedLock,
        sourceSha256: build.sourceFiles.sha256, build: build.build, mirrorTree: build.mirrorTree, worker: build.worker, shared: build.shared, dependencies: deps.direct, fixture,
        mountedStageSha256: sha(Buffer.from(mountedStage)), configSha256: sha(configBytes), toolchain, hostLoad: os.loadavg() };
      journal.mark('leg-start', legMeta);
      registry = new ProcessRegistry(journal, abort); registry.start();
      let legIssue = null, runner;
      try {
        const runnerConfig = { node: process.execPath, workerCwd: build.mirror, workerArgs: [join(build.mirror, 'node_modules/wrangler/bin/wrangler.js'),
          'dev', '--config', configPath, '--env-file', secretFile, '--local', '--ip', '127.0.0.1', '--port', String(port), '--inspector-port', String(inspectorPort),
          '--var', 'PLAYTEST_X:-798', '--var', 'PLAYTEST_Z:3300', '--var', 'PLAYTEST_YAW:0.053', '--var', 'PLAYTEST_SEED:0', '--var', 'PLAYTEST_PAUSE:1', '--persist-to', join(temp, 'storage')],
          recorderCwd: harness, recorderStderrPath: join(leg, 'recorder-stderr.txt'), recorderArgs: [join(build.mirror, 'node_modules/tsx/dist/cli.mjs'),
          join(harness, 'scripts/playtest-record.ts'), '--url', `http://127.0.0.1:${port}/?room=${room}&perf`, '--target-ref', source.ref,
          '--scenario', join(harness, 'scripts/playtests/startup.json'), '--out', join(leg, 'browser'), '--gpu', 'metal', '--no-video', '--trajectory'] };
        const runnerConfigBytes = Buffer.from(JSON.stringify(runnerConfig));
        const runnerConfigPath = join(temp, 'leg-config.json');
        await writeFile(runnerConfigPath, runnerConfigBytes, { flag: 'wx', mode: 0o600 });
        journal.mark('leg-runner-config', { index: index + 1, sha256: sha(runnerConfigBytes) });
        const env = childEnvironment(temp); env.PLAYTEST_STAGE_SECRET = secret;
        runner = await spawnObserved(registry, `leg-group-${index + 1}`, process.execPath, [join(harness, 'leg-runner.mjs'), runnerConfigPath], { cwd: harness, env }, 0, true, controller.signal);
        const workerStart = await waitMessage(runner, 'child-start', 'worker', 15000, controller.signal);
        await verifyMember(registry, runner, workerStart, 'worker', journal);
        await health(port, runner, source.protocol, controller.signal, journal);
        await verifyServedAssets(port, join(build.mirror, 'dist'), journal);
        if (!runner.child.connected) throw new Error('leg-runner-disconnected');
        await new Promise((ok, fail) => runner.child.send({ type: 'start-recorder' }, error => error ? fail(new Error('leg-runner-send-failed')) : ok()));
        const recorderStart = await waitMessage(runner, 'child-start', 'recorder', 15000, controller.signal);
        await verifyMember(registry, runner, recorderStart, 'recorder', journal);
        const stopWatching = watchRecorder(runner, join(leg, 'browser/live-events.ndjson'), journal, abort);
        try {
          await verifyBrowserProfile(registry, temp, runner, controller.signal, journal);
          const result = await waitMessage(runner, 'capture-finished', undefined, 180000, controller.signal);
          journal.mark('recorder-exit', { index: index + 1, code: result.code, signal: result.signal, error: !!result.error });
          if (result.code !== 0 || result.signal || result.error) throw new Error('recorder-failed');
        }
        finally { stopWatching(); }
        if (runner.messages.some(m => m?.type === 'child-exit' && m.role === 'worker')) throw new Error('worker-exited-during-leg');
        const manifest = JSON.parse(await readFile(join(leg, 'browser/manifest.json'), 'utf8'));
        if (manifest.status !== 'complete' || manifest.target?.refProvidedByOperator !== source.ref) throw new Error('recorder-incomplete-or-target-mismatch');
        await verifyWelcome(join(leg, 'browser/live-events.ndjson'), source.protocol);
        journal.mark('leg-recorder-complete', { index: index + 1, id });
      } catch (error) {
        legIssue = error;
      } finally {
        try { await closeRegistry(registry, journal, `leg-${index + 1}-finished`); }
        catch (error) { legIssue ??= error; }
        const trackedRunner = runner ?? [...registry.roots.values()].find(root => root.label === `leg-group-${index + 1}`);
        if (trackedRunner?.messages.some(message => message?.type === 'child-start' && message.role === 'recorder') &&
            !trackedRunner.messages.some(message => message?.type === 'child-exit' && message.role === 'recorder')) {
          try { journal.mark('recorder-exit-unavailable', { index: index + 1, stderrArtifact: 'recorder-stderr.txt' }); }
          catch (error) { legIssue ??= error; }
        }
        registry = undefined;
        try { await rm(secretFile, { force: true }); secretFiles.delete(secretFile); }
        catch (error) { legIssue ??= error; }
      }
      // On a resource or signal abort, do not spawn a new analyzer process.
      // Retain a censored status if disk permits and preserve all raw files.
      if (controller.signal.aborted) {
        try { await writeFile(join(leg, 'analysis-status.json'), JSON.stringify({ status: 'censored', analyzerSha256: fixture['analyze.mjs'], reason: 'aborted-before-analyzer' }) + '\n', { flag: 'wx', mode: 0o600 }); } catch {}
        throw legIssue ?? new Error('aborted');
      }
      const analysis = await runAnalyzer({ index: index + 1, leg, temp, harness, expectedSha: fixture['analyze.mjs'], journal, signal: controller.signal, abort });
      if (legIssue) throw legIssue;
      if (analysis.status !== 'evidence-complete') throw new Error('leg-analysis-censored');
      await assertSource(targets[id]); await verifyHarness(harness, fixture);
      if ((await treeFingerprint(build.mirror, controller.signal)).sha256 !== build.mirrorTree.sha256) throw new Error('source-or-client-changed-after-leg');
      journal.mark('leg-end', { index: index + 1, id });
    }
    journal.mark('run-finished', { status: 'complete' });
  } catch (error) {
    abort(error);
    try { journal.mark('run-finished', { status: 'failed' }); } catch {}
    process.exitCode = 1;
  } finally {
    resources?.stop();
    if (registry) { try { await closeRegistry(registry, journal, 'emergency'); } catch { process.exitCode = 1; } }
    for (const secretFile of secretFiles) { try { await rm(secretFile, { force: true }); } catch { process.exitCode = 1; } }
    process.off('SIGINT', onInterrupt); process.off('SIGTERM', onTerminate);
    journal.close();
  }
}

main().catch(() => { try { process.stderr.write('startup probe failed before journal completion\n'); } catch {} process.exitCode = 1; });

