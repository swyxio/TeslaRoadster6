import {test} from 'node:test';
import assert from 'node:assert/strict';
import {NEUTRAL} from './baseline/shared/game';
import {ScheduledInput as Baseline,type InputCommand} from './baseline/shared/tick-input';
import {ScheduledInput as Widened} from './experimental/shared/tick-input';

// A measured archived rejection. The timestamps, previous
// commands, input level, exact server tick and watchdog state were NOT retained.
const observed={seq:232,targetTick:220,lastTickAtSend:212,lastTickAtReply:224};
const cmd=(seq:number,targetTick:number,fields:Partial<typeof NEUTRAL>={},controlRevision=0,actionSeq=0):InputCommand=>
  ({seq,targetTick,controlRevision,actionSeq,input:{...NEUTRAL,...fields}});
function prime<S extends Baseline|Widened>(scheduler:S):S {
  assert.deepEqual(scheduler.receive(cmd(231,220,{throttle:.5}),219,5000),{outcomes:[]});
  for(let tick=220;tick<=224;tick++)scheduler.advance(tick,5000+(tick-219)*50);
  return scheduler;
}

test('the captured max-lead shape rejects at the minimum compatible receive tick, even with a live watchdog',()=>{
  assert.equal(observed.targetTick-observed.lastTickAtSend,8);
  assert.equal(observed.lastTickAtReply-observed.targetTick,4);
  const scheduler=prime(new Baseline(NEUTRAL));
  const result=scheduler.receive(cmd(observed.seq,observed.targetTick,{throttle:1}),observed.lastTickAtReply,5250);
  assert.equal(result.rejection,'late');
  assert.equal(scheduler.snapshot().appliedSeq,231);
  assert.ok(!scheduler.snapshot().queued.some(item=>item.seq===observed.seq));
});

test('counterfactual four-tick retiming changes this outcome only while the watchdog remains armed',()=>{
  const scheduler=prime(new Widened(NEUTRAL));
  const accepted=scheduler.receive(cmd(232,220,{throttle:1}),224,5250);
  assert.equal(accepted.retimedTargetTick,225);
  assert.equal(scheduler.advance(225,5300).input.throttle,1);
  assert.equal(scheduler.snapshot().appliedSeq,232);
  assert.equal(scheduler.advance(226,5301).input.throttle,0,'retiming cannot extend the original watchdog');
  assert.equal(scheduler.receive(cmd(233,220,{throttle:1}),226,5302).rejection,'late','late controls cannot rearm it');
});

test('a newer release removes the retimed throttle before application',()=>{
  const scheduler=prime(new Widened(NEUTRAL));
  assert.equal(scheduler.receive(cmd(232,220,{throttle:1}),224,5250).retimedTargetTick,225);
  assert.equal(scheduler.receive(cmd(233,220),224,5251).retimedTargetTick,225);
  assert.deepEqual(scheduler.snapshot().queued.map(item=>item.seq),[233]);
  assert.equal(scheduler.advance(225,5299).input.throttle,0);
});

test('edges keep the original target, expire, and cannot replay through a later heartbeat',()=>{
  const scheduler=prime(new Widened(NEUTRAL));
  const result=scheduler.receive(cmd(232,220,{throttle:1,jump:1,flip:1}),224,5250);
  assert.equal(result.retimedTargetTick,225);
  assert.deepEqual(result.outcomes.map(x=>[x.kind,x.status]),[['jump','expired'],['flip','expired']]);
  assert.equal(scheduler.advance(225,5299).input.jump,0);
  const repeat=scheduler.receive(cmd(233,226,{throttle:1,jump:1,flip:1}),225,5299);
  assert.deepEqual(repeat.outcomes,[]);
  const step=scheduler.advance(226,5300);assert.equal(step.input.jump,0);assert.equal(step.input.flip,0);
});

test('relocation revision and action mismatch continue to fence a four-tick-late frame',()=>{
  const relocation=new Widened(NEUTRAL);
  relocation.invalidate(NEUTRAL,{type:'relocation'});
  assert.deepEqual(relocation.receive(cmd(231,220,{},1),219,5000),{outcomes:[]});
  const old=relocation.receive(cmd(232,220,{throttle:1,jump:1},0),224,5250);
  assert.equal(old.rejection,'revision');assert.equal(old.outcomes[0].status,'expired');
  assert.equal(relocation.snapshot().queued.some(item=>item.seq===232),false);
  const action=prime(new Widened(NEUTRAL));assert.equal(action.beginAction(1,{jump:0,flip:0}),true);
  assert.equal(action.receive(cmd(232,220,{throttle:1},0,0),224,5250).rejection,'action');
});

test('counterexample: a live watchdog does not bound the age of the frame being retimed',()=>{
  // Hypothetical queued/bunched delivery, not observed in the archive. The
  // client sent in order; original send times are absent from the protocol.
  const priorSentAt=1000,staleSentAt=1050,releaseSentAt=1100,priorReceivedAt=5000,staleReceivedAt=5250;
  assert.ok(staleSentAt>priorSentAt&&releaseSentAt>staleSentAt);
  assert.ok(staleReceivedAt-staleSentAt>300);
  const scheduler=prime(new Widened(NEUTRAL));
  assert.equal(scheduler.receive(cmd(232,220,{throttle:1}),224,staleReceivedAt).retimedTargetTick,225);
  assert.equal(scheduler.advance(225,priorReceivedAt+300).input.throttle,1);
  // A later user release is still in flight: the server has no evidence of it.
});
