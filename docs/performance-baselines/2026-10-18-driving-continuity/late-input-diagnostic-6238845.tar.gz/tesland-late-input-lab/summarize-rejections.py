#!/usr/bin/env python3
"""Aggregate archived reports; no room/client identifiers are emitted."""
import collections
import gzip
import hashlib
import json
import pathlib
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: python3 summarize-rejections.py REPORT_DIRECTORY')
root = pathlib.Path(sys.argv[1])
paths = sorted(root.glob('group-*.json.gz'))
if len(paths) != 4:
    raise SystemExit(f'expected 4 reports, found {len(paths)}')
expected_candidate = '623884560ed3d902090c36ff04b790d1c714bb84'
late, reasons = [], collections.Counter()
for path in paths:
    with gzip.open(path, 'rt', encoding='utf-8') as handle:
        report = json.load(handle)
    if report.get('candidateSha') != expected_candidate:
        raise SystemExit(f'wrong candidate in {path.name}')
    for item in report['rejections']:
        if item.get('sendPhase') != 'measured':
            continue
        reasons[item['reason']] += 1
        if item['reason'] == 'late':
            required = ('targetTick', 'lastTickAtSend', 'lastTickAtReceive')
            if any(type(item.get(key)) is not int for key in required):
                raise SystemExit(f'missing/invalid tick in {path.name}')
            late.append(item)
lead = collections.Counter(x['targetTick'] - x['lastTickAtSend'] for x in late)
reply_gap = collections.Counter(x['lastTickAtReceive'] - x['targetTick'] for x in late)
maximum = [x for x in late if x['targetTick'] - x['lastTickAtSend'] == 8]
maximum_beyond_two = [x for x in maximum if x['lastTickAtReceive'] - x['targetTick'] > 2]
output = {
    'candidate_sha': expected_candidate,
    'report_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
    'measured_rejections_by_reason': dict(sorted(reasons.items())),
    'late_lead_ticks': dict(sorted(lead.items())),
    'late_observed_reply_snapshot_minus_target_ticks': dict(sorted(reply_gap.items())),
    'late_at_maximum_lead_8': len(maximum),
    'late_at_maximum_lead_and_reply_snapshot_more_than_2_past_target': len(maximum_beyond_two),
    'late_reply_snapshot_more_than_2_past_target': sum(n for gap,n in reply_gap.items() if gap > 2),
}
print(json.dumps(output, indent=2))
