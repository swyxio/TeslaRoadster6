# Late-input diagnostic — unsafe counterfactual, not shipped

This is an isolated reproduction and evidence bundle, not a release patch. It does not establish a safe fix or prove 64-driver capacity. Do not apply `COUNTERFACTUAL-UNSAFE.patch`: accepting more late levels expands stale-throttle behavior, and a user release may still be in flight. No production or shared checkout files were edited.

## Source and evidence

The hosted 64-Session diagnostic targeted candidate `623884560ed3d902090c36ff04b790d1c714bb84`, run `39180414284`. The four full reports are retained separately at `/private/tmp/tesland-throughput-lab/hosted-6238845-39180414284/reports/`. `logs/rejection-summary-original.json` hashes those originals. The bundled `sanitized-reports/` retains only candidate SHA and measured rejection reason, target tick, last snapshot tick at send and at rejection callback, and send phase. It removes room, player and run-specific driver identifiers and timestamps. Its four files reproduce the aggregate calculations in `logs/rejection-summary.json`; the original report checksums necessarily differ.

`baseline/` contains frozen `shared/` and `tests/tick-input.test.ts` from `af54fbede2977bcc9dfaaf970e45f98b338520a3`. The scheduler, motion-clock and session files at that commit are identical to candidate `6238845`. `provenance/` contains the exact candidate's motion clock, session and Worker entry, plus the archived diagnostic observer. The baseline scheduler SHA-256 is `b55ee884d67d42aea0a0cd4b3bf60d58a6f664c1a5dba7d893e0ad6276819c93`. Baseline test SHA-256 is `bc125d61148d84851beb5c77ad769e2de2f4a96599c9df785963dae9901e68b0`. `experimental/` differs from baseline only by the documented two-to-four-tick counterfactual in the patch. The test file models the reported target/snapshot shape but chooses a plausible server tick, prior control and watchdog state: those were not recorded in the run.

The run used four independent generators and 64 normal city spawns, which can obstruct each other. Every client connected and applied some input; 25 traveled less than one meter, only three completed any ten-second movement block, and no driver completed all six. It is a diagnostic of that older candidate, not a release gate pass. A one-second rejection drain can omit late replies, so these are observed counts, not all possible rejections.

## Exact 274/93 derivation and limits

From the four reports, select `sendPhase == "measured"` and `reason == "late"`: 1,326 records (eight measured revision rejections are separate). Of the 1,326, 274 have `targetTick - lastTickAtSend == 8`, the client's maximum lead over its last accepted snapshot; its clock clamps to `lastSnapshot + FUTURE_TICKS`, and the server has an eight-tick future window. Of those 274, 93 also have `lastTickAtReceive - targetTick > 2`, exceeding the current two-tick late-level retiming window. Across all late records, 134 have this latter property. Distributions and original report hashes are in the summary logs.

The >2 deduction assumes ordered delivery on the same WebSocket, the same room epoch, and monotonic server tick. The observer updates `lastTick` on the Session's successful snapshot clock observation, and records it when the rejection callback executes; the Worker sends the rejection synchronously in the control handler. Under those assumptions that last received snapshot tick is a lower bound on the tick at which the server rejected the input, not the exact receive tick. Consequently increasing client lead **within the existing eight-tick cap** cannot explain away those 93 rejections. This does not prove exactly which physical delay or throughput bottleneck caused them, nor show what the input level was or whether the watchdog was armed. Server receive ticks, original control payloads and packet ages were not retained. Rejection reply delay combines transit and processing and is not a measured one-way packet age. Snapshots observed below target in 225 cases further illustrate that a reply-side snapshot is not the receive tick.

## Safety counterexample

The six focused tests show the archived tick shape rejected by the current scheduler even with a live watchdog; they also explore a hypothetical four-tick window. In an explicitly synthetic common timeline, the client sends prior throttle at 1,000 ms, stronger throttle at 1,050 ms and release at 1,100 ms. Ordered delivery delays the prior control until server time 5,000 ms, when its target is still in the future and it arms the receive-time watchdog. At 5,250 ms the next throttle arrives four ticks late; under the counterfactual it is retimed and can apply at 5,300 ms, while the release is still in flight. The frame's real send age exceeds 300 ms, but the only available watchdog age is 250 ms since an earlier server acceptance. The exactly-300-ms boundary remains armed because the implementation expires on `> 300`.

This constructed schedule is not claimed to have happened in the capture. A delayed prior control could already be accepted by the baseline while its target is future; the counterfactual specifically enlarges the set of late stale levels accepted. The current wire fields do not prove the actual age of an individual control or arrival of a later release. Experimental tests cover release replacement when it actually arrives, original edge targets/expiry and duplicate suppression, revision/action fences, and no watchdog refresh, but these do not eliminate the in-flight-release counterexample. A fresh-control protocol would require a separately verified time/freshness contract and edge, revision and watchdog tests; Cloudflare in-Worker clocks cannot be assumed to measure uninterrupted CPU wall time.

## Reproduce

Requires Python 3 and a checkout with the project's pnpm/tsx dependencies installed. These logs used Node v22.22.2 and pnpm 10.33.1. After extracting, set `LAB` to this directory. From an installed Tesland checkout:

```sh
LAB=/private/tmp/tesland-late-input-lab
python3 "$LAB/summarize-rejections.py" "$LAB/sanitized-reports"
pnpm exec tsx --test "$LAB/rejection-regression.test.ts"
pnpm exec tsx --test "$LAB/baseline/tests/tick-input.test.ts"
pnpm exec tsx --test "$LAB/experimental/tests/tick-input.test.ts"
```

Expected: aggregation 1,326 / 274 / 93, six focused tests pass, baseline 30/30 pass, and experimental 28/30 pass with two **expected failures** where the established contract rejects a level four ticks late. Logs include exit statuses and assertion details. Recompute against the unsanitized originals by passing their directory to the Python script; original reports are not included in this archive. A fresh hosted run, if authorized separately, will not reproduce exact counts because traffic, placement, timing and cloud execution differ.
