# Presentation contact follow-up lab, 2026-10-18

Status: EXPERIMENTAL; RELEASE BLOCKED. This contains diagnostics and research changes, not a release-ready patch. No deployment was made.

The base is d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31. Patch SHA-256: 2b11c7e3a5be2cf26119b0c47a890f102bf8a78ebe7da9bf106862304bf764f8. From a fresh archive of that base, `git apply -p2 tesland-presentation-contact-followup-20261018.patch`. The patch was applied cleanly to a fresh base archive and all 17 changed files compared byte-identical with the isolated lab `/private/tmp/tesland-presentation-contact-followup-20261018`.

With project dependencies available:

```
./node_modules/.bin/tsx --test --test-concurrency=1 tests/session-motion.test.ts tests/remote-presentation.test.ts tests/tick-prediction.test.ts tests/motion-clock.test.ts tests/presentation-contact.test.ts tests/building-sweep-proofs.test.ts
./node_modules/.bin/tsc --noEmit
```

The above scoped run had 130/131 passing; the remaining failure is a short authoritative teleport being mistaken for continuous peer motion. The pinned-wall jump now passes using an experimental swept-building check and tiny contact projection. The scoped command did not include `tests/building-sweep-lab.test.ts`: that earlier safety test requires blocking a physically clear 0.0001 m near-wall approach, whereas a later fixed-yaw SAT case accepts a comparable approach. A union run combining this patch with independently developed pose identity changes failed that older safety assertion; it must be reconciled without hiding or dropping either assertion. Do not represent 130/131 as a complete suite.

`tesland-playback-jump-deep-sweep.log` and its geometry log preserve a 4,883 ms intermediate failure: the previously displayed car was physically clear but naive extrapolation penetrated the building by 0.000776389 m. A ~0.001 m wall-normal proposal allowed separate static sweeps from both the prior pose and replay goal in that frame. `tesland-playback-jump-rebase.log` and geometry preserve the next 4,900 ms rebase failure, with 0.000936671 m naive endpoint penetration; the eventual lab adds the same tiny projection in both locations and proves both static sweeps before accepting a pose. The final pinned-wall test pass is in `tesland-playback-jump-projected-rebase2.log`. This is neither a proof of joint peer safety nor a measured runtime cost.

The moving-ferry tests establish zero hull-relative offset for two stationary passengers in synthetic departure/arrival cases, and a separate 600 ms fixture checks one unknown shore-braking action. The lab combines replayed hull x/z with latest phase, passenger membership, countdown and arrivals, and rigidly translates other ferry-supported occupants. Actual scene smoothing, gate timing, moving passengers, boarding and disembark remain unverified. Endpoint-only peer checks cannot prove swept 3-D pair safety. Float margins and deeper subdivision cost are also unverified.

A separate planar-only interval proof exists at `/private/tmp/tesland-peer-sweep-proof-20261018` and archive `/private/tmp/tesland-peer-sweep-proof-20261018.tar.gz`. It is not integrated into this patch and is not a complete motion gate.
