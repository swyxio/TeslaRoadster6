import {readFileSync} from 'node:fs';
import {terrainHeight} from '/private/tmp/tesland-ferry-timeline-20261018/shared/map';
import {ferryDocked,onFerryDeck} from '/private/tmp/tesland-ferry-timeline-20261018/shared/ferry';
const rows=readFileSync('/private/tmp/tesland-matched-driving-20261018/evidence/confirmed-ferry-candidate.jsonl','utf8').trim().split('\n').map(x=>JSON.parse(x));
const bad:any[]=[];
for(const row of rows)for(const e of row.world.entities){
 const ground=e.supportId==='ground'&&terrainHeight(e.x,e.z)===null;
 const ferry=e.supportId==='ferry'&&ferryDocked(row.world.ferry)&&!onFerryDeck(row.world.ferry,e.x,e.z);
 if(ground||ferry)bad.push({now:row.now,tick:row.tick,before:row.before,after:row.after,alpha:row.alpha,id:e.id,support:e.supportId,x:e.x,z:e.z,ferryPhase:row.world.ferry.phase,terrain:terrainHeight(e.x,e.z),unavailable:row.unavailable});
}
console.log(JSON.stringify({frames:rows.length,invalidSupportOccurrences:bad.length,first:bad.slice(0,5)},null,2));
