import {readFileSync,writeFileSync} from 'node:fs';
const source=JSON.parse(readFileSync(process.argv[2],'utf8'));
if(source.scenario!=='peer-fifo')throw new Error('only the retained peer fixture may be augmented');
const initial=JSON.parse(source.initialRaw);
const ids=initial.world.entities.map(entity=>entity.id);
if(ids.length!==2||new Set(ids).size!==2)throw new Error('expected exactly two stable entity identities');
const token=new Map(ids.map((id,index)=>[id,index+1]));
const augment=world=>{
  if(world.entities.length!==2||world.entities.some(entity=>!token.has(entity.id)))throw new Error('entity roster changed');
  world.nextPresentationIncarnation=3;
  for(const entity of world.entities){entity.presentationIncarnation=token.get(entity.id);entity.presentationRevision=0;}
};
const packet=raw=>{const value=JSON.parse(raw);augment(value.world);return JSON.stringify(value);};
source.initialRaw=packet(source.initialRaw);
for(const world of source.authority)augment(world);
for(const plan of source.plans)for(const event of plan.events)event.raw=packet(event.raw);
writeFileSync(process.argv[3],JSON.stringify(source));
