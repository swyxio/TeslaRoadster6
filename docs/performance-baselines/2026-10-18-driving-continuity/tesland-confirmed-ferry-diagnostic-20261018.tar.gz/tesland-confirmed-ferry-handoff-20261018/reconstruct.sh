#!/bin/sh
set -eu
TASK_HANDOFF=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TASK_WORK_DIR=${1:-/tmp/tesland-confirmed-ferry-reproduction}
if [ -e "$TASK_WORK_DIR" ]; then
  printf 'Refusing to overwrite existing path: %s\n' "$TASK_WORK_DIR" >&2
  exit 1
fi
mkdir -p "$TASK_WORK_DIR/main" "$TASK_WORK_DIR/candidate" "$TASK_WORK_DIR/token"
tar -xzf "$TASK_HANDOFF/source/e07f0be.tar.gz" -C "$TASK_WORK_DIR/main"
tar -xzf "$TASK_HANDOFF/source/020f25b.tar.gz" -C "$TASK_WORK_DIR/candidate"
tar -xzf "$TASK_HANDOFF/source/020f25b.tar.gz" -C "$TASK_WORK_DIR/token"
cp "$TASK_HANDOFF/evidence/matched-peer-trace.lab.ts" "$TASK_WORK_DIR/main/tests/"
cp "$TASK_HANDOFF/evidence/matched-peer-trace.lab.ts" "$TASK_WORK_DIR/candidate/tests/"
git -C "$TASK_WORK_DIR/token" apply "$TASK_HANDOFF/evidence/token-prototype-from-clean.patch"
git -C "$TASK_WORK_DIR/token" apply "$TASK_HANDOFF/evidence/confirmed-ferry-diagnostic.patch"
printf 'Reconstructed clean source and isolated diagnostic at %s\n' "$TASK_WORK_DIR"
