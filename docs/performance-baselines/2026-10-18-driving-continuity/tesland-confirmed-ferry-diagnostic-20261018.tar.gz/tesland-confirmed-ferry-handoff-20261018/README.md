# Tesland matched continuity and ferry diagnostics

**Unavailable as a fix. Do not merge or deploy these experiments.** All captured fixtures and driver IDs are synthetic; the logs contain no production sessions, credentials, recovery codes or identity records. Source archives contain the exact tracked code and configs needed for these focused tests; large media and dependencies are not bundled. The patches and logs preserve failing assertions.

- `source/e07f0be.tar.gz`: tracked-code subset of baseline e07f0bec4e62737fedcfc72ab9714f4dd4e7a1bf, wire v48.
- `source/020f25b.tar.gz`: tracked-code subset of integrated candidate 020f25b40696608e7e7285fc74adf6f52c4c3d42, wire v49.
- `evidence/token-prototype-from-clean.patch`: unsafe identity/history experiment on 020f25b, wire v50.
- `evidence/confirmed-ferry-diagnostic.patch`: confirmed-only ferry/scene diagnostic on that token experiment, not an accepted safety implementation.
- `evidence/confirmed-ferry-diagnostic-notes.md`: exact test commands, results, interpretation and limitations.
- `evidence/peer-fixture.json` and `peer-{baseline,candidate}.json`: original matched synthetic FIFO trace, identical state packet bytes and input timings; only the welcome protocol differs. Both revisions snap before impact. `peer-token-fixture.json` is a separately augmented packet fixture and must not be conflated with the original comparison.
- `evidence/{candidate,token}-pinned-scheduled.*`: identical-timing synthetic real-ScheduledInput wall scenario; both reproduce late-input rejections. Other files include strict failed logs, full frame traces, controls, outcomes and seam audits.

To reconstruct without any source repository:

```
./reconstruct.sh /tmp/tesland-confirmed-ferry-reproduction
cd /tmp/tesland-confirmed-ferry-reproduction/token
pnpm install --frozen-lockfile
CONFIRMED_FERRY_TRACE_PATH=/tmp/confirmed-ferry-candidate.jsonl ./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/confirmed-ferry-candidate.lab.test.ts
CONFIRMED_FERRY_TRACE_PATH=/tmp/confirmed-ferry-seam.jsonl ./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/confirmed-ferry-seam.lab.test.ts
TRACE_PATH=/tmp/confirmed-ferry-responsiveness.json ./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/confirmed-ferry-responsiveness.lab.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/confirmed-ferry-scene.lab.test.ts tests/confirmed-ferry-contract.lab.test.ts
```

All four commands retain expected failures, explained in the notes. `CONFIRMED_FERRY_TRACE_PATH` is appended to, so use a fresh filename. Test-only diagnostics intentionally inspect candidates whose safety status is unavailable; their snap oracle is a >1 m candidate-step detector, and some unchanged assertions reflect the original Session predictor rather than the candidate. The moving hull test uses Three.js vector placement math, not a real browser. These are functional tests, not performance or device evidence.

For matched comparison, install dependencies in `main` and `candidate`, then run the following from each checkout, using the same absolute `peer-fixture.json` and distinct output files:

```
./node_modules/.bin/tsx tests/matched-peer-trace.lab.ts replay peer-fifo /ABSOLUTE/HANDOFF/evidence/peer-fixture.json /tmp/peer-output.json
```

The handshake version is read from each revision; raw state packets, inputs and timings are shared. To run the augmented v50 fixture use the `token` checkout and `peer-token-fixture.json` instead. The 20 Hz authority / 120 Hz rendering FIFO fixture is deterministic synthetic stress; it is not a live Worker, browser, load or physical-device run. The user skipped the physical mobile gate; it did not pass.

Reconstruction was checked from this bundle: both original paired replay JSON files matched the included captures byte for byte, the four diagnostic contract checks passed, and `tsc --noEmit` passed using the existing project dependency installation. Package checksums are in `SHA256SUMS`.
