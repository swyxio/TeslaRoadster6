# ACK observer evidence

Packaged 2026-10-19 UTC from the independent `/private/tmp/tesland-ack-observer` lab. The prototype, tests and patch were not applied to the release checkout. `hosted-ack-observer.patch` adds the three included `diagnostic-lab/` files; it does not integrate the observer into a client or room.

The older hosted diagnostic checkout used for dependency resolution was at Git HEAD `a53d0998ef83ead142ca498d6bfbedc57d628c65`; its gameplay candidate was `623884560ed3d902090c36ff04b790d1c714bb84`. That diagnostic checkout also had staged and unstaged lab changes and a `node_modules` symlink; it was not clean. The observer itself has no game-source imports. The final release source, assets, provider bindings, Durable Object isolation, and exact Session protocol have not been checked by this archive. The old hosted fixture still imports an earlier movement tracker and must use the final corrected tracker before future diagnostics.

On 2026-10-19 UTC, the archived copies were tested from the older diagnostic checkout using Node `v22.22.2`, pnpm `10.33.1`, TypeScript `5.9.3`, and tsx `4.23.15`. The following commands used the package's files:

```sh
pnpm exec tsx --test /private/tmp/tesland-ack-evidence-20261019/diagnostic-lab/ack-observer.test.ts
pnpm exec tsc --noEmit --target ES2022 --module ESNext --moduleResolution Bundler --skipLibCheck --types node /private/tmp/tesland-ack-evidence-20261019/diagnostic-lab/ack-observer.ts /private/tmp/tesland-ack-evidence-20261019/diagnostic-lab/ack-observer.test.ts
git apply --check /private/tmp/tesland-ack-evidence-20261019/hosted-ack-observer.patch
```

See `logs/` for exit statuses and test output. Dependency installation, a Worker, a hosted run, load, browser capture, deployment and production writes were not performed as part of this package. No credentials, state directories, runtime data or `node_modules` are included. Reproduction requires the compatible lockfile dependencies from the recorded checkout or final candidate; those are not bundled.

**Sustained acknowledgement remains unmeasured.** This is a unit-tested observer prototype, not a release checker pass. Exact frame-to-Session acceptance instrumentation and an integration test remain required; the old collector's deferred mutable prediction lookup can associate the wrong state with an arrival time. The measured values are observed send-to-snapshot upper bounds only, with no release latency threshold. Its completeness policy and coverage, memory and observer-cost limitations are in `diagnostic-lab/ACK-OBSERVER-README.md`.
