# Unshipped 1.8 s burst diagnostic

This package is experimental evidence, not a deployable fix. Starting base commit: `d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31`. In a fresh isolated checkout of that commit, apply `combined-lab-base.patch`, then `burst-diagnostic-incremental.patch` with `git apply`. The separate focused test file is identical to the new test in the incremental patch. Use matching project dependencies and run:

```
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/burst-continuity-lab.test.ts
```

The larger (32-snapshot) bounded histories avoid disconnect in these fixtures, but steering fails to respond during the blackout and an interacting peer makes a 19.73 m cut. Two tests fail; a third confirms clear endpoint contact cannot prove a swept path safe. These are functional simulations, not a browser, performance, or production-capacity result. `NOTES.md` explains the measurements, proposed contract and remaining proof gaps. The output intentionally contains diagnostic console lines.
