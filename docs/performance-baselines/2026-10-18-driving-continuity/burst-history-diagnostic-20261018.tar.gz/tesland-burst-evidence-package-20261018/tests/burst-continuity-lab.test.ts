import test from 'node:test';
import assert from 'node:assert/strict';
import {addPlayer,createEmptyWorld,makeEntity,NEUTRAL,PROTOCOL_VERSION,step,type Entity} from '../shared/game';
import {body,contact} from '../shared/physics';
import {ScheduledInput} from '../shared/tick-input';
import {Session} from '../src/session';
import {presentedContact} from '../src/presentation-contact';

class Socket {
  static OPEN=1;static last:Socket;readyState=Socket.OPEN;sent:string[]=[];
  onmessage?: (event:{data:string})=>void;onclose?: (event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}
  send(value:string){this.sent.push(value);}
  close(){this.readyState=3;}
  message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});

function exercise(headOn:boolean){
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');if(headOn)addPlayer(world,'q','Peer');world.pickups=[];
  const local=world.entities.find(e=>e.driver==='p')!,peer=world.entities.find(e=>e.driver==='q');
  world.entities=peer?[local,peer]:[local];
  Object.assign(local,{x:-400,z:-2050,y:0,yaw:-Math.PI/2,speed:50,vx:50,vz:0,supportId:'ground'});
  if(peer)Object.assign(peer,{x:-240,z:-2050,y:0,yaw:Math.PI/2,speed:50,vx:-50,vz:0,supportId:'ground'});
  const initial={...NEUTRAL,throttle:1},scheduler=new ScheduledInput(NEUTRAL);
  const packet=(tick:number)=>({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:scheduler.snapshot(),poseRevision:0,substeps:5});
  socket.message(packet(0));let tick=0,disconnectAt:number|null=null,exhaustAt:number|null=null,last:Entity|undefined,lastPeer:Entity|undefined;
  let maxStep=0,maxPeerStep=0,maxDepth=0,longest=0,overlap=0,yawBefore=0,yawAfter=0,authorityImpact=false,processed=0,sentAtPress=0,sentAtRelease=0;
  const queue:unknown[]=[];
  for(let frame=0;frame<=600;frame++){
    now=frame*1000/120;
    const input={...initial,steer:!headOn&&now>=800&&now<1200?1:0};
    while(processed<socket.sent.length){
      const command=JSON.parse(socket.sent[processed++]);
      if(command.type==='input'){
        const result=scheduler.receive(command,tick,now);
        if(result.rejection)socket.message({type:'inputRejected',seq:command.seq,reason:result.rejection});
      }
    }
    while((tick+1)*50<=now+1e-8){
      tick++;const applied=scheduler.advance(tick,now).input;
      step(world,new Map(peer?[['p',applied],['q',initial]]:[['p',applied]]),.05,{substeps:5});
      authorityImpact ||= local.health<100;
      if(tick%2===0){if(tick*50<=1800)queue.push(packet(tick));else socket.message(packet(tick));}
    }
    if(now>=1800)while(queue.length)socket.message(queue.shift());
    session.tick(1/120,input);const displayed=session.renderWorld(),shown=displayed.entities.find(e=>e.driver==='p')!;
    const other=displayed.entities.find(e=>e.driver==='q');
    if(session.status!=='online'&&disconnectAt===null)disconnectAt=now;
    if(session.presentationHistoryExhausted&&exhaustAt===null)exhaustAt=now;
    if(frame===96){yawBefore=shown.yaw;sentAtPress=socket.sent.map(value=>JSON.parse(value)).filter(message=>message.type==='input').length;}
    if(frame===103)yawAfter=shown.yaw;
    if(frame===144)sentAtRelease=socket.sent.map(value=>JSON.parse(value)).filter(message=>message.type==='input').length;
    if(last)maxStep=Math.max(maxStep,Math.hypot(shown.x-last.x,shown.y-last.y,shown.z-last.z));
    if(other&&lastPeer){
      const peerStep=Math.hypot(other.x-lastPeer.x,other.y-lastPeer.y,other.z-lastPeer.z);
      if(peerStep>maxPeerStep){
        maxPeerStep=peerStep;
        if(peerStep>1)console.log('BURST_PEER_CUT',JSON.stringify({now,from:lastPeer.x,to:other.x,latest:session.world.entities.find(e=>e.driver==='q')?.x,local:shown.x,active:session.localPresentationActive,remoteActive:session.remotePresentationActive,localHeld:Reflect.get(Reflect.get(session,'prediction'),'presentationHeld'),queued:Reflect.get(Reflect.get(session,'prediction'),'snapshots')?.length}));
      }
    }
    const hit=other&&contact(body(shown),body(other));
    if(hit){maxDepth=Math.max(maxDepth,hit.depth);overlap++;longest=Math.max(longest,overlap);}else overlap=0;
    last=shown;lastPeer=other;
  }
  const result={headOn,disconnectAt,exhaustAt,maxStep,maxPeerStep,maxDepth,longest,yawBefore,yawAfter,authorityImpact,sentAtPress,sentAtRelease};
  console.log('BURST_RESULT',JSON.stringify(result));session.disconnect();return result;
}

test('1.8 s FIFO burst keeps free travel online and responds to steering within a step',()=>{
  const r=exercise(false);
  assert.equal(r.disconnectAt,null);assert.equal(r.exhaustAt,null);assert.ok(r.maxStep<1,`visual step ${r.maxStep} m`);
  assert.ok(Math.abs(r.yawAfter-r.yawBefore)>1e-4,'steering pressed during the outage visibly affects motion');
});

test('1.8 s FIFO burst keeps a head-on contact online and on a safe visual timeline',()=>{
  const r=exercise(true);
  assert.equal(r.authorityImpact,true);assert.equal(r.disconnectAt,null);assert.equal(r.exhaustAt,null);
  assert.ok(r.longest<=3,`overlap ${r.longest} frames`);assert.ok(r.maxDepth<.05,`depth ${r.maxDepth} m`);
  assert.ok(r.maxStep<1,`local step ${r.maxStep} m`);assert.ok(r.maxPeerStep<1,`peer step ${r.maxPeerStep} m`);
});

// Endpoints alone cannot establish that a 19 m display correction avoids a body.
test('a long peer correction can cross a body with clear endpoint contacts',()=>{
  const {ferry}=createEmptyWorld(),local=makeEntity('local','model-3',-250,-2050);
  const before=makeEntity('peer','model-3',-240,-2050),after={...before,x:-260};
  assert.equal(presentedContact(ferry,local,before),null);
  assert.equal(presentedContact(ferry,local,after),null);
  assert.ok(presentedContact(ferry,local,{...before,x:(before.x+after.x)/2}));
});
