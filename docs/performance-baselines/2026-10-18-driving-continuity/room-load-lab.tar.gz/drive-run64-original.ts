// Local-only 64-driver diagnostic; never call this a capacity pass.
// Start the isolated lab Worker first. Do not launch until a load window is reserved.
import { monitorEventLoopDelay } from 'node:perf_hooks';
import { RoomInputClient } from '../tesland-load-64-d05/tests/room-input-client';
import { movementTracker, inputCoverage } from '../tesland-load-64-d05/scripts/load-room';
import { FUTURE_TICKS } from '../tesland-load-64-d05/shared/tick-input';
import { PROTOCOL_VERSION, type World } from '../tesland-load-64-d05/shared/game';
import { driveControl } from './controller';
import report from './preflight-result.json';

const count=64,seconds=60,warmupMs=15_000;
type Car=World['entities'][number];
type Client={socket:WebSocket;input:RoomInputClient;id:string;car:Car|null;carAt:number;initialHealth:number|null;
  firstTime:number|null;lastTime:number|null;lastSnapshot:number;seenPlayers:number;snapshots:number;sent:number;closed:boolean;
  distance:ReturnType<typeof movementTracker>;queues:{samples:number;levels:number;jumpEdges:number;flipEdges:number};
  maxDrift:number;maxSpeed:number;maxProgress:number;minOtherDistance:number|null;damageObserved:boolean;impulseObserved:boolean;
  pending:Map<number,number>;droppedPending:number;lastReceived:number;lastApplied:number};
const delay=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
const percentile=(values:number[],p:number)=>values.length?[...values].sort((a,b)=>a-b)[Math.min(values.length-1,Math.floor(values.length*p))]:null;

async function main(){
  const base=process.argv[2]??'http://127.0.0.1:19881',url=new URL(base),secret=process.env.LAB_STAGE_SECRET;
  if(url.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(url.hostname))throw new Error('Lab runner permits loopback HTTP only');
  if(!secret||!/^[0-9a-f]{64}$/i.test(secret))throw new Error('LAB_STAGE_SECRET must be 64 hex characters');
  const health=await (await fetch(base+'/api/health')).json() as {version:number;capacity:number};
  if(health.version!==PROTOCOL_VERSION||health.capacity!==64)throw new Error(`Wrong lab protocol/capacity: ${JSON.stringify(health)}`);
  const room=`lab-${Date.now().toString(36)}`,wsUrl=base.replace(/^http/,'ws')+'/api/room/'+room;
  const clients:Client[]=[],loop=monitorEventLoopDelay({resolution:20}),receivedDelays:number[]=[],appliedDelays:number[]=[],gaps:number[]=[];
  let measuring=false,measurementStart=0,bytes=0,sent=0,keepalive:ReturnType<typeof setInterval>|undefined,driving:ReturnType<typeof setInterval>|undefined;
  const headers={Authorization:`Bearer ${secret}`};
  try{
    // Identity heartbeats prevent the production 30-second inactivity fence
    // firing during a slow sequential setup; controls stay neutral until begin.
    let heartbeatRequest=1000;
    keepalive=setInterval(()=>{for(const client of clients)if(client.socket.readyState===WebSocket.OPEN)
      client.socket.send(JSON.stringify({type:'identity',code:null,requestId:heartbeatRequest++}));},5000);
    for(let index=0;index<count;index++)await new Promise<void>((resolve,reject)=>{
      const socket=new WebSocket(wsUrl),input=new RoomInputClient(socket);
      const client:Client={socket,input,id:'',car:null,carAt:0,initialHealth:null,firstTime:null,lastTime:null,lastSnapshot:0,
        seenPlayers:0,snapshots:0,sent:0,closed:false,distance:movementTracker(seconds*1000),
        queues:{samples:0,levels:0,jumpEdges:0,flipEdges:0},maxDrift:0,maxSpeed:0,maxProgress:0,minOtherDistance:null,
        damageObserved:false,impulseObserved:false,pending:new Map(),droppedPending:0,lastReceived:0,lastApplied:0};
      clients.push(client);let joined=false;
      const timer=setTimeout(()=>reject(new Error(`Driver ${index} join timed out`)),15000);
      socket.addEventListener('error',()=>{if(!joined){clearTimeout(timer);reject(new Error(`Driver ${index} connection failed`));}});
      socket.addEventListener('close',()=>{client.closed=true;if(!joined){clearTimeout(timer);reject(new Error(`Driver ${index} closed before staging`));}});
      socket.addEventListener('message',event=>{
        const raw=String(event.data),message=JSON.parse(raw) as {type:string;id?:string;version?:number;playtestMode?:string|null;tick:number;poseRevision:number;world?:World};
        input.observe(message);
        if(message.type==='welcome'){
          if(message.version!==PROTOCOL_VERSION||message.playtestMode!==null){clearTimeout(timer);reject(new Error(`Driver ${index} not in normal lab room`));return;}
          client.id=message.id??'';socket.send(JSON.stringify({type:'identity',code:null,requestId:1}));
        }
        if(message.type!=='state'||!message.world)return;
        const now=performance.now(),world=message.world,player=world.players.find(item=>item.id===client.id);
        const car=world.entities.find(item=>item.id===player?.entityId&&item.driver===client.id)??null;
        if(car){client.car=car;client.carAt=now;}
        if(!joined&&input.active&&message.poseRevision>0&&car?.x===report.poses[index].x&&car.z===report.poses[index].z){
          joined=true;clearTimeout(timer);resolve();
        }
        if(!measuring)return;
        if(client.lastSnapshot)gaps.push(now-client.lastSnapshot);
        client.lastSnapshot=now;client.snapshots++;client.seenPlayers=world.players.length;bytes+=Buffer.byteLength(raw);
        client.firstTime??=world.time;client.lastTime=world.time;
        client.distance.observe({atMs:now-measurementStart,tick:message.tick,poseRevision:message.poseRevision,vehicle:car});
        const control=input.control;
        if(control){
          client.queues.samples++;client.queues.levels=Math.max(client.queues.levels,control.queued.length);
          client.queues.jumpEdges=Math.max(client.queues.jumpEdges,control.jump.pending.length);client.queues.flipEdges=Math.max(client.queues.flipEdges,control.flip.pending.length);
          for(const [kind,seq] of [['received',control.receivedSeq],['applied',control.appliedSeq]] as const){
            const last=kind==='received'?client.lastReceived:client.lastApplied,when=client.pending.get(seq);
            if(seq>last&&when!==undefined)(kind==='received'?receivedDelays:appliedDelays).push(now-when);
            if(kind==='received')client.lastReceived=Math.max(last,seq);else client.lastApplied=Math.max(last,seq);
          }
          for(const seq of client.pending.keys())if(seq<control.appliedSeq)client.pending.delete(seq);
        }
        if(car){
          client.initialHealth??=car.health;
          client.damageObserved||=car.health<client.initialHealth-.001;
          client.impulseObserved||=Math.hypot(car.pushX,car.pushZ)>.1;
          client.maxDrift=Math.max(client.maxDrift,Math.abs(car.x-report.poses[index].x));
          client.maxProgress=Math.max(client.maxProgress,report.startZ-car.z);
          client.maxSpeed=Math.max(client.maxSpeed,Math.abs(car.speed));
          for(const other of world.entities)if(other.id!==car.id){
            const d=Math.hypot(other.x-car.x,other.y-car.y,other.z-car.z);
            client.minOtherDistance=client.minOtherDistance===null?d:Math.min(client.minOtherDistance,d);
          }
        }
      });
    });
    const status=await (await fetch(`${base}/api/lab/status/${room}`,{headers})).json() as {ready:boolean;staged:{exact:boolean;economy:boolean}[]};
    if(!status.ready||status.staged.length!==count||status.staged.some(driver=>!driver.exact||!driver.economy))throw new Error('Lab did not stage 64 economy-enabled drivers');
    const revisions=clients.map(client=>client.input.control!.revision);
    const begin=await fetch(`${base}/api/lab/begin/${room}`,{method:'POST',headers});
    if(!begin.ok)throw new Error(`Lab begin rejected: ${begin.status}`);
    clearInterval(keepalive);keepalive=undefined;
    const revisionDeadline=performance.now()+5000;
    while(clients.some((client,i)=>(client.input.control?.revision??-1)<=revisions[i])){
      if(performance.now()>revisionDeadline)throw new Error('Did not receive all begin fences');
      await delay(20);
    }
    driving=setInterval(()=>{
      const now=performance.now();
      for(const client of clients)if(client.input.active&&!client.closed){
        const seq=client.input.send(driveControl(client.car?.speed??null,now-client.carAt));
        if(measuring){
          sent++;client.sent++;client.pending.set(seq,now);
          if(client.pending.size>256){client.pending.delete(client.pending.keys().next().value!);client.droppedPending++;}
        }
      }
    },50);
    await delay(warmupMs);
    const before=clients.map(client=>client.input.lastSeq);measurementStart=performance.now();measuring=true;loop.enable();
    await delay(seconds*1000);
    measuring=false;const elapsed=(performance.now()-measurementStart)/1000;loop.disable();
    const coverage=inputCoverage(clients.map((client,index)=>({lastSentBefore:before[index],applied:client.input.control?.appliedSeq??null,rejections:client.input.rejectionCount})));
    const movement=clients.map(client=>client.distance.summary());
    const advances=clients.map(client=>client.firstTime===null||client.lastTime===null?0:client.lastTime-client.firstTime);
    const incomplete:string[]=[];
    if(clients.some(client=>client.closed))incomplete.push('client-disconnected');
    if(clients.some(client=>client.seenPlayers!==count))incomplete.push('not-all-clients-observed');
    if(movement.some(result=>result.blocks.some(block=>!block.complete)))incomplete.push('not-all-drivers-sustained-moving');
    if(coverage.rejectedClients.length)incomplete.push('input-rejected');
    if(coverage.clientsWithoutAppliedInput.length)incomplete.push('missing-applied-input');
    if(clients.some(client=>!client.queues.samples))incomplete.push('missing-control-queue-observations');
    if(clients.some(client=>client.queues.levels>FUTURE_TICKS||client.queues.jumpEdges>FUTURE_TICKS||client.queues.flipEdges>FUTURE_TICKS))incomplete.push('sampled-control-queue-bound-exceeded');
    if(clients.some(client=>client.maxDrift>3||client.maxProgress>report.startZ-report.endZ))incomplete.push('corridor-exit-observed');
    if(clients.some(client=>client.droppedPending))incomplete.push('ack-observation-overflow');
    if(!appliedDelays.length)incomplete.push('no-observed-applied-ack-samples');
    if(Math.min(...advances)<57)incomplete.push('less-than-57-simulated-seconds');
    console.log(JSON.stringify({scope:'same-host local diagnostic, not capacity proof',room,clients:count,warmupSeconds:warmupMs/1000,elapsedSeconds:elapsed,
      simulatedSecondsMin:Math.min(...advances),snapshots:clients.reduce((sum,c)=>sum+c.snapshots,0),decodedJsonMiB:bytes/1048576,sentInputs:sent,
      rejections:clients.reduce((sum,c)=>sum+c.input.rejectionCount,0),...coverage,p95SnapshotGapMs:percentile(gaps,.95),maxSnapshotGapMs:gaps.length?Math.max(...gaps):null,
      receivedObservationDelayP95Ms:percentile(receivedDelays,.95),appliedObservationDelayP95Ms:percentile(appliedDelays,.95),
      receivedSamples:receivedDelays.length,appliedSamples:appliedDelays.length,clientEventLoopP95Ms:loop.percentile(95)/1e6,
      movement,drivers:clients.map(client=>({id:client.id,closed:client.closed,sent:client.sent,queues:client.queues,
        maxDrift:client.maxDrift,maxSpeed:client.maxSpeed,maxProgress:client.maxProgress,minOtherDistance:client.minOtherDistance,
        damageObserved:client.damageObserved,impulseObserved:client.impulseObserved,droppedPending:client.droppedPending})),
      diagnosticCoverageComplete:incomplete.length===0,incomplete,
      limitations:'Sampled damage, impulse and nearest entity are contact indicators, not substep contact counts. Control queue peaks between snapshots, browser prediction history, Worker CPU, WAN, GPU and physical-device behavior are not measured. Receive sequence can include rejected commands; ACK delays are for sequences actually observed in snapshots, not all sent commands. The 64 staged parallel off-road paths are not representative dense city driving.'},null,2));
  }finally{
    if(keepalive)clearInterval(keepalive);if(driving)clearInterval(driving);
    for(const client of clients)if(client.socket.readyState===WebSocket.OPEN)client.socket.close();
  }
}

void main().catch(error=>{console.error(error);process.exitCode=1;});
