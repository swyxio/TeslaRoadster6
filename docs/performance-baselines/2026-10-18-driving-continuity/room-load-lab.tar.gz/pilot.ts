// Two clients, eight seconds of driving. Functional check only; not capacity.
import assert from 'node:assert/strict';
import { RoomInputClient } from '../tesland-load-64-d05/tests/room-input-client';
import { PROTOCOL_VERSION, type World } from '../tesland-load-64-d05/shared/game';
import { driveControl } from './controller';
import report from './preflight-result.json';
const base='http://127.0.0.1:19891',secret='a'.repeat(64),room=`lab-pilot-${Date.now().toString(36)}`;
const sockets:WebSocket[]=[],inputs:RoomInputClient[]=[],ids:string[]=[],cars:(World['entities'][number]|null)[]=[null,null],carAt=[0,0],snapshots=[0,0];
const delay=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
async function main(){
  let timer:ReturnType<typeof setInterval>|undefined;
  try {
    for(let i=0;i<2;i++)await new Promise<void>((resolve,reject)=>{
      const socket=new WebSocket(base.replace('http','ws')+'/api/room/'+room),input=new RoomInputClient(socket);
      sockets.push(socket);inputs.push(input);let joined=false;
      const timeout=setTimeout(()=>reject(new Error(`Driver ${i} timed out`)),15000);
      socket.addEventListener('error',()=>{clearTimeout(timeout);reject(new Error(`Driver ${i} connection failed`));});
      socket.addEventListener('close',()=>{if(!joined){clearTimeout(timeout);reject(new Error(`Driver ${i} closed before staging`));}});
      socket.addEventListener('message',event=>{
        const message=JSON.parse(String(event.data)) as {type:string;id?:string;version?:number;playtestMode?:string|null;poseRevision:number;world?:World};
        input.observe(message);
        if(message.type==='welcome'){
          if(message.version!==PROTOCOL_VERSION||message.playtestMode!==null){clearTimeout(timeout);reject(new Error('Wrong protocol or room mode'));return;}
          ids[i]=message.id??'';socket.send(JSON.stringify({type:'identity',code:null,requestId:1}));
        }
        if(message.type!=='state'||!message.world)return;
        const player=message.world.players.find(item=>item.id===ids[i]);
        const car=message.world.entities.find(item=>item.id===player?.entityId&&item.driver===ids[i])??null;
        if(car){cars[i]=car;carAt[i]=performance.now();snapshots[i]++;}
        if(!joined&&input.active&&message.poseRevision>0&&car?.x===report.poses[i].x&&car.z===report.poses[i].z){
          joined=true;clearTimeout(timeout);resolve();
        }
      });
    });
    const headers={Authorization:`Bearer ${secret}`};
    const statusResponse=await fetch(`${base}/api/lab/status/${room}`,{headers});assert.equal(statusResponse.status,200);
    const status=await statusResponse.json() as {ready:boolean;expectedDrivers:number;initialAmbientCount:number;initialAmbientRetained:number;staged:{exact:boolean;economy:boolean;poseRevision:number}[]};
    assert.equal(status.ready,true);assert.equal(status.expectedDrivers,2);assert.equal(status.staged.length,2);
    assert.ok(status.staged.every(item=>item.exact&&item.economy));
    assert.ok(status.initialAmbientCount>0);assert.equal(status.initialAmbientCount,status.initialAmbientRetained);
    const revisions=inputs.map(input=>input.control!.revision);
    const begin=await fetch(`${base}/api/lab/begin/${room}`,{method:'POST',headers});assert.equal(begin.status,200);
    const deadline=performance.now()+5000;
    while(inputs.some((input,i)=>(input.control?.revision??-1)<=revisions[i])){if(performance.now()>deadline)throw new Error('Missing begin fences');await delay(20);}
    const before=inputs.map(input=>input.lastSeq),start=performance.now();
    timer=setInterval(()=>{const now=performance.now();for(let i=0;i<2;i++)inputs[i].send(driveControl(cars[i]?.speed??null,now-carAt[i]));},50);
    await delay(8000);clearInterval(timer);timer=undefined;
    const drivers=inputs.map((input,i)=>{
      const car=cars[i],pose=report.poses[i];
      return {initialPose:pose,poseRevision:input.poseRevision,appliedSeq:input.control?.appliedSeq??null,receivedSeq:input.control?.receivedSeq??null,
        sent:input.lastSeq-before[i],rejections:input.rejectionCount,snapshots:snapshots[i],finalPose:car?{x:car.x,y:car.y,z:car.z,speed:car.speed}:null,
        displacementM:car?Math.hypot(car.x-pose.x,car.z-pose.z):null};
    });
    assert.ok(drivers.every((driver,i)=>driver.appliedSeq!==null&&driver.appliedSeq>before[i]&&driver.sent>0&&driver.rejections===0&&driver.displacementM!==null&&driver.displacementM>10));
    console.log(JSON.stringify({scope:'two-client functional pilot only; not capacity or performance evidence',ok:true,elapsedSeconds:(performance.now()-start)/1000,
      initialAmbientCount:status.initialAmbientCount,initialAmbientRetained:status.initialAmbientRetained,drivers},null,2));
  }finally{if(timer)clearInterval(timer);for(const socket of sockets)if(socket.readyState===WebSocket.OPEN)socket.close();}
}
void main().catch(error=>{console.error(error);process.exitCode=1;});
