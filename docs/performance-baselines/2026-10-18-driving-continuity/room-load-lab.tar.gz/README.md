# Disposable throughput lab

This is a local test fixture over the frozen `/private/tmp/tesland-load-64-d05` source, supplied as revision `d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31`. The frozen directory has no `.git`; its `worker/index.ts`, `wrangler.jsonc` and `scripts/measure-room-compression.ts` hashes were checked against that commit. It is not part of the production Worker, and must never be deployed. Before any comparison, recreate the same lab against the exact intended source revision and verify that its preflight still passes.

The static preflight samples terrain, map bounds, access level and enlarged building-clearance rectangles every 2 m. Initial poses also use the authoritative `addPlayer` fit check against seed-0 ambient entities and each preceding staged player. It does not prove continuous ground support, that moving traffic stays out of the corridor, absence of substep contacts, or sustained player movement.

The normal room's identity, economy, ambient traffic, input handler and tick scheduler remain in use. The lab wrapper temporarily pauses and stages sequentially joined drivers, then fences their controls and starts the ordinary timer. Status/begin require a lab bearer token. Bind Wrangler strictly to loopback and use isolated disposable local storage: URL host validation is not a network security boundary.

Generate the candidate lanes without running a load:

```sh
cd /private/tmp/tesland-load-64-d05
pnpm exec tsx /private/tmp/tesland-throughput-lab/preflight.ts > /private/tmp/tesland-throughput-lab/preflight-result.json
pnpm exec tsx --test /private/tmp/tesland-throughput-lab/controller.test.ts /private/tmp/tesland-throughput-lab/diagnostics.test.ts
```

A short functional pilot uses separate ports and fresh storage; it exercises two drivers for eight seconds and is not performance or capacity evidence. The default remains 64 drivers.

```sh
cd /private/tmp/tesland-load-64-d05
pnpm exec wrangler dev --local --config /private/tmp/tesland-throughput-lab/wrangler.lab.jsonc --ip 127.0.0.1 --port 19891 --inspector-port 19892 --persist-to /private/tmp/tesland-throughput-lab/fresh-pilot-state --show-interactive-dev-session false --var LAB_EXPECTED_DRIVERS:2 --var LAB_STAGE_SECRET:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
```

In a separate terminal, then stop Wrangler:

```sh
cd /private/tmp/tesland-load-64-d05
pnpm exec tsx /private/tmp/tesland-throughput-lab/pilot.ts > /private/tmp/tesland-throughput-lab/pilot-result.json
```

The 2026-10-18 local pilot with `--persist-to /private/tmp/tesland-throughput-lab/pilot-state` completed in 8.0008 wall seconds: both drivers moved 49.82 m from their exact staged poses, each sent 155 inputs, reached applied sequence 151, and had zero rejections. The normal economy session and all 22 initial ambient entities were present. See `pilot-result.json`. This validates the short two-driver setup and control path, not sustained movement, 64-player capacity, production behavior, or a performance gate.

Only after a coordinated measurement window, use a fresh state directory. This illustrative fixed token is valid only for disposable loopback tests:

```sh
cd /private/tmp/tesland-load-64-d05
pnpm exec wrangler dev --local --config /private/tmp/tesland-throughput-lab/wrangler.lab.jsonc --ip 127.0.0.1 --port 19881 --inspector-port 19882 --persist-to /private/tmp/tesland-throughput-lab/next-run-state --show-interactive-dev-session false --var LAB_STAGE_SECRET:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
```

In a separate terminal, from the same source directory:

```sh
LAB_STAGE_SECRET=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa pnpm exec tsx /private/tmp/tesland-throughput-lab/drive.ts http://127.0.0.1:19881 > /private/tmp/tesland-throughput-lab/run-64.json
```

Stop Wrangler afterwards. Do not rerun into an existing state directory without recording that fact. The runner's fixed workload is 64 drivers, 15 seconds warmup and 60 seconds measurement. The controller targets 12 m/s from sampled authoritative speed; an ideal flat, immediate-feedback ground-equation estimate travels 856.6 m in 75 seconds, below the 1,100 m sampled corridor. Lag or collisions can invalidate that estimate; report the actual result. Lanes start at least 12 m apart, and a sampled displacement over 3 m from a lane is flagged. This does not rule out contact between snapshots.

The output reports 10-second authoritative movement blocks, sampled queues and contact indicators, snapshots, decoded application bytes, and ACK observations for sequences seen in snapshots. Each driver's first and last state message records elapsed measurement time, room tick and world time even when the vehicle pose is missing. A WebSocket close records its code, reason, cleanliness, phase and elapsed times; null means no close was observed. Rejection counts by reason include warm-up. These diagnostic fields were added after `run64.json` and cannot recover information absent from that run. The output does not measure actual compressed network transfer, Worker CPU, inter-snapshot queue maxima, browser history, exact substep contacts, or dense city traffic. Same-host client and server contention precludes a capacity claim. Isolated generator and suitable runtime CPU evidence remain necessary for that claim.

`drive-run64-original.ts` is the exact driver used for `run64.json` (SHA-256 `bdb2f35c9d815db70b1849a400fd7e6518524486b70f842aed88b0a2dc054a45`). The later `drive.ts` contains the additional diagnostics and was not used for that recorded run.

## Archiving

Archive the lab's source/configuration, `package.json`, README, and the desired sanitized result JSON files explicitly. Do not include `.wrangler/`, `state/`, `pilot-state/`, later local storage directories, or `node_modules/`; none are needed. No live secret was used: the repeated `a` token above is a fixed illustrative value for a disposable loopback server. The lab imports the sibling frozen source directory and requires its source revision, pnpm dependencies, and an assets directory to reproduce; reconstruct those from the recorded commit rather than archiving runtime state.
