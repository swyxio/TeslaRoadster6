import test from 'node:test';
import assert from 'node:assert/strict';
import { driveControl } from './controller';
import { VEHICLES } from '../tesland-load-64-d05/shared/vehicles';

test('straight control bounds acceleration and stops on stale observations',()=>{
  assert.equal(driveControl(0,0).throttle,.1);
  assert.equal(driveControl(12,0).throttle,0);
  assert.equal(driveControl(13.1,0).brake,true);
  assert.equal(driveControl(0,501).throttle,0);
  assert.equal(driveControl(null,0).throttle,0);
  assert.equal(driveControl(8,0).steer,0);
});

test('ideal ground-speed estimate stays inside the proposed 1100 m corridor',()=>{
  // Diagnostic estimate only: no terrain, lag, ambient traffic or contacts.
  // Starter Roadster is rocket-equipped; nonzero throttle has no drag.
  const spec=VEHICLES.roadster,dt=.05;let speed=0,distance=0,maxSpeed=0;
  for(let i=0;i<75/dt;i++){
    const input=driveControl(speed,0);
    speed=(speed+input.throttle*spec.acceleration*dt)*Math.exp(-(input.throttle===0?.65:0)*dt);
    if(input.brake)speed=Math.max(0,speed-spec.brakeDecel*dt);
    distance+=speed*dt;maxSpeed=Math.max(maxSpeed,speed);
  }
  assert.ok(distance<1100);
  assert.ok(distance>700);
  assert.ok(maxSpeed<=13.1);
});
