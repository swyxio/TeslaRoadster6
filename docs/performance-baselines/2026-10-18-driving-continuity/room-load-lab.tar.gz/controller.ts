import { NEUTRAL, type Input } from '../tesland-load-64-d05/shared/game';

// Use authoritative snapshots; stale observations stop propulsion. A Roadster
// does not naturally cap its speed at low throttle, so constant input cannot
// safely stay within the static corridor.
export function driveControl(speed:number|null,snapshotAgeMs:number):Input {
  if(speed===null||!Number.isFinite(speed)||snapshotAgeMs>500)return {...NEUTRAL};
  if(speed>13)return {...NEUTRAL,brake:true};
  return {...NEUTRAL,throttle:Math.max(0,Math.min(.1,(12-speed)*.06))};
}
