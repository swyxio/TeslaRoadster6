import assert from 'node:assert/strict';
import test from 'node:test';
import { newDiagnostics,observeClose,observeRejection,observeSnapshot } from './diagnostics';

test('coverage retains first and last state times, not just valid vehicle poses',()=>{
  const d=newDiagnostics();
  observeSnapshot(d,1050,1000,12,1.2);
  observeSnapshot(d,1325,1000,16,1.4);
  assert.deepEqual(d.firstSnapshot,{measurementMs:50,tick:12,worldTime:1.2});
  assert.deepEqual(d.lastSnapshot,{measurementMs:325,tick:16,worldTime:1.4});
});

test('close code, reason, cleanliness and phase survive with missing measurement data',()=>{
  const d=newDiagnostics();
  observeClose(d,{code:1008,reason:'Message rate exceeded',wasClean:true},800,100,null,'joining');
  observeClose(d,{code:1006,reason:'',wasClean:false},900,100,850,'measurement');
  assert.deepEqual(d.close,{code:1008,reason:'Message rate exceeded',wasClean:true,phase:'joining',runElapsedMs:700,measurementElapsedMs:null});
  assert.equal(d.firstSnapshot,null);assert.equal(d.lastSnapshot,null);
  const measured=newDiagnostics();
  observeClose(measured,{code:1006,reason:'',wasClean:false},1200,100,1000,'measurement');
  assert.equal(measured.close?.measurementElapsedMs,200);
});

test('rejection reasons are counted without an unbounded set of arbitrary values',()=>{
  const d=newDiagnostics();observeRejection(d,'late');observeRejection(d,'late');observeRejection(d,'future');observeRejection(d,'unknown');
  assert.deepEqual(d.rejectionsByReason,{late:2,future:1,other:1});
});
