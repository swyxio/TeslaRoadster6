// Local static candidate search only. This is not proof of collision-free driving.
import { createWorld, addPlayer } from '../tesland-load-64-d05/shared/game';
import { MAP_BOUNDS, isSurface, nearbyBuildings, terrainHeight } from '../tesland-load-64-d05/shared/map';
import { requiredLevelAt } from '../tesland-load-64-d05/shared/delivery';
import { contact } from '../tesland-load-64-d05/shared/physics';

const startZ=4100, endZ=3000, sampleM=2, width=6, length=8.5;
const world=createWorld(0), poses:{x:number;z:number;yaw:number}[]=[];
const rejected:Record<string,number>={};
const reject=(reason:string)=>{rejected[reason]=(rejected[reason]??0)+1;return false;};

function corridor(x:number):boolean {
  const startLevel=requiredLevelAt(x,startZ);
  let previousLevel=startLevel;
  for(let z=startZ;z>=endZ;z-=sampleM){
    const level=requiredLevelAt(x,z);
    if(level>previousLevel)return reject('access-increase');
    previousLevel=level;
    if(x-width/2<MAP_BOUNDS.minX||x+width/2>MAP_BOUNDS.maxX||z-length/2<MAP_BOUNDS.minZ||z+length/2>MAP_BOUNDS.maxZ)return reject('map-bounds');
    for(const dx of [-width/2,0,width/2])for(const dz of [-length/2,0,length/2]){
      if(!isSurface(x+dx,z+dz)||terrainHeight(x+dx,z+dz)===null)return reject('surface');
      if(requiredLevelAt(x+dx,z+dz)>startLevel)return reject('access');
    }
    if(nearbyBuildings(x,z,length+width).some(building=>contact({x,z,w:width,d:length+sampleM,yaw:0},{...building,yaw:0})))return reject('building');
  }
  return true;
}

for(let x=-1450;x<=1800&&poses.length<64;x+=12){
  if(!corridor(x))continue;
  // The actual spawn function checks static ground and all initial entities.
  // Clone first because addPlayer falls back to a different safe spawn.
  const pose={x,z:startZ,yaw:0}, trial=structuredClone(world);
  const player=addPlayer(trial,`preflight-${poses.length}`,`Driver ${poses.length}`,[pose]);
  const car=trial.entities.find(entity=>entity.id===player.entityId);
  if(!car||car.x!==pose.x||car.z!==pose.z||car.yaw!==pose.yaw){reject('initial-occupancy');continue;}
  world.entities=trial.entities;world.players=trial.players;
  poses.push(pose);
}

console.log(JSON.stringify({source:'d05d6f4 archive, seed 0',sampleM,startZ,endZ,
  footprint:{width,length},count:poses.length,rejected,poses,
  limitations:'Sampled static map and initial entity occupancy only; does not prove continuous surface, dynamic traffic avoidance or 64 sustained moving drivers.'},null,2));
if(poses.length!==64)process.exitCode=1;
