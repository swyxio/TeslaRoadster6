// LOCAL LAB ONLY. Use a loopback-bound Wrangler dev server and disposable storage.
// Never deploy this file or expose its staging RPCs on a production Worker.
import worker, { GameRoom as ProductionGameRoom, GlobalChat, DriverProfile, RoomEconomy, GlobalIncome, GlobalEarningsEvent, MarketService } from '../tesland-load-64-d05/worker/index';
import { addPlayer, createWorld, type World } from '../tesland-load-64-d05/shared/game';
import { terrainHeight } from '../tesland-load-64-d05/shared/map';
import { roomSlug } from '../tesland-load-64-d05/worker/protocol';
import { prepareSnapshots } from '../tesland-load-64-d05/worker/snapshot';
import type { ScheduledInput } from '../tesland-load-64-d05/shared/tick-input';
import report from './preflight-result.json';

export { GlobalChat, DriverProfile, RoomEconomy, GlobalIncome, GlobalEarningsEvent, MarketService };
type Session={id:string;attachPending:boolean;guest:boolean;poseRevision:number;control:ScheduledInput;economy:{sync():number|undefined}|null;syncToken:number};
type Pose={x:number;z:number;yaw:number};
const poses:Pose[]=report.poses;
if(poses.length!==64)throw new Error('Lab needs exactly 64 preflighted positions');

function poseFree(world:World,pose:Pose,exclude:string):boolean {
  const trial=structuredClone(world);
  trial.entities=trial.entities.filter(entity=>entity.id!==exclude);
  try{
    const player=addPlayer(trial,'__lab-check__','Lab check',[pose]);
    const car=trial.entities.find(entity=>entity.id===player.entityId);
    return !!car&&car.x===pose.x&&car.z===pose.z&&car.yaw===pose.yaw;
  }catch{return false;}
}

export class GameRoom extends ProductionGameRoom {
  private seeded?:World;
  private paused?:World;
  private started?:World;
  private staging=false;
  private heartbeat?:ReturnType<typeof setInterval>;
  private slots=new Map<string,number>();
  private ambientIds:string[]=[];
  private expectedDrivers():number {
    const configured=Reflect.get(this.env,'LAB_EXPECTED_DRIVERS');
    if(configured===undefined||configured==='64')return 64;
    if(configured==='2')return 2;
    throw new Error('LAB_EXPECTED_DRIVERS must be 2 or 64');
  }
  private sessionsForLab():Map<WebSocket,Session>{return Reflect.get(this,'sessions') as Map<WebSocket,Session>;}
  private stopHeartbeat():void{if(this.heartbeat!==undefined)clearInterval(this.heartbeat);this.heartbeat=undefined;}
  private publish():void{
    const world=Reflect.get(this,'world') as World,sessions=this.sessionsForLab();
    if(world!==this.paused||!sessions.size){this.stopHeartbeat();return;}
    const snapshot=prepareSnapshots(world,Reflect.get(this,'tickCount') as number,Reflect.get(this,'roomEpoch') as string,Reflect.get(this,'lastSubsteps') as number);
    for(const [socket,session] of sessions)try{socket.send(snapshot(session.id,session.control.snapshot(),session.poseRevision,session.economy?.sync()??session.syncToken));}catch{/* ordinary close handler cleans up */}
  }
  labStatus(room:string){
    if(!this.ctx.id.equals(this.env.ROOMS.idFromName(room)))throw new Error('Room identity mismatch');
    const world=Reflect.get(this,'world') as World,entries=[...this.sessionsForLab()];
    const staged=entries.map(([socket,session])=>{
      const slot=this.slots.get(session.id),player=world.players.find(item=>item.id===session.id);
      const car=world.entities.find(item=>item.id===player?.entityId),pose=slot===undefined?undefined:poses[slot];
      return {id:session.id,slot,connected:socket.readyState===1,guest:session.guest,attachPending:session.attachPending,
        economy:!!session.economy,poseRevision:session.poseRevision,carId:car?.id,exact:!!car&&!!pose&&car.x===pose.x&&car.z===pose.z&&car.yaw===pose.yaw};
    });
    const expectedDrivers=this.expectedDrivers();
    const ready=this.paused===world&&entries.length===expectedDrivers&&staged.every(item=>item.connected&&item.guest&&!item.attachPending&&item.exact);
    return {paused:this.paused===world,started:this.started===world,ready,tick:Reflect.get(this,'tickCount') as number,
      expectedDrivers,initialAmbientCount:this.ambientIds.length,initialAmbientRetained:this.ambientIds.filter(id=>world.entities.some(entity=>entity.id===id)).length,staged};
  }
  labBegin(room:string){
    const status=this.labStatus(room);
    if(!status.ready||status.started)return {ok:false,...status};
    const world=this.paused!;
    this.stopHeartbeat();
    // Discard any setup controls; publish the new revisions before ticks run.
    for(const [socket,session] of this.sessionsForLab())Reflect.apply(Reflect.get(this,'invalidate'),this,[socket,session]);
    this.publish();
    this.paused=undefined;this.started=world;
    Reflect.apply(Reflect.get(this,'startTicks'),this,[]);
    return {ok:true,tick:status.tick,drivers:status.staged.length};
  }
  override async fetch(request:Request):Promise<Response>{
    if(this.staging)return new Response('Join sequentially', {status:429});
    let world=Reflect.get(this,'world') as World;
    if(this.started===world)return new Response('Lab has already started',{status:409});
    this.staging=true;
    try{
      const sessions=this.sessionsForLab();
      if(this.seeded!==world&&!sessions.size&&!world.players.length&&Reflect.get(this,'tickCount')===0){
        const previousMars=world.mars;
        world=createWorld(0);world.mars.fund=previousMars.fund;world.mars.roomFund=previousMars.roomFund;
        this.ambientIds=world.entities.map(entity=>entity.id);
        Reflect.set(this,'world',world);this.seeded=world;this.slots.clear();
      }
      if(sessions.size>=this.expectedDrivers())return new Response('Lab is full',{status:409});
      const before=new Set(sessions.keys());
      const response=await super.fetch(request);
      if(response.status!==101)return response;
      // super.fetch schedules the real timer; stop it before yielding again.
      Reflect.apply(Reflect.get(this,'stopTicks'),this,[]);
      world=Reflect.get(this,'world') as World;
      const joined=[...sessions].filter(([socket])=>!before.has(socket));
      if(joined.length!==1){for(const [socket] of joined)socket.close(1011,'Lab could not identify joined driver');return response;}
      const [socket,session]=joined[0];
      const slot=this.slots.size,pose=poses[slot],player=world.players.find(item=>item.id===session.id);
      const car=world.entities.find(item=>item.id===player?.entityId);
      if(!pose||!car||!poseFree(world,pose,car.id)){
        socket.close(1011,'Lab staging pose is unavailable');return response;
      }
      const y=terrainHeight(pose.x,pose.z);
      if(y===null){socket.close(1011,'Lab staging pose has no support');return response;}
      Object.assign(car,pose,{y,vx:0,vy:0,vz:0,speed:0,pushX:0,pushZ:0,pitch:0,roll:0,pitchRate:0,yawRate:0,rollRate:0,
        supportId:'ground',autopilot:false,navigation:null});
      this.slots.set(session.id,slot);this.paused=world;
      Reflect.apply(Reflect.get(this,'invalidate'),this,[socket,session,true]);
      this.publish();
      if(this.heartbeat===undefined)this.heartbeat=setInterval(()=>this.publish(),1000);
      return response;
    }finally{this.staging=false;}
  }
}

export default {async fetch(request:Request,env:Parameters<typeof worker.fetch>[1],ctx:ExecutionContext):Promise<Response>{
  const url=new URL(request.url);
  // Host validation is not authentication; the actual boundary is Wrangler's
  // required --ip 127.0.0.1 plus isolated local storage.
  if(!['127.0.0.1','localhost','[::1]'].includes(url.hostname))return new Response('Lab is local only',{status:403});
  if(url.pathname==='/api/health')return worker.fetch(request,env,ctx);
  const operation=/^\/api\/lab\/(status|begin)\/(lab-[a-z0-9-]+)$/.exec(url.pathname);
  if(operation){
    if((operation[1]==='status'&&request.method!=='GET')||(operation[1]==='begin'&&request.method!=='POST'))return new Response('Method not allowed',{status:405});
    const secret=Reflect.get(env,'LAB_STAGE_SECRET');
    const token=/^Bearer ([0-9a-f]{64})$/i.exec(request.headers.get('Authorization')??'')?.[1];
    if(typeof secret!=='string'||!/^[0-9a-f]{64}$/i.test(secret)||!token||!crypto.subtle.timingSafeEqual(new TextEncoder().encode(token),new TextEncoder().encode(secret)))return new Response('Unauthorized',{status:401});
    const room=roomSlug(`/api/room/${operation[2]}`);if(!room)return new Response('Invalid room',{status:400});
    const object=(env.ROOMS as unknown as DurableObjectNamespace<GameRoom>).get(env.ROOMS.idFromName(room));
    if(operation[1]==='status')return Response.json(await object.labStatus(room));
    const result=await object.labBegin(room);return Response.json(result,{status:result.ok?200:409});
  }
  const slug=roomSlug(url.pathname);
  if(!slug||!slug.startsWith('lab-'))return new Response('Unknown lab route',{status:404});
  return worker.fetch(request,env,ctx);
}};
