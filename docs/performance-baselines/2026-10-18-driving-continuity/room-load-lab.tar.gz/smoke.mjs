// One-client functional smoke, not a throughput or sustained-motion run.
import assert from 'node:assert/strict';
const base='http://127.0.0.1:19881',room='lab-smoke',token='a'.repeat(64);
const socket=new WebSocket(base.replace('http','ws')+'/api/room/'+room);
let playerId,playtestMode,stagedSnapshot=false,identified=false;
const timer=setTimeout(()=>{console.error('smoke timeout');socket.close();process.exitCode=1;},15000);
try{
  await new Promise((resolve,reject)=>{
    socket.onerror=()=>reject(new Error('WebSocket failed'));
    socket.onclose=event=>reject(new Error(`WebSocket closed: ${event.code}`));
    socket.onmessage=event=>{
      const message=JSON.parse(String(event.data));
      if(message.type==='welcome'){playerId=message.id;playtestMode=message.playtestMode;socket.send(JSON.stringify({type:'identity',code:null,requestId:1}));}
      if(message.type==='identityResult')identified=message.ok===true;
      if(message.type==='state'&&message.poseRevision>0){
        const player=message.world.players.find(item=>item.id===playerId);
        const car=message.world.entities.find(item=>item.id===player?.entityId);
        stagedSnapshot=!!car&&car.x===-1270&&car.z===4100&&car.yaw===0;
      }
      if(identified&&stagedSnapshot)resolve();
    };
  });
  assert.equal(playtestMode,null);
  const path=`${base}/api/lab/status/${room}`;
  const unauthorized=await fetch(path);
  assert.equal(unauthorized.status,401);
  const statusResponse=await fetch(path,{headers:{Authorization:`Bearer ${token}`}});
  assert.equal(statusResponse.status,200);
  const status=await statusResponse.json();
  assert.equal(status.paused,true);assert.equal(status.started,false);assert.equal(status.ready,false);assert.equal(status.tick,0);
  assert.equal(status.staged.length,1);assert.equal(status.staged[0].exact,true);
  assert.equal(status.staged[0].guest,true);assert.equal(status.staged[0].attachPending,false);assert.equal(status.staged[0].economy,true);
  assert.ok(status.initialAmbientCount>0);assert.equal(status.initialAmbientRetained,status.initialAmbientCount);
  const begin=await fetch(`${base}/api/lab/begin/${room}`,{method:'POST',headers:{Authorization:`Bearer ${token}`}});
  assert.equal(begin.status,409);
  console.log(JSON.stringify({ok:true,playtestMode,identified,stagedSnapshot,unauthorizedStatus:unauthorized.status,
    beginWithOneStatus:begin.status,paused:status.paused,tick:status.tick,ambientCount:status.initialAmbientCount,
    ambientRetained:status.initialAmbientRetained,driver:status.staged[0]},null,2));
}finally{clearTimeout(timer);socket.onclose=null;socket.close();}
