export type RunPhase='joining'|'begin'|'warmup'|'measurement'|'after-measurement';
type SnapshotObservation={measurementMs:number;tick:number;worldTime:number};
type CloseObservation={code:number;reason:string;wasClean:boolean;phase:RunPhase;runElapsedMs:number;measurementElapsedMs:number|null};
export type ClientDiagnostics={firstSnapshot:SnapshotObservation|null;lastSnapshot:SnapshotObservation|null;
  close:CloseObservation|null;rejectionsByReason:Record<string,number>};

export function newDiagnostics():ClientDiagnostics {
  return {firstSnapshot:null,lastSnapshot:null,close:null,rejectionsByReason:{}};
}

// Count every state message, including a state without a usable vehicle pose.
export function observeSnapshot(d:ClientDiagnostics,now:number,start:number,tick:number,worldTime:number):void {
  const item={measurementMs:now-start,tick,worldTime};
  d.firstSnapshot??=item;d.lastSnapshot=item;
}

export function observeClose(d:ClientDiagnostics,event:{code:number;reason:string;wasClean:boolean},now:number,
  runStart:number,measurementStart:number|null,phase:RunPhase):void {
  d.close??={code:event.code,reason:event.reason,wasClean:event.wasClean,phase,
    runElapsedMs:now-runStart,measurementElapsedMs:measurementStart===null?null:now-measurementStart};
}

export function observeRejection(d:ClientDiagnostics,reason:unknown):void {
  const value=typeof reason==='string'&&['epoch','revision','action','late','future','order'].includes(reason)?reason:'other';
  d.rejectionsByReason[value]=(d.rejectionsByReason[value]??0)+1;
}
