# Airborne solid-contact follow-up, 2026-10-18

**Diagnostic only; unavailable as a fix. Do not merge or deploy.** This is a patch atop the earlier v50 token/history experiment, itself based on candidate 020f25b40696608e7e7285fc74adf6f52c4c3d42. It is not a patch to the release checkout. The accompanying full captures, fixture identities and inputs are synthetic; they contain no production sessions or credentials. Keep all strict assertions and failed results.

## Provenance and reconstruction

Predecessor: `/private/tmp/tesland-confirmed-ferry-handoff-20261018.tar.gz`, SHA-256 `86b9e1a9b51fa01b28be3bdff0fdf12fdd005b8a71ec82667377dfd468f0599d`. Follow its README and `reconstruct.sh` to construct the `token` checkout, then apply this bundle's `airborne-solid-signal-followup.patch` there. `git apply --check` passed against the matching pre-follow-up token files; the old `src/tick-prediction.ts` SHA-256 is `7b652a74d3b50a5007825170cfd2545c5f9357ec3cdca2ab5e717429c209e849` and old `shared/game.ts` SHA-256 is `10ea7595e3b7b1bda505ce37ca36e698622216e25bc100048bd9b27f2f2a48cf`. The patch adds the contact-signal change, stationary correction and both focused test files, including the JSON fixture. It preserves the predecessor's ferry diagnostic and original strict test cases.

After dependency installation in the reconstructed token directory, use distinct output files and run:

```
git apply --check /ABSOLUTE/PATH/airborne-solid-signal-followup.patch
git apply /ABSOLUTE/PATH/airborne-solid-signal-followup.patch
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/airborne-stationary-contact.lab.test.ts tests/solid-contact-signal.lab.test.ts
./node_modules/.bin/tsc --noEmit
TRACE_PATH=/tmp/pinned-trace.json ./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/pinned-scheduled-input.lab.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec --test-name-pattern 'a pinned-wall jump remains responsive' tests/session-motion.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec --test-name-pattern 'ferry phase and membership|shore driver stays clear|moving local and remote riders|confirmed boarding under' tests/ferry-transition.lab.test.ts
```

The last three commands retain failures. The bundled v7 trace JSON contains complete synthetic frames, authority, input receipts, and edges, including results produced even though the assertion fails. The v6 old-wall and ferry logs were captured immediately before v7's additional guard tightening; they were not rerun at v7. Their results are evidence for v6, not claimed as exact v7 results.

## Findings and limits

The shared simulation rolls back position at a solid wall while retaining negative airborne velocity. The presentation experiment extrapolated that retained velocity and then moved upward toward the clamped position. An optional per-step observer now reports actual simulated solid-block events without changing the physics in the tested wall fixture. The lab predictor uses the replayed segment displacement for bounded corrections only after its existing static and joint checks. A small synthetic exit test clears the signal and moves away; this does not establish real input responsiveness at a wall. Events are not classified by exact collision time or surface, and the experimental static, dynamic, 3-D, ferry and identity proofs are incomplete. Callback cost has not been measured.

The v7 focused test log passes 14/14 and typecheck passes. In the deterministic 20 Hz authority / 120 Hz rendering actual-Session/ScheduledInput synthetic pinned fixture, the captured first falling interval has no upward display frames from 5.4–6.0 s, versus 21 before this follow-up; the fixture reports no snap, maximum displayed frame step 0.294 m, zero measured peer penetration, and jump display after 8.33 ms. It still **fails** because eight late commands are rejected, and that assertion precedes its snap assertion. No runtime gate passes on the strength of this capture.

The previous v6 run of the older, inconsistent-control wall fixture still fails at frame 596. The v6 ferry suite fails 6/6: the departure and arrival phase tests do not exercise a stable replay segment; displayed shore/deck overlap reaches 1.104 m while authoritative overlap is zero; boarding reaches a 1.319 m step and 121 held frames, disembarking a 1.495 m step, and confirmed boarding displays stale ground across seven sampled frames. The earlier confirmed-only ferry prototype also failed responsiveness and is not a solution.

No live Worker, browser, device, performance, or room throughput tests were performed on this follow-up. A safe solution still needs a coherent, responsive hull/passenger/nearby-car timeline, swept contacts, support/identity/action fences and validation in actual rendering and networking. The earlier wire-clock hypotheses remain unsafe; this package does not change input scheduling.
