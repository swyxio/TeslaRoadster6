# Unshipped conditional blackout control model

This package contains a mathematical model and a small test-only scheduler experiment. **It is not connected to the real Worker, wire parser, or Session and is not a release candidate.** The visual driving-continuity, Worker clock and performance gates remain open.

Starting base: `d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31`, then apply `combined-lab-base.patch` followed by `model-incremental.patch` in an isolated checkout. The test files are also included separately for reading and match those in the model patch. With the project's dependencies installed:

```
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/blackout-control-contract.lab.test.ts tests/tick-input.test.ts
./node_modules/.bin/tsc --noEmit
./node_modules/.bin/tsc --noEmit --module ESNext --moduleResolution Bundler --target ES2022 --lib ES2022,DOM,DOM.Iterable --types node --skipLibCheck --strict tests/blackout-control-contract.lab.test.ts
```

The first command passed 36/36, including six new conditional model tests; the captured output is `focused-tests.log`. Both typechecks exited zero; project typecheck covers src/shared, while the second also checks the model test. Test values are examples, not measured bounds.

## Candidate contract and assumptions

The client includes the latest received authoritative snapshot tick and elapsed client monotonic milliseconds since its receipt with a control command. The server retains an immutable monotonic timestamp from at or before generation of that exact `(roomEpoch,tick)` snapshot. It uses an independently established upper bound on client clock speed, upper bound on server clock slowness, and measurement uncertainty. Then:

```
upper_age = (server_receive - server_anchor) / (1 - server_slow_fraction)
          + measurement_uncertainty
          - client_elapsed / (1 + client_fast_fraction)
```

This conservatively includes the anchor's downlink delay as well as control uplink delay. If the upper bound exceeds the 300 ms modeled control deadline, is inconsistent, or the anchor/bounds are missing/evicted, the control fails closed. Thus fresh controls can be assigned to the next server tick during a 1.8 s downstream state blackout **only if all stated clock bounds are valid and the upper bound fits the deadline**. A fresh command can be rejected conservatively because initial snapshot downlink delay counts against the budget. The 300 ms value mirrors the existing watchdog; it is not a newly measured performance target.

The model scheduler consumes expired sequence and edge counters without applying a level, prevents repeated jump, respects an epoch guard in a simulated Worker wrapper, tests action/relocation fences, and uses the existing control watchdog. The wrapper stands in for real protocol code: it does not exercise a Cloudflare Worker, serialization, retained-anchor implementation, live WebSocket, or reconnect identity. In particular, epoch filtering and timestamp lookup must occur before scheduling in the real Worker. The scheduler's new optional `expired` argument is experimental and is never called by production.

Clock bounds (.0001 fractional rates and 1 ms uncertainty in tests) are illustrative and **not established** for browsers, OS suspension, or Cloudflare Workers. Existing Worker wall-clock/I/O update behavior and monotonicity have not been verified. If bounds are unknown or a violation is observable, the model rejects the command; an undetectable faster client clock can make the same measurements represent a fresh or stale command. The last focused test explicitly constructs that indistinguishability. Client honesty and true elapsed-time bounds are assumptions; a malicious or badly broken client can lie. No age guarantee can be claimed for unverified bounds.

## Remaining requirements

Wire schema/protocol versioning, actual authenticated epoch and connection fencing, anchor storage/lifetime/eviction, clock discontinuity handling and Cloudflare I/O semantics remain undesigned or untested. The real client currently freezes visible prediction after 500 ms and limits replay to 12 ticks; this model does not fix visual input response, local replay or its 64-command pending bound. A 1.8 s blackout can also deliver identity/action/revision changes later; the server can reject stale generations, but neither safe visible local response nor authoritative acceptance through an unseen fence is proven. No swept peer/contact, wall, ferry, scene, rendering, 64-player allocation, latency, physical-device or production-capacity result is provided. Do not integrate or deploy this model.
