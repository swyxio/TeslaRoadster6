import test from 'node:test';
import assert from 'node:assert/strict';
import { NEUTRAL, type Input } from '../shared/game';
import { INPUT_TIMEOUT_MS, ScheduledInput, type InputCommand } from '../shared/tick-input';
import { ageUpperBoundMs, type ClockBounds } from './blackout-control-contract.lab';

const bounds:ClockBounds={clientFast:.0001,serverSlow:.0001,uncertaintyMs:1};
const input=(fields:Partial<Input>={})=>({...NEUTRAL,...fields});
const command=(seq:number,fields:Partial<Input>={},controlRevision=0,actionSeq=0):InputCommand=>({seq,targetTick:1,controlRevision,actionSeq,input:input(fields)});

// Illustrates an intended worker boundary; no claim this wrapper is integrated.
function arrival(scheduler:ScheduledInput,epoch:string,expectedEpoch:string,cmd:InputCommand,tick:number,serverNow:number,anchor:number|null,elapsed:number,bounds:ClockBounds|null){
  if(epoch!==expectedEpoch)return {rejection:'epoch' as const,outcomes:[]};
  const age=anchor===null?null:ageUpperBoundMs(anchor,serverNow,elapsed,bounds);
  const expired=age===null||age>INPUT_TIMEOUT_MS;
  return scheduler.receive({...cmd,targetTick:tick+1},tick,serverNow,expired);
}

test('fresh controls during 1.8 s downstream snapshot blackout apply at the next tick and edge is not repeated',()=>{
  const s=new ScheduledInput(input());
  const anchor=0,serverNow=1990,elapsed=1800; // 150 ms down, 1.8 s since receipt, 40 ms up.
  assert.ok(ageUpperBoundMs(anchor,serverNow,elapsed,bounds)!<INPUT_TIMEOUT_MS);
  assert.equal(arrival(s,'room','room',command(1,{throttle:1,jump:1}),36,serverNow,anchor,elapsed,bounds).rejection,undefined);
  const pressed=s.advance(37,serverNow+50);
  assert.equal(pressed.input.throttle,1);assert.deepEqual(pressed.outcomes.map(x=>[x.kind,x.id,x.status]),[['jump',1,'processed']]);
  assert.equal(arrival(s,'room','room',command(2,{throttle:0,jump:1}),37,serverNow+60,anchor,elapsed+60,bounds).rejection,undefined);
  const released=s.advance(38,serverNow+100);assert.equal(released.input.throttle,0);assert.equal(released.outcomes.length,0);
  assert.equal(s.advance(39,serverNow+150).outcomes.length,0);
});

test('an upstream-delayed press expires, does not set throttle, and its edge cannot revive later',()=>{
  const s=new ScheduledInput(input());
  assert.ok(ageUpperBoundMs(0,2500,1800,bounds)!>INPUT_TIMEOUT_MS);
  const result=arrival(s,'room','room',command(1,{throttle:1,jump:1}),36,2500,0,1800,bounds);
  assert.equal(result.rejection,'expired');assert.deepEqual(result.outcomes.map(x=>[x.kind,x.id,x.status]),[['jump',1,'expired']]);
  assert.equal(s.advance(37,2510).input.throttle,0);
  // Client sends its newest release and same edge counter after the queue clears.
  assert.equal(arrival(s,'room','room',command(2,{jump:1}),37,2560,0,2400,bounds).rejection,undefined);
  const released=s.advance(38,2610);assert.equal(released.input.throttle,0);assert.equal(released.input.jump,0);assert.deepEqual(released.outcomes,[]);
});

test('unknown, evicted, malformed or observably impossible clock bounds fail closed',()=>{
  const s=new ScheduledInput(input());
  const scenarios:[number|null,number,ClockBounds|null][]=[[0,1800,null],[null,1800,bounds],[0,NaN,bounds],[0,3000,bounds],[0,1800,{...bounds,serverSlow:1}]];
  for(let i=0;i<scenarios.length;i++){
    const [anchor,elapsed,clock]=scenarios[i];
    assert.equal(arrival(s,'room','room',command(i+1,{throttle:1,jump:i+1}),36,2000,anchor,elapsed,clock).rejection,'expired');
  }
  assert.equal(s.advance(37,2050).input.throttle,0);assert.equal(s.snapshot().jump.pending.length,0);
});

test('epoch, action and relocation fences prevent input replay',()=>{
  const s=new ScheduledInput(input());
  assert.equal(arrival(s,'old','new',command(1,{throttle:1,jump:1}),36,1990,0,1800,bounds).rejection,'epoch');
  assert.equal(s.snapshot().receivedSeq,0);
  s.invalidate(input(),{type:'relocation'});
  assert.equal(arrival(s,'new','new',command(1,{throttle:1,jump:1}),36,1990,0,1800,bounds).rejection,'revision');
  assert.equal(arrival(s,'new','new',command(2,{jump:1},1),36,1990,0,1800,bounds).rejection,undefined);
  assert.equal(s.advance(37,2040).input.jump,0);
  assert.equal(s.beginAction(1,{jump:1,flip:0}),true);
  assert.equal(arrival(s,'new','new',command(3,{throttle:1,jump:2},1,0),37,2050,0,1860,bounds).rejection,'action');
  assert.equal(s.advance(38,2100).input.throttle,0);
});

test('watchdog neutralizes a fresh level if later heartbeats stop',()=>{
  const s=new ScheduledInput(input());
  arrival(s,'room','room',command(1,{throttle:1}),36,1990,0,1800,bounds);
  assert.equal(s.advance(37,2040).input.throttle,1);
  assert.equal(s.advance(38,1990+INPUT_TIMEOUT_MS+1).input.throttle,0);
});

test('unobservable violation of client clock bound is indistinguishable from a fresh packet',()=>{
  // Identical observed values: (A) 150 ms down + 1800 ms elapsed + 50 ms up;
  // (B) 0 ms down + 1500 ms elapsed on a clock running 20% fast + 500 ms up.
  const a={serverElapsed:2000,clientElapsed:1800},b={serverElapsed:2000,clientElapsed:1800};
  assert.deepEqual(a,b);assert.ok(ageUpperBoundMs(0,a.serverElapsed,a.clientElapsed,bounds)!<INPUT_TIMEOUT_MS);
  assert.ok(500>INPUT_TIMEOUT_MS,'case B is actually stale, but cannot be distinguished from A without the clock bound');
});
