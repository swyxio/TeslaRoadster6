/** Experimental mathematical model. This is not wired to the Worker or client. */
export type ClockBounds={clientFast:number;serverSlow:number;uncertaintyMs:number};

// A server timestamp preceding snapshot generation and client elapsed time
// since receipt bound both network legs. Returns null when no proof exists.
export function ageUpperBoundMs(anchorServerMs:number,receiptServerMs:number,clientElapsedMs:number,bounds:ClockBounds|null):number|null {
  if(!bounds||![anchorServerMs,receiptServerMs,clientElapsedMs,bounds.clientFast,bounds.serverSlow,bounds.uncertaintyMs].every(Number.isFinite)||
    receiptServerMs<anchorServerMs||clientElapsedMs<0||bounds.clientFast<0||bounds.clientFast>=.5||
    bounds.serverSlow<0||bounds.serverSlow>=.5||bounds.uncertaintyMs<0)return null;
  const total=(receiptServerMs-anchorServerMs)/(1-bounds.serverSlow)+bounds.uncertaintyMs;
  const sinceReceipt=clientElapsedMs/(1+bounds.clientFast);
  if(sinceReceipt>total)return null; // Measurements violate the stated bounds.
  return total-sinceReceipt;
}
