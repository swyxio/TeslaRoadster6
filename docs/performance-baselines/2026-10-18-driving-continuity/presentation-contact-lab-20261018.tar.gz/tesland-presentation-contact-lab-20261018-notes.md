# Tesland presentation history lab, 2026-10-18

STATUS: experimental and UNSAFE TO SHIP. No release checkout changes.

- Base: d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31
- Patch: /private/tmp/tesland-presentation-contact-lab-20261018.patch
- SHA-256: 89c54c76dad2072fc3d8040e709dda4fa8069e3332adfe0c370705fcb5ff06eb
- Lab checkout: /private/tmp/tesland-presentation-contact-lab-20261018
- Full log: /private/tmp/tesland-presentation-contact-lab-suite-final.log
- The patch includes diagnostics and two new lab tests; it is not a proposed production diff.
- Verified `git apply --check`, application to a fresh archive of the exact base, and byte-for-byte equality of all 11 patched files.

From a clean checkout of the base, run `git apply /private/tmp/tesland-presentation-contact-lab-20261018.patch`, install the existing project dependencies, then:

```
pnpm exec tsx --test --test-concurrency=1 --test-reporter=spec tests/session.test.ts tests/audio.test.ts tests/motion-clock.test.ts tests/tick-prediction.test.ts tests/session-motion.test.ts tests/remote-presentation.test.ts tests/building-sweep-lab.test.ts
pnpm exec tsc --noEmit
node --expose-gc --import tsx tests/presentation-cost-probe.lab.ts
```

Focused reproduction:

```
pnpm exec tsx --test --test-name-pattern 'a peer pinned near a wall remains safe|a pinned-wall jump remains responsive|head-on peer contact remains|three-body impact remains' tests/session-motion.test.ts
pnpm exec tsx --test --test-name-pattern 'a later relocation fences every older|samples are copied|later impact retains' tests/remote-presentation.test.ts
pnpm exec tsx --test tests/building-sweep-lab.test.ts
```

Final full suite: 151 tests, 148 pass, 3 fail; typecheck passes. The wall fixture fails on seven held frames after a narrow exact fixed-orientation withdrawal proof; a new input during the prior no-proof version showed steering after 100 ms and jump after 108.3 ms. With the withdrawal proof, the same initial inputs appear after 0/8.3 ms, but the jump fixture later holds 204 frames and trips false history exhaustion, even with zero actual vertical-aware dynamic overlap. The existing ferry-passenger case fails because shore traffic does not interpolate. Head-on and three-body burst regressions pass. A discrete endpoint check cannot establish dynamic swept-path safety: the included static fixture proves two nonoverlapping endpoint pairs can cross at midpoint.

The wall proof covers exactly upright, constant-yaw translation away from an already sub-millimetre wall clearance and leaves approaches/turns/initial penetration blocked. It is not a multi-body solution. Runtime fallback guards currently use 2-D OBB contact without the server's height or dome rules; there is no full swept joint-world proof. The new regression uses the actual server vertical bounds and reports zero authority and shown penetration.

The lab lineage heuristic fences disappear/reappear and visibly implausible relocations while preserving the later-impact segment; it cannot distinguish a short, otherwise plausible authoritative relocation from continuous motion. Correctness needs an explicit per-entity incarnation/pose-discontinuity token carried in each snapshot and scoped to the room epoch; advance it for every spawn/ID reuse and forced relocation, not for ordinary continuous collision damage. On observing a changed token, discard that entity's pre-token playback; keep UI/authority updates and local action/revision fences immediate. Define and test all server paths that relocate or replace entities, loss/reordering, room restart, ownership, ferry/dome support and local camera semantics. The token alone does not solve 3-D/dome/ferry swept contacts, immediate local controls, bounded history or performance.

One synthetic local cost probe, 64 cloned players plus 22 ambient entities, yielded 114,129 JSON bytes per world; retaining 16 clones added about 2,074,128 bytes of measured V8 heap after GC. Single-run median clone 0.661 ms, max 1.028 ms, total 10.795 ms. The serialized size is only a data-size proxy; heap numbers and timings are host/runtime specific, exclude parsing, remote pose history, replay, geometry and GC/frame impact, and are not browser or capacity-gate evidence.
