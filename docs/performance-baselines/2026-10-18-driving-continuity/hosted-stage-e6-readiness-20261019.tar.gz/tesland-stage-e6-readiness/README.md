# Disabled staged-room laboratory — candidate e6ad3b7

This is a local-only research fixture, not a release, deployed Worker, 64-driver result, or capacity proof. Hosted execution is unconditionally disabled. See `evidence/READINESS-e6.md` for the precise test results, measurement method, and outstanding contact, provider-isolation, observer-overhead, wire-byte, and per-tick CPU gaps. `evidence/READINESS-38f.md` and `diagnostic-lab/README.md` preserve historical context; the e6 notes supersede their old source and pose-cap details. No live secrets or persisted state are included; the local config's repeated `a` token is a dummy.

## Reproduce focused checks

In a disposable checkout of `e6ad3b7ebb2ba47b768eb738472e4eb6aeb1844f` with locked dependencies installed, copy `diagnostic-lab/`, `scripts/hosted-room-observations.ts` and `worker/input-diagnostic-guard.ts` into the matching paths and apply the three `patches/*.patch`. Never apply this lab to the release checkout or deploy it. The recorded environment used Node 22.22.2 and pnpm 10.33.1; `ws@8.21.0` is an existing pnpm transitive dependency used for the loopback-only smoke.

```sh
pnpm exec tsx --test diagnostic-lab/hosted-stage-core.test.ts
pnpm exec tsx --test diagnostic-lab/multi-session-measurement.test.ts diagnostic-lab/session-ack.integration.test.ts diagnostic-lab/ack-observer.test.ts tests/load-room.test.ts
pnpm exec tsc -p diagnostic-lab/tsconfig.worker.json --noEmit
pnpm exec tsc -p diagnostic-lab/tsconfig.client.json --noEmit
pnpm exec tsx diagnostic-lab/hosted-stage-preflight.ts
```

For the small local smoke only, use a fresh disposable state directory and port 19331. Stop Wrangler after the second command:

```sh
pnpm exec wrangler dev --config diagnostic-lab/wrangler.local-smoke.jsonc --local --local-protocol https --ip 127.0.0.1 --port 19331 --inspector-port 0 --persist-to /private/tmp/tesland-stage-new-smoke-state --log-level warn
pnpm exec tsx diagnostic-lab/hosted-stage-local-smoke.ts
```

`SHA256SUMS` covers the package files. Contact coverage remains intentionally unverified even when these checks succeed; do not enable the hosted driver without independent audit and coordination.
