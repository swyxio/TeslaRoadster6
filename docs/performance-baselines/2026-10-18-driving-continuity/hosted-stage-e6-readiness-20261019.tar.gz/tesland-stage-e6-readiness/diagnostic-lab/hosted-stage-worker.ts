// Disabled diagnostic prototype. Never deploy on bay-drive or a production route.
import worker, { GameRoom as BaseRoom, GlobalChat, DriverProfile, RoomEconomy, GlobalIncome, GlobalEarningsEvent, MarketService } from '../worker/index';
import { isDiagnosticPreview } from '../worker/input-diagnostic-guard';
import { addPlayer,createWorld,type World,type Entity,type DiagnosticSubstepHooks } from '../shared/game';
import { terrainHeight } from '../shared/map';
import { prepareSnapshots } from '../worker/snapshot';
import type { ScheduledInput } from '../shared/tick-input';
import { SlotAdmissions,ContactTrace,unsupportedPose,type TracePose } from './hosted-stage-core';
import { groundSweep,overlaps,staticSweepProblem,surfaceSweepProblem,type Bounds } from './ground-sweep';
import report from './preflight-result.json';
export {GlobalChat,DriverProfile,RoomEconomy,GlobalIncome,GlobalEarningsEvent,MarketService};
type Session={id:string;guest:boolean;attachPending:boolean;poseRevision:number;control:ScheduledInput;economy:{sync():number|undefined}|null;syncToken:number};
type Pose={x:number;z:number;yaw:number};
const poses:Pose[]=report.poses;
if(poses.length!==64)throw new Error('Diagnostic requires 64 candidate lane positions');
function free(world:World,pose:Pose,exclude:string):boolean{
  const trial=structuredClone(world);trial.entities=trial.entities.filter(e=>e.id!==exclude);
  try{const p=addPlayer(trial,'__staging_check__','Staging check',[pose]);const car=trial.entities.find(e=>e.id===p.entityId);
    return !!car&&car.x===pose.x&&car.z===pose.z&&car.yaw===pose.yaw;}catch{return false;}
}
export class GameRoom extends BaseRoom {
  private expected=(()=>{
    const value=Reflect.get(this.env,'LAB_EXPECTED_DRIVERS');
    if(value===undefined||value==='64')return 64;
    if(value==='2')return 2;
    throw new Error('Expected driver count must be 2 or 64');
  })();
  private admissions=new SlotAdmissions(this.expected);private sequence:Promise<unknown>=Promise.resolve();
  private slots=new Map<string,number>();private ambient:string[]=[];
  private paused?:World;private started?:World;private startedAtTick:number|null=null;private heartbeat?:ReturnType<typeof setInterval>;
  // Instrumented decisions still do not establish complete contact coverage.
  private trace=new ContactTrace(this.expected,1_048_576,4096,false);
  private beforeHealth=new Map<number,number>();
  private revisions=new Map<string,number>();
  private activeSubstep:{tick:number;index:number;count:number}|null=null;
  private groundStarts=new Map<string,{x:number;z:number;kind:Entity['kind'];supportId:Entity['supportId'];inDome:boolean;loopAngle:number|null}>();
  private groundPaths=new Map<string,{bounds:Bounds;from:{x:number;z:number};x:number;z:number;slot:number|undefined}>();
  private untracedGround=false;
  private done=new Set<number>();private recording=true;
  private sessionsForLab(){return Reflect.get(this,'sessions') as Map<WebSocket,Session>;}
  private worldForLab(){return Reflect.get(this,'world') as World;}
  private tickForLab(){return Reflect.get(this,'tickCount') as number;}
  private checkRoom(room:string){if(!this.ctx.id.equals(this.env.ROOMS.idFromName(room)))throw new Error('Room identity mismatch');}
  private publish(){
    const world=this.worldForLab(),sessions=this.sessionsForLab();
    if(world!==this.paused||!sessions.size){if(this.heartbeat!==undefined)clearInterval(this.heartbeat);this.heartbeat=undefined;return;}
    const data=prepareSnapshots(world,this.tickForLab(),Reflect.get(this,'roomEpoch') as string,Reflect.get(this,'lastSubsteps') as number);
    for(const [socket,s] of sessions)try{socket.send(data(s.id,s.control.snapshot(),s.poseRevision,s.economy?.sync()??s.syncToken));}catch{}
  }
  private guarded(run:()=>void){try{run();}catch{this.trace.invalid=true;}}
  private inspect(world:World,tick:number,substep:number,substeps:number):TracePose[]{
    const samples:TracePose[]=[],sessions=new Map([...this.sessionsForLab().values()].map(s=>[s.id,s]));
    for(const entity of world.entities){
      if(!entity.driver)continue;const slot=this.slots.get(entity.driver);if(slot===undefined)continue;
      const s=sessions.get(entity.driver),p=world.players.find(player=>player.id===entity.driver);
      if(!s||p?.entityId!==entity.id||s.poseRevision!==this.revisions.get(entity.driver)){
        this.trace.event({tick,substep,slot,kind:'unsupported',reason:'identity-or-revision-changed'});
      }
      const reason=unsupportedPose(entity,poses[slot],report.startZ,report.endZ);
      if(reason)this.trace.event({tick,substep,slot,kind:'unsupported',reason});
      samples.push({tick,substep,substeps,slot,x:entity.x,y:entity.y,z:entity.z,speed:entity.speed,support:entity.supportId});
    }
    if(samples.length!==this.expected||new Set(samples.map(sample=>sample.slot)).size!==this.expected)this.trace.invalid=true;
    return samples;
  }
  private substepHooks():DiagnosticSubstepHooks{return {
    begin:(index,count,world)=>this.guarded(()=>{
      if(!this.recording)return;
      if(world!==this.started||this.activeSubstep!==null){this.trace.invalid=true;return;}
      const tick=this.tickForLab()+1;this.activeSubstep={tick,index,count};this.inspect(world,tick,index,count);
      this.groundStarts.clear();this.groundPaths.clear();this.untracedGround=false;
      if(world.entities.length>256){this.trace.overflow=true;return;}
      for(const e of world.entities){
        if(this.groundStarts.has(e.id))this.untracedGround=true;
        this.groundStarts.set(e.id,{x:e.x,z:e.z,kind:e.kind,supportId:e.supportId,inDome:e.inDome,loopAngle:e.loopAngle});
      }
    }),
    event:(index,kind,entity,other,reason)=>this.guarded(()=>{
      if(!this.recording)return;
      const active=this.activeSubstep;if(!active||active.index!==index){this.trace.invalid=true;return;}
      for(const target of [entity,other]){
        const slot=target?.driver?this.slots.get(target.driver):undefined;if(slot===undefined)continue;
        this.trace.event({tick:active.tick,substep:index,slot,kind,reason});
      }
    }),
    groundMove:(index,entity,from)=>this.guarded(()=>{
      if(!this.recording||this.trace.overflow)return;
      const active=this.activeSubstep,start=this.groundStarts.get(entity.id);
      if(!active||active.index!==index||!start||this.groundPaths.has(entity.id)){this.untracedGround=true;return;}
      const bounds=groundSweep(entity.kind,from,entity);
      if(!bounds||start.kind!==entity.kind||start.x!==from.x||start.z!==from.z||start.supportId!=='ground'||
        from.supportId!=='ground'||entity.supportId!=='ground'||start.inDome||entity.inDome||start.loopAngle!==null||entity.loopAngle!==null){
        this.untracedGround=true;return;
      }
      this.groundPaths.set(entity.id,{bounds,from:{x:from.x,z:from.z},x:entity.x,z:entity.z,slot:entity.driver?this.slots.get(entity.driver):undefined});
    }),
    end:(index,count,world)=>this.guarded(()=>{
      if(!this.recording)return;
      const active=this.activeSubstep;
      if(!active||active.index!==index||active.count!==count||world!==this.started){this.trace.invalid=true;return;}
      if(this.trace.overflow){this.activeSubstep=null;return;}
      if(this.groundStarts.size!==world.entities.length||this.groundPaths.size!==world.entities.length)this.untracedGround=true;
      for(const e of world.entities){
        const path=this.groundPaths.get(e.id);
        if(!path||e.x!==path.x||e.z!==path.z||e.supportId!=='ground'||e.inDome||e.loopAngle!==null)this.untracedGround=true;
      }
      if(this.untracedGround)this.trace.event({tick:active.tick,substep:index,slot:0,kind:'unsupported',reason:'untraced-entity-path'});
      const paths=[...this.groundPaths.values()];
      for(let i=0;i<paths.length&&!this.trace.overflow;i++){
        const path=paths[i];
        if(path.slot!==undefined){
          const reason=staticSweepProblem(path.bounds);if(reason)this.trace.event({tick:active.tick,substep:index,slot:path.slot,kind:'other',reason});
          const surface=surfaceSweepProblem(path.from,path);if(surface)this.trace.event({tick:active.tick,substep:index,slot:path.slot,kind:'unsupported',reason:surface});
        }
        for(let j=i+1;j<paths.length&&!this.trace.overflow;j++){
          const other=paths[j];if(path.slot===undefined&&other.slot===undefined||!overlaps(path.bounds,other.bounds))continue;
          for(const slot of [path.slot,other.slot])if(slot!==undefined)this.trace.event({tick:active.tick,substep:index,slot,kind:'other',reason:'possible-swept-entity'});
        }
      }
      const samples=this.inspect(world,active.tick,index,count);
      for(const sample of samples){
        const entity=world.entities.find((e:Entity)=>e.driver&&this.slots.get(e.driver)===sample.slot)!;
        const health=this.beforeHealth.get(sample.slot);this.beforeHealth.set(sample.slot,entity.health);
        if((health!==undefined&&entity.health<health-.001)||Math.hypot(entity.pushX,entity.pushZ)>.1)
          this.trace.event({tick:active.tick,substep:index,slot:sample.slot,kind:'other',reason:'damage-or-impulse'});
      }
      this.trace.substep(active.tick,index,count,samples);this.activeSubstep=null;
    }),
  };}
  labStatus(room:string){
    this.checkRoom(room);const world=this.worldForLab(),entries=[...this.sessionsForLab()];
    const staged=entries.map(([socket,s])=>{
      const slot=this.slots.get(s.id),p=world.players.find(x=>x.id===s.id),car=world.entities.find(x=>x.id===p?.entityId),pose=slot===undefined?undefined:poses[slot];
      return {slot,connected:socket.readyState===1,guest:s.guest,economy:!!s.economy,attachPending:s.attachPending,
        exact:!!pose&&!!car&&car.x===pose.x&&car.z===pose.z&&car.yaw===pose.yaw};
    });
    const ready=this.paused===world&&this.admissions.complete&&staged.length===this.expected&&
      staged.every(s=>s.connected&&s.guest&&s.economy&&!s.attachPending&&s.exact);
    return {ready,started:this.started===world,startedAtTick:this.startedAtTick,tick:this.tickForLab(),substeps:Reflect.get(this,'lastSubsteps') as number,expectedDrivers:this.expected,staged,doneGroups:this.done.size,ambientInitial:this.ambient.length,
      ambientRetained:this.ambient.filter(id=>world.entities.some(e=>e.id===id)).length,trace:this.trace.summary()};
  }
  labBegin(room:string){
    const status=this.labStatus(room);if(!status.ready||status.started||!this.admissions.seal())return {ok:false,...status};
    const world=this.paused!;
    if(this.heartbeat!==undefined)clearInterval(this.heartbeat);this.heartbeat=undefined;
    for(const [socket,s] of this.sessionsForLab())Reflect.apply(Reflect.get(this,'invalidate'),this,[socket,s]);
    this.publish();this.paused=undefined;this.started=world;this.startedAtTick=status.tick;
    this.trace=new ContactTrace(this.expected,1_048_576,4096,false,status.tick+1);
    this.revisions=new Map([...this.sessionsForLab().values()].map(s=>[s.id,s.poseRevision]));
    this.diagnosticSimulationHooks=this.substepHooks();
    Reflect.apply(Reflect.get(this,'startTicks'),this,[]);
    return {ok:true,tick:status.tick};
  }
  labTrace(room:string,offset:number,limit:number){
    this.checkRoom(room);
    if(this.done.size!==4||this.recording)throw new Error('Trace is not sealed');
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>1000)throw new Error('Invalid trace page');
    return {summary:this.trace.summary(),offset,poses:this.trace.posePage(offset,limit),events:this.trace.events.slice(offset,offset+limit)};
  }
  labDone(room:string,group:number){
    this.checkRoom(room);
    if(this.started!==this.worldForLab()||!Number.isInteger(group)||group<1||group>4||this.done.has(group))return {ok:false,doneGroups:this.done.size};
    this.done.add(group);if(this.done.size===4){this.recording=false;if(this.activeSubstep)this.trace.invalid=true;this.trace.seal(this.tickForLab());this.diagnosticSimulationHooks=undefined;}
    return {ok:true,doneGroups:this.done.size};
  }
  override async fetch(request:Request):Promise<Response>{
    const raw=request.headers.get('x-lab-slot'),slot=raw!==null&&/^\d{1,2}$/.test(raw)?Number(raw):-1;
    if(!this.admissions.reserve(slot))return new Response('Slot unavailable',{status:409});
    const task=this.sequence.then(()=>this.stage(request,slot));this.sequence=task.then(()=>undefined,()=>undefined);return task;
  }
  private async stage(request:Request,slot:number):Promise<Response>{
    let world=this.worldForLab();const sessions=this.sessionsForLab();
    if(this.started===world)return new Response('Already started',{status:409});
    if(!this.paused&&!sessions.size&&!world.players.length&&this.tickForLab()===0){
      const oldMars=world.mars;world=createWorld(0);world.mars.fund=oldMars.fund;world.mars.roomFund=oldMars.roomFund;
      this.ambient=world.entities.map(e=>e.id);Reflect.set(this,'world',world);
    }
    const before=new Set(sessions.keys()),response=await super.fetch(request);
    if(response.status!==101)return response;
    Reflect.apply(Reflect.get(this,'stopTicks'),this,[]);world=this.worldForLab();
    const joined=[...sessions].filter(([socket])=>!before.has(socket));
    if(joined.length!==1){for(const [socket] of joined)socket.close(1011,'Staging identity unavailable');return response;}
    const [socket,s]=joined[0],p=world.players.find(x=>x.id===s.id),car=world.entities.find(x=>x.id===p?.entityId),pose=poses[slot];
    if(!car||!pose||!free(world,pose,car.id)){socket.close(1011,'Staging pose unavailable');return response;}
    const y=terrainHeight(pose.x,pose.z);if(y===null){socket.close(1011,'Staging support unavailable');return response;}
    Object.assign(car,pose,{y,vx:0,vy:0,vz:0,speed:0,pushX:0,pushZ:0,pitch:0,roll:0,pitchRate:0,yawRate:0,rollRate:0,supportId:'ground',autopilot:false,navigation:null});
    this.slots.set(s.id,slot);if(!this.admissions.stage(slot)){socket.close(1011,'Staging slot invalid');return response;}
    this.paused=world;Reflect.apply(Reflect.get(this,'invalidate'),this,[socket,s,true]);this.publish();
    if(this.heartbeat===undefined)this.heartbeat=setInterval(()=>this.publish(),1000);
    return response;
  }
}

export default {async fetch(request:Request,env:Parameters<typeof worker.fetch>[1],ctx:ExecutionContext):Promise<Response>{
  const url=new URL(request.url);
  if(!isDiagnosticPreview(url,Reflect.get(env,'INPUT_DIAGNOSTIC_PREVIEW')))return new Response('Diagnostic preview only',{status:403});
  if(url.pathname==='/api/health'&&request.method==='GET')return worker.fetch(request,env,ctx);
  const secret=Reflect.get(env,'LAB_STAGE_TOKEN'),provided=/^Bearer ([0-9a-f]{64})$/.exec(request.headers.get('Authorization')??'')?.[1];
  if(typeof secret!=='string'||!/^[0-9a-f]{64}$/.test(secret)||!provided||
    !crypto.subtle.timingSafeEqual(new TextEncoder().encode(secret),new TextEncoder().encode(provided)))return new Response('Unauthorized',{status:401});
  const roomMatch=/^\/api\/room\/(gha-[0-9]{1,20}-[0-9]{1,4})$/.exec(url.pathname);
  if(roomMatch&&request.method==='GET'){
    const headers=new Headers(request.headers);headers.delete('Authorization');
    return worker.fetch(new Request(request,{headers}),env,ctx);
  }
  const operation=/^\/api\/lab\/(status|begin|done|trace)\/(gha-[0-9]{1,20}-[0-9]{1,4})$/.exec(url.pathname);
  if(!operation)return new Response('Unknown diagnostic path',{status:404});
  if((['begin','done'].includes(operation[1])&&request.method!=='POST')||(!['begin','done'].includes(operation[1])&&request.method!=='GET'))return new Response('Method not allowed',{status:405});
  const room=operation[2],obj=(env.ROOMS as unknown as DurableObjectNamespace<GameRoom>).get(env.ROOMS.idFromName(room));
  if(operation[1]==='status')return Response.json(await obj.labStatus(room));
  if(operation[1]==='begin'){const value=await obj.labBegin(room);return Response.json(value,{status:value.ok?200:409});}
  if(operation[1]==='done'){const value=await obj.labDone(room,Number(request.headers.get('x-lab-group')));return Response.json(value,{status:value.ok?200:409});}
  const offset=Number(url.searchParams.get('offset')??0),limit=Number(url.searchParams.get('limit')??1000);
  if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>1000)return new Response('Invalid trace page',{status:400});
  if((await obj.labStatus(room)).doneGroups!==4)return new Response('Trace not sealed',{status:409});
  return Response.json(await obj.labTrace(room,offset,limit));
}};
