import test from 'node:test';
import assert from 'node:assert/strict';
import { addPlayer,createEmptyWorld,NEUTRAL,PROTOCOL_VERSION,step,type Entity,type World } from '../shared/game';
import { FERRY_DOCKS } from '../shared/map';
import { body,contact } from '../shared/physics';
import { ScheduledInput } from '../shared/tick-input';
import { Session } from '../src/session';
import type { Ferry } from '../shared/ferry';

class Socket {static OPEN=1;static last:Socket;readyState=Socket.OPEN;sent:string[]=[];onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}send(value:string){this.sent.push(value);}close(){this.readyState=3;}message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});
const idset=(f:Ferry)=>f.passengers.map(p=>p.entityId).sort().join(',');

for(const phase of ['departure','arrival'] as const)test(`ferry phase and membership track its replayed hull through ${phase}`,()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Passenger');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];
  if(phase==='arrival'){
    world.ferry.phase='to-island';world.ferry.remaining=.15;world.ferry.z=FERRY_DOCKS.island.deckZ+.5*3*.15**2;
    world.ferry.passengers=[{entityId:local.id,x:-3,z:0},{entityId:peer.id,x:3,z:0}];
  }else world.ferry.remaining=.15;
  Object.assign(local,{x:-3,z:world.ferry.z,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  Object.assign(peer,{x:3,z:world.ferry.z,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,stable=0;const mismatches:unknown[]=[];
  for(let frame=0;frame<=60;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL],['q',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld();
    const prediction=Reflect.get(session,'prediction'),segment=Reflect.get(prediction,'segment') as {ferryBefore:Ferry;ferryAfter:Ferry}|null;
    if(!segment||segment.ferryBefore.phase!==segment.ferryAfter.phase||idset(segment.ferryBefore)!==idset(segment.ferryAfter))continue;
    stable++;
    const expected=segment.ferryBefore;
    if(shown.ferry.phase!==expected.phase||idset(shown.ferry)!==idset(expected))mismatches.push({frame,now,
      displayed:{phase:shown.ferry.phase,passengers:idset(shown.ferry),z:shown.ferry.z,remaining:shown.ferry.remaining},
      expected:{phase:expected.phase,passengers:idset(expected),z:expected.z,remaining:expected.remaining},authority:{phase:world.ferry.phase,passengers:idset(world.ferry),z:world.ferry.z}});
  }
  console.log('FERRY_COHERENCE',JSON.stringify({phase,stable,mismatchCount:mismatches.length,first:mismatches[0]}));
  assert.ok(stable>0,'exercised stable replay intervals');assert.deepEqual(mismatches,[]);
  session.disconnect();
});

for(const phase of ['departure','arrival'] as const)test(`ferry does not display an unconfirmed ${phase}`,()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');const local=world.entities.find(entity=>entity.driver==='p')!;
  world.entities=[local];world.pickups=[];
  if(phase==='arrival'){
    world.ferry.phase='to-island';world.ferry.remaining=.15;world.ferry.z=FERRY_DOCKS.island.deckZ+.5*3*.15**2;
    world.ferry.passengers=[{entityId:local.id,x:0,z:0}];
  }else world.ferry.remaining=.15;
  Object.assign(local,{x:0,z:world.ferry.z,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0;const early:unknown[]=[];
  for(let frame=0;frame<=42;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld();
    const predictedTransition=phase==='departure'?shown.ferry.phase==='to-island':shown.ferry.phase==='island';
    const actualTransition=phase==='departure'?world.ferry.phase==='to-island':world.ferry.phase==='island';
    if(predictedTransition&&!actualTransition)early.push({frame,now,shown:shown.ferry.phase,authority:world.ferry.phase});
  }
  console.log('FERRY_EARLY',JSON.stringify({phase,count:early.length,first:early[0]}));
  assert.deepEqual(early,[]);session.disconnect();
});

test('a confirmed blocked ramp stays blocked while replay waits for departure',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Shore obstruction');
  const local=world.entities.find(entity=>entity.driver==='p')!,shore=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,shore];world.pickups=[];world.ferry.remaining=0;world.ferry.blocked='ramp';
  Object.assign(local,{x:0,z:-268,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  Object.assign(shore,{x:0,z:-254,y:0,yaw:0,supportId:'ground',speed:0,vx:0,vz:0});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0;const mismatches:unknown[]=[];
  for(let frame=0;frame<=36;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL],['q',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    assert.equal(world.ferry.blocked,'ramp',`authority at frame ${frame}`);
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld();
    if(shown.ferry.blocked!=='ramp'||shown.ferry.remaining!==0)mismatches.push({frame,now,
      shown:{blocked:shown.ferry.blocked,remaining:shown.ferry.remaining},authority:{blocked:world.ferry.blocked,remaining:world.ferry.remaining}});
  }
  console.log('FERRY_BLOCKED_RAMP',JSON.stringify({count:mismatches.length,first:mismatches[0]}));
  assert.deepEqual(mismatches,[]);session.disconnect();
});

test('arrival keeps the secured local car and another passenger on the displayed hull',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Passenger');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];world.ferry.phase='to-island';world.ferry.remaining=.05;
  world.ferry.z=FERRY_DOCKS.island.deckZ+.5*3*.05**2;
  world.ferry.passengers=[{entityId:local.id,x:0,z:0},{entityId:peer.id,x:3,z:-8}];
  Object.assign(local,{x:world.ferry.x,z:world.ferry.z,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  Object.assign(peer,{x:world.ferry.x+3,z:world.ferry.z-8,y:0,yaw:0,supportId:'ferry',speed:0,vx:0,vz:0});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,max=0;const mismatches:unknown[]=[];
  for(let frame=0;frame<=36;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL],['q',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld(),car=shown.entities.find(entity=>entity.driver==='p')!,other=shown.entities.find(entity=>entity.driver==='q')!;
    const localDelta=Math.hypot(car.x-shown.ferry.x,car.z-shown.ferry.z),peerDelta=Math.hypot(other.x-shown.ferry.x-3,other.z-shown.ferry.z+8);
    const delta=Math.max(localDelta,peerDelta);max=Math.max(max,delta);
    if(delta>1e-6&&mismatches.length<2){const segment=Reflect.get(Reflect.get(session,'prediction'),'segment');mismatches.push({frame,now,localDelta,peerDelta,
      ferry:shown.ferry,local:{x:car.x,z:car.z},peer:{x:other.x,z:other.z},segment:segment&&{before:segment.ferryBefore,after:segment.ferryAfter,previous:segment.previous,next:segment.next}});}
  }
  console.log('FERRY_HULL_DETAIL',JSON.stringify({max,first:mismatches[0]}));
  assert.ok(max<1e-6,`hull mismatch ${max}`);session.disconnect();
});

test('two moving deck cars stay safe when the leading rider brakes unexpectedly',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Leading rider');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];
  Object.assign(local,{x:0,z:-262.5,y:0,yaw:0,supportId:'ferry',speed:6,vx:0,vz:-6});
  Object.assign(peer,{x:0,z:-267.05,y:0,yaw:0,supportId:'ferry',speed:6,vx:0,vz:-6});
  const input={...NEUTRAL,throttle:.1};let peerInput={...input};
  const control=new ScheduledInput(input).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,maxDepth=0,authorityDepth=0,held=0,maxHeld=0,maxStep=0,previous:Entity|undefined,firstHit:unknown=null;
  for(let frame=0;frame<=120;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',input],['q',peerInput]]),.05,{substeps:5});
      authorityDepth=Math.max(authorityDepth,contact(body(local),body(peer))?.depth??0);if(tick%2===0)state(tick);}
    if(frame===12)peerInput={...peerInput,brake:true};
    session.tick(1/120,input);const shown=session.renderWorld(),p=shown.entities.find(entity=>entity.driver==='p')!,q=shown.entities.find(entity=>entity.driver==='q')!;
    const depth=contact(body(p),body(q))?.depth??0;maxDepth=Math.max(maxDepth,depth);
    if(depth>.05&&!firstHit)firstHit={frame,now,depth,shown:{local:p.z,peer:q.z},authority:{local:local.z,peer:peer.z},latest:session.world.entities.find(entity=>entity.driver==='q')?.z};
    held=Reflect.get(Reflect.get(session,'prediction'),'presentationHeld')?held+1:0;maxHeld=Math.max(maxHeld,held);
    if(previous)maxStep=Math.max(maxStep,Math.hypot(p.x-previous.x,p.y-previous.y,p.z-previous.z));previous=p;
    assert.equal(session.takePresentationSnap(),false,`frame ${frame}`);
  }
  console.log('MOVING_DECK_BRAKE',JSON.stringify({maxDepth,authorityDepth,maxHeld,maxStep,firstHit,peerSpeed:peer.speed,localSpeed:local.speed}));
  assert.ok(authorityDepth<.05,`authority depth ${authorityDepth}`);
  assert.ok(maxDepth<.05,`displayed depth ${maxDepth}`);assert.ok(maxHeld<=6,`held ${maxHeld} frames`);assert.ok(maxStep<1,`local step ${maxStep}`);
  session.disconnect();
});

test('a shore driver stays clear when a deck rider brakes unexpectedly',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Shore driver');addPlayer(world,'q','Deck rider');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];
  Object.assign(local,{x:0,z:-253,y:0,yaw:0,supportId:'ground',speed:6,vx:0,vz:-6});
  Object.assign(peer,{x:0,z:-257.55,y:0,yaw:0,supportId:'ferry',speed:6,vx:0,vz:-6});
  const input={...NEUTRAL,throttle:.1};let peerInput={...input};
  const control=new ScheduledInput(input).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,maxDepth=0,authorityDepth=0,held=0,maxHeld=0,maxStep=0,previous:Entity|undefined,firstHit:unknown=null,shoreFrames=0;
  for(let frame=0;frame<=36;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',input],['q',peerInput]]),.05,{substeps:5});
      authorityDepth=Math.max(authorityDepth,contact(body(local),body(peer))?.depth??0);if(tick%2===0)state(tick);}
    if(frame===6)peerInput={...peerInput,brake:true};
    session.tick(1/120,input);const shown=session.renderWorld(),p=shown.entities.find(entity=>entity.driver==='p')!,q=shown.entities.find(entity=>entity.driver==='q')!;
    if(p.supportId==='ground')shoreFrames++;
    const depth=contact(body(p),body(q))?.depth??0;maxDepth=Math.max(maxDepth,depth);
    if(depth>.05&&!firstHit)firstHit={frame,now,depth,shown:{local:p.z,peer:q.z},authority:{local:local.z,peer:peer.z},latest:session.world.entities.find(entity=>entity.driver==='q')?.z};
    held=Reflect.get(Reflect.get(session,'prediction'),'presentationHeld')?held+1:0;maxHeld=Math.max(maxHeld,held);
    if(previous)maxStep=Math.max(maxStep,Math.hypot(p.x-previous.x,p.y-previous.y,p.z-previous.z));previous=p;
    assert.equal(session.takePresentationSnap(),false,`frame ${frame}`);
  }
  console.log('SHORE_DECK_BRAKE',JSON.stringify({shoreFrames,maxDepth,authorityDepth,maxHeld,maxStep,firstHit}));
  assert.ok(shoreFrames>0,'exercised the shore side of the seam');assert.ok(authorityDepth<.05,`authority depth ${authorityDepth}`);
  assert.ok(maxDepth<.05,`displayed depth ${maxDepth}`);assert.ok(maxHeld<=6,`held ${maxHeld} frames`);assert.ok(maxStep<1,`local step ${maxStep}`);
  session.disconnect();
});

for(const operation of ['boarding','disembarking'] as const)test(`moving local and remote riders stay continuous through ${operation}`,()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Deck rider');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];
  if(operation==='boarding')Object.assign(local,{x:0,z:-252,y:0,yaw:0,supportId:'ground',speed:5,vx:0,vz:-5});
  else Object.assign(local,{x:0,z:-258,y:0,yaw:0,supportId:'ferry',speed:-5,vx:0,vz:5});
  Object.assign(peer,{x:3.5,z:-270,y:0,yaw:0,supportId:'ferry',speed:2,vx:0,vz:-2});
  const input={...NEUTRAL,throttle:operation==='boarding'?.25:-.25},peerInput={...NEUTRAL,throttle:.1};
  const control=new ScheduledInput(input).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,authorityTransition=false,presentationTransition=false,maxStep=0,maxDepth=0,held=0,maxHeld=0,previous:Entity|undefined,previousPeer:Entity|undefined,maxPeerStep=0,firstSnap:unknown=null;
  for(let frame=0;frame<=240;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',input],['q',peerInput]]),.05,{substeps:5});
      if(local.supportId===(operation==='boarding'?'ferry':'ground'))authorityTransition=true;if(tick%2===0)state(tick);}
    session.tick(1/120,input);const shown=session.renderWorld(),p=shown.entities.find(entity=>entity.driver==='p')!,q=shown.entities.find(entity=>entity.driver==='q')!;
    if(p.supportId===(operation==='boarding'?'ferry':'ground'))presentationTransition=true;
    maxDepth=Math.max(maxDepth,contact(body(p),body(q))?.depth??0);
    held=Reflect.get(Reflect.get(session,'prediction'),'presentationHeld')?held+1:0;maxHeld=Math.max(maxHeld,held);
    if(previous)maxStep=Math.max(maxStep,Math.hypot(p.x-previous.x,p.y-previous.y,p.z-previous.z));
    if(previousPeer)maxPeerStep=Math.max(maxPeerStep,Math.hypot(q.x-previousPeer.x,q.y-previousPeer.y,q.z-previousPeer.z));
    const snap=session.takePresentationSnap();if(snap&&!firstSnap)firstSnap={frame,now,position:p.z,support:p.supportId};
    previous=p;previousPeer=q;
  }
  console.log('FERRY_MOVING_TRANSITION',JSON.stringify({operation,authorityTransition,presentationTransition,maxStep,maxPeerStep,maxDepth,maxHeld,firstSnap,localEnd:local.z,peerEnd:peer.z}));
  assert.ok(authorityTransition&&presentationTransition,'actual and displayed support transitions occurred');
  assert.equal(firstSnap,null,'local presentation should not snap');
  assert.ok(maxStep<1&&maxPeerStep<1,`steps ${maxStep}/${maxPeerStep}`);assert.ok(maxDepth<.05,`displayed depth ${maxDepth}`);assert.ok(maxHeld<=6,`held ${maxHeld} frames`);
  session.disconnect();
});
