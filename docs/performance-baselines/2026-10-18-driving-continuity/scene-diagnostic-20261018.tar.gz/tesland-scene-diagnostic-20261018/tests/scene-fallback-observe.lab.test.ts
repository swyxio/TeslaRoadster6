import test from 'node:test';
import assert from 'node:assert/strict';
import { Vector3 } from 'three';
import { addPlayer, createEmptyWorld, NEUTRAL, PROTOCOL_VERSION, step } from '../shared/game';
import { ScheduledInput } from '../shared/tick-input';
import { Session } from '../src/session';
import { placeSceneVehicle } from '../src/scene-placement.lab';
class Socket {
  static OPEN=1;static last:Socket;readyState=Socket.OPEN;
  onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}send(_value:string){}close(){this.readyState=3;}
  message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});

test('observe raw fallback around a server recovery while moving',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');const car=world.entities.find(entity=>entity.driver==='p')!;
  world.entities=[car];world.pickups=[];Object.assign(car,{x:600,y:.6,z:-2250,yaw:-Math.PI/2,supportId:null,speed:20,vx:20,vy:-5,vz:0});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,oldX:number|undefined,maxStep=0,maxBeforeRecovery=0,maxFormerBeforeRecovery=0;
  const direct=new Vector3(car.x,car.y,car.z),former=direct.clone(),alpha=1-Math.exp(-14/120),frames:unknown[]=[];
  for(let frame=0;frame<=36;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld().entities.find(entity=>entity.driver==='p')!;
    const snap=session.takePresentationSnap(),camera=session.takeCameraSnap();
    const before=direct.clone(),beforeFormer=former.clone(),target=new Vector3(shown.x,shown.y,shown.z);
    const options={onFerry:false,wasOnFerry:false,ferryPosition:new Vector3(),worldFerry:{x:0,z:0},ferryMotion:new Vector3(),
      controlled:true,snapLocal:snap,previousPredicted:false,localPredicted:session.localPresentationActive,interpolatedRemote:false,alpha};
    placeSceneVehicle(direct,target.clone(),{...options,networkSampled:true});
    placeSceneVehicle(former,target.clone(),{...options,networkSampled:false});
    if(frame<=12){maxBeforeRecovery=Math.max(maxBeforeRecovery,direct.distanceTo(before));maxFormerBeforeRecovery=Math.max(maxFormerBeforeRecovery,former.distanceTo(beforeFormer));}
    const dist=oldX===undefined?0:Math.abs(shown.x-oldX);maxStep=Math.max(maxStep,dist);
    if(frame%6===0||dist>.5)frames.push({frame,now,x:shown.x,y:shown.y,step:dist,authX:car.x,authY:car.y,local:session.localPresentationActive,remote:session.remotePresentationActive,exhausted:session.presentationHistoryExhausted,snap,camera});
    oldX=shown.x;
  }
  console.log('REAL_FALLBACK_TRACE',JSON.stringify({maxStep,maxBeforeRecovery,maxFormerBeforeRecovery,frames}));
  assert.equal(session.presentationHistoryExhausted,false);
  assert.ok(maxBeforeRecovery<1,`pre-recovery direct scene step ${maxBeforeRecovery} m`);
});
