import test from 'node:test';
import assert from 'node:assert/strict';
import { Vector3 } from 'three';
import { makeEntity } from '../shared/game';
import { createFerry, FERRY_DECK, onFerryDeck, whollyOnFerry } from '../shared/ferry';
import { terrainHeight } from '../shared/map';
import { body, contact, dimensions } from '../shared/physics';
import { placeSceneFerry, placeSceneVehicle } from '../src/scene-placement.lab';

const alpha=1-Math.exp(-14/120);
const place=(position:Vector3,target:Vector3,options:{onFerry:boolean;wasOnFerry:boolean;ferryPosition:Vector3;worldFerry:{x:number;z:number};ferryMotion:Vector3;controlled:boolean})=>
  placeSceneVehicle(position,target,{...options,snapLocal:false,previousPredicted:options.controlled,localPredicted:true,
    interpolatedRemote:!options.controlled,networkSampled:true,alpha});

test('scene smoothing keeps a dock rider clear of a co-timed shore car',()=>{
  const ferry=createFerry(),length=dimensions('roadster').length;
  const shore=makeEntity('shore','roadster',0,-254.5),rider=makeEntity('rider','roadster',0,shore.z-length-.05);
  rider.supportId='ferry';shore.supportId='ground';
  const riderGoal={...rider,z:rider.z-.2},shoreGoal={...shore,z:shore.z-.2};
  assert.ok(onFerryDeck(ferry,rider.x,rider.z)&&onFerryDeck(ferry,riderGoal.x,riderGoal.z));
  assert.equal(terrainHeight(shore.x,shore.z),0);assert.equal(terrainHeight(shoreGoal.x,shoreGoal.z),0);
  assert.equal(contact(body(rider),body(shore)),null);assert.equal(contact(body(riderGoal),body(shoreGoal)),null);
  const hull=new Vector3(ferry.x,0,ferry.z),motion=new Vector3();
  const shownRider=new Vector3(rider.x,rider.y,rider.z),shownShore=new Vector3(shore.x,shore.y,shore.z);
  place(shownRider,new Vector3(riderGoal.x,riderGoal.y,riderGoal.z),{onFerry:true,wasOnFerry:true,ferryPosition:hull,worldFerry:ferry,ferryMotion:motion,controlled:true});
  place(shownShore,new Vector3(shoreGoal.x,shoreGoal.y,shoreGoal.z),{onFerry:false,wasOnFerry:false,ferryPosition:hull,worldFerry:ferry,ferryMotion:motion,controlled:false});
  const depth=contact(body({...rider,x:shownRider.x,z:shownRider.z}),body({...shore,x:shownShore.x,z:shownShore.z}))?.depth??0;
  console.log('SCENE_DOCK_COTIMING',JSON.stringify({alpha,depth,shownRider:shownRider.z,shownShore:shownShore.z}));
  assert.ok(depth<.05,`displayed contact depth ${depth}`);
});

test('scene hull lag keeps a departing rider clear of co-timed shore traffic',()=>{
  const previous=createFerry(),next={...previous,phase:'to-island' as const,z:previous.z-.5};
  const rider=makeEntity('rider','roadster',0,previous.z+FERRY_DECK.length/2-dimensions('roadster').length/2);
  rider.supportId='ferry';
  const shore=makeEntity('shore','roadster',0,rider.z+dimensions('roadster').length+.05);shore.supportId='ground';
  const riderGoal={...rider,z:rider.z-.5},shoreGoal={...shore,z:shore.z-.5};
  const deck=(z:number)=>({x:previous.x,z,w:FERRY_DECK.width,d:FERRY_DECK.length,yaw:0});
  assert.ok(whollyOnFerry(previous,rider)&&whollyOnFerry(next,riderGoal));
  assert.equal(contact(body(shore),deck(previous.z)),null);assert.equal(contact(body(shoreGoal),deck(next.z)),null);
  assert.equal(contact(body(rider),body(shore)),null);assert.equal(contact(body(riderGoal),body(shoreGoal)),null);
  assert.equal(terrainHeight(shore.x,shore.z),0);assert.equal(terrainHeight(shoreGoal.x,shoreGoal.z),0);
  const oldHull=new Vector3(previous.x,0,previous.z),visualHull=oldHull.clone();
  placeSceneFerry(visualHull,new Vector3(next.x,0,next.z),true,alpha);
  const motion=visualHull.clone().sub(oldHull),shownRider=new Vector3(rider.x,rider.y,rider.z),shownShore=new Vector3(shore.x,shore.y,shore.z);
  place(shownRider,new Vector3(riderGoal.x,riderGoal.y,riderGoal.z),{onFerry:true,wasOnFerry:true,ferryPosition:visualHull,worldFerry:next,ferryMotion:motion,controlled:true});
  place(shownShore,new Vector3(shoreGoal.x,shoreGoal.y,shoreGoal.z),{onFerry:false,wasOnFerry:false,ferryPosition:visualHull,worldFerry:next,ferryMotion:motion,controlled:false});
  const depth=contact(body({...rider,x:shownRider.x,z:shownRider.z}),body({...shore,x:shownShore.x,z:shownShore.z}))?.depth??0;
  const hullDepth=contact(body({...shore,x:shownShore.x,z:shownShore.z}),deck(visualHull.z))?.depth??0;
  console.log('SCENE_HULL_COTIMING',JSON.stringify({alpha,depth,hullDepth,shownRider:shownRider.z,shownShore:shownShore.z,visualHull:visualHull.z,targetHull:next.z}));
  assert.ok(depth<.05&&hullDepth<.05,`displayed rider/hull contact depths ${depth}/${hullDepth}`);
});
