import test from 'node:test';
import assert from 'node:assert/strict';
import { Vector3 } from 'three';
import { addPlayer, createEmptyWorld, NEUTRAL, PROTOCOL_VERSION, step } from '../shared/game';
import { FERRY_TRAVEL_SECONDS } from '../shared/ferry';
import { FERRY_DOCKS } from '../shared/map';
import { ScheduledInput } from '../shared/tick-input';
import { Session } from '../src/session';
import { placeSceneFerry, placeSceneVehicle } from '../src/scene-placement.lab';

class Socket {
  static OPEN=1;static last:Socket;readyState=Socket.OPEN;
  onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}send(_value:string){}close(){this.readyState=3;}
  message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});
const alpha=1-Math.exp(-14/120);
const placement=(position:Vector3,target:Vector3,networkSampled:boolean,onFerry:boolean,controlled:boolean,
  ferryPosition:Vector3,worldFerry:{x:number;z:number},ferryMotion:Vector3,wasOnFerry=onFerry)=>
  placeSceneVehicle(position,target,{networkSampled,onFerry,wasOnFerry,controlled,ferryPosition,worldFerry,ferryMotion,
    previousPredicted:controlled,localPredicted:true,snapLocal:false,interpolatedRemote:!controlled,alpha});

test('network placement follows the presented pose through boarding and disembarking',()=>{
  const hull=new Vector3(0,0,-274),worldFerry={x:0,z:-274},position=new Vector3(0,0,-253);
  let previousSupport=false;
  for(const next of [{z:-254,support:false},{z:-256,support:true},{z:-255,support:false}]){
    const target=new Vector3(0,0,next.z);
    const blend=placement(position,target,true,next.support,true,hull,worldFerry,new Vector3(0,0,-.5),previousSupport);
    assert.deepEqual(position.toArray(),target.toArray());assert.equal(blend,1);
    previousSupport=next.support;
  }
});

test('solo ferry and rider retain their previous smoothing',()=>{
  const hull=new Vector3(0,0,0),targetHull=new Vector3(0,0,-10);
  placeSceneFerry(hull,targetHull,false,alpha);
  assert.ok(Math.abs(hull.z-(-10*alpha))<1e-12);
  const motion=hull.clone(),rider=new Vector3(0,0,1),targetRider=new Vector3(0,0,-8.8);
  const blend=placement(rider,targetRider,false,true,true,hull,{x:0,z:-10},motion);
  assert.equal(blend,alpha);
  assert.ok(Math.abs(rider.z-(1-10*alpha+.2*alpha))<1e-12,`solo rider ${rider.z}`);
});

test('a sampled moving ferry and both passengers retain their frame and smoothness',()=>{
  let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Passenger');
  const local=world.entities.find(entity=>entity.driver==='p')!,peer=world.entities.find(entity=>entity.driver==='q')!;
  world.entities=[local,peer];world.pickups=[];
  Object.assign(world.ferry,{phase:'to-island',remaining:FERRY_TRAVEL_SECONDS-10,z:FERRY_DOCKS.sf.deckZ-20*(10-10/3),velocity:-20,
    passengers:[{entityId:local.id,x:-3,z:0},{entityId:peer.id,x:3,z:0}]});
  Object.assign(local,{x:-3,y:0,z:world.ferry.z,yaw:0,supportId:'ferry',speed:0,vx:0,vz:-20});
  Object.assign(peer,{x:3,y:0,z:world.ferry.z,yaw:0,supportId:'ferry',speed:0,vx:0,vz:-20});
  const control=new ScheduledInput(NEUTRAL).snapshot();control.heldUntilTick=1000;
  const state=(tick:number)=>socket.message({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:5});
  state(0);let tick=0,maxStep=0;const hull=new Vector3(world.ferry.x,0,world.ferry.z);
  const rider=new Vector3(local.x,local.y,local.z),other=new Vector3(peer.x,peer.y,peer.z);
  for(let frame=0;frame<=240;frame++){
    now=frame*1000/120;
    while((tick+1)*50<=now+1e-8){tick++;step(world,new Map([['p',NEUTRAL],['q',NEUTRAL]]),.05,{substeps:5});if(tick%2===0)state(tick);}
    session.tick(1/120,NEUTRAL);const shown=session.renderWorld();
    assert.equal(session.presentationHistoryExhausted,false,`live presentation at frame ${frame}`);
    assert.equal(session.remotePresentationActive,true);
    const p=shown.entities.find(entity=>entity.driver==='p')!,q=shown.entities.find(entity=>entity.driver==='q')!;
    const oldHull=hull.clone(),oldRider=rider.clone(),oldOther=other.clone();
    placeSceneFerry(hull,new Vector3(shown.ferry.x,0,shown.ferry.z),true,alpha);
    const motion=hull.clone().sub(oldHull);
    placement(rider,new Vector3(p.x,p.y,p.z),true,true,true,hull,shown.ferry,motion);
    placement(other,new Vector3(q.x,q.y,q.z),true,true,false,hull,shown.ferry,motion);
    assert.ok(Math.abs(rider.x-hull.x+3)<1e-6&&Math.abs(rider.z-hull.z)<1e-6,`local deck frame ${frame}`);
    assert.ok(Math.abs(other.x-hull.x-3)<1e-6&&Math.abs(other.z-hull.z)<1e-6,`remote deck frame ${frame}`);
    if(frame>0)maxStep=Math.max(maxStep,hull.distanceTo(oldHull),rider.distanceTo(oldRider),other.distanceTo(oldOther));
  }
  console.log('DIRECT_NETWORK_FERRY',JSON.stringify({frames:241,maxStep}));
  assert.ok(maxStep<.5,`maximum displayed step ${maxStep} m`);
  session.disconnect();
});

test('direct network placement stays smooth when presented samples arrive at 10 Hz',()=>{
  // This deliberately models the raw-authority fallback, not a claim about
  // how often a real session enters it. Both objects share every sample.
  const directHull=new Vector3(),oldHull=new Vector3(),rider=new Vector3(0,0,3),oldRider=new Vector3(0,0,3);
  let maxDirectStep=0,maxSmoothedStep=0;
  for(let frame=0;frame<=120;frame++){
    const target=new Vector3(0,0,-2*Math.floor(frame/12)),oldDirect=directHull.clone(),oldSmoothed=oldHull.clone();
    placeSceneFerry(directHull,target,true,alpha);placeSceneFerry(oldHull,target,false,alpha);
    placement(rider,new Vector3(0,0,target.z+3),true,true,true,directHull,target,directHull.clone().sub(oldDirect));
    placement(oldRider,new Vector3(0,0,target.z+3),false,true,true,oldHull,target,oldHull.clone().sub(oldSmoothed));
    if(frame>0){maxDirectStep=Math.max(maxDirectStep,directHull.distanceTo(oldDirect));maxSmoothedStep=Math.max(maxSmoothedStep,oldHull.distanceTo(oldSmoothed));}
    assert.ok(Math.abs(rider.z-directHull.z-3)<1e-9,'direct hull and rider share a frame');
    assert.ok(Math.abs(oldRider.z-oldHull.z-3)<1e-9,'smoothed hull and rider share a frame');
  }
  console.log('DIRECT_RAW_SAMPLES',JSON.stringify({maxDirectStep,maxSmoothedStep,rateHz:10,speedMetersPerSecond:20}));
  assert.ok(maxDirectStep<1,`direct hull step ${maxDirectStep} m for sampled authority`);
});
