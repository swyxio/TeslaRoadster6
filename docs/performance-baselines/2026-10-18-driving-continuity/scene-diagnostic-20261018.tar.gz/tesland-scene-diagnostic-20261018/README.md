# Tesland scene placement diagnostic — 2026-10-18

Status: experimental, failing, not suitable for release integration. All work was performed in isolated labs; the release worktree was not edited. The tests are functional evidence only, not performance, browser visual, or device evidence.

## Provenance and patch chain

The source base is Git commit `d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31` in `/Users/swyx/Work/TeslaRoadster6`. `01-presentation-contact.patch` is the prior independent playback prototype. `02-ferry-transition.patch` adds the experimental ferry replay and extracts the scene placement math into `src/scene-placement.lab.ts`. `03-scene-direct.patch` changes that extracted math and its call sites for the direct network placement experiment; it also includes the tests. Tests in `tests/` are convenient exact copies from the final lab.

The three patches were applied in order to a fresh `git archive` of that commit and the resulting scene and test files compared equal to the lab. The reconstructed focused suite produced the same two fallback failures; see `logs/reconstructed-focused-strict.log`. The lab used the existing `/private/tmp/tesland-continuity-throughput/node_modules` symlink. No dependency tree is bundled.

Example reconstruction in a new scratch directory after unpacking this bundle:

```sh
bundle=/private/tmp/tesland-scene-diagnostic-20261018
scratch=$(mktemp -d /private/tmp/tesland-scene-repro-XXXXXX)
git -C /Users/swyx/Work/TeslaRoadster6 archive d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31 | tar -x -C "$scratch"
cd "$scratch"
git apply -p2 "$bundle/patches/01-presentation-contact.patch"
git apply -p4 "$bundle/patches/02-ferry-transition.patch"
git apply -p4 "$bundle/patches/03-scene-direct.patch"
pnpm install --frozen-lockfile
pnpm exec tsx --test tests/ferry-transition.lab.test.ts tests/scene-ferry-cotiming.lab.test.ts tests/scene-direct.lab.test.ts tests/scene-fallback-observe.lab.test.ts tests/session-motion.test.ts tests/tick-prediction.test.ts tests/remote-presentation.test.ts tests/building-sweep-lab.test.ts
pnpm exec tsc --noEmit
```

The test command is expected to fail. Typechecking in the original lab exited 0 with empty output (`logs/client-typecheck.log`). It ran before adding the final fallback test; no source implementation changed afterward.

## Observations and limits

The network mode takes hull and all vehicle positions from the supplied presented world, avoiding extra hull lag, rider offsets, and additional remote yaw extrapolation. Two constructed cases with co-timed safe endpoints then had zero displayed overlap, versus 0.128 m and 0.395 m under the previous placement. The 0.395 m case used a constructed 0.5 m hull lag; its frequency in actual rendering is unknown. A 241-frame Session simulation of a moving ferry with two secured passengers stayed co-timed, with 0.171 m maximum displayed step. A solo fixture retained the prior smoothing calculation.

The mode is unsafe to integrate as written. A synthetic 10 Hz co-timed stream at 20 m/s produced 2 m direct steps versus 0.292 m for prior smoothing, failing a <1 m test. A separate actual `Session` plus shared-physics fixture for a falling car measured a 2.075 m direct step versus 0.229 m prior smoothing before authoritative recovery, again failing the <1 m assertion. `remotePresentationActive` is true while local presentation is unavailable and the returned frame is raw authority, so the flag does not establish a smoothly sampled or jointly co-timed frame. The fallback fixture keeps `poseRevision` constant; its later large post-recovery displacement is not evidence about production teleport behavior.

The complete strict union passed 133 of 139 tests (`logs/retained-union-strict.log`). Its six failures are the existing wall clearance-margin policy conflict, the ferry blocked-ramp state, shore/deck braking contact, the older lab's missing short-teleport identity fence, and the two direct-placement smoothness failures above. The earlier playback and ferry prototypes also have unresolved collision, transition, and responsiveness issues; passing narrow scene cases does not prove safe ferry/passenger/shore playback or the driving-continuity gate. No scene browser run, physical device check, load measurement, deploy, or production validation was done as part of this diagnostic.
