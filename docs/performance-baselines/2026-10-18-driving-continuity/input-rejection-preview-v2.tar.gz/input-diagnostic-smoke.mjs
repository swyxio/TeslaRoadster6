import assert from 'node:assert/strict';
import https from 'node:https';
import WebSocket from '/private/tmp/tesland-hosted-throughput-diagnostic/node_modules/.pnpm/ws@8.21.0/node_modules/ws/index.js';

const host='1234abcd-bay-drive-input-diag.swyxio.workers.dev';
const port=19329;
async function request(path,hostHeader=host){
  return await new Promise((resolve,reject)=>{
    const req=https.request({hostname:'127.0.0.1',port,path,servername:host,rejectUnauthorized:false,headers:{host:hostHeader},timeout:4000},res=>{
      let body='';res.setEncoding('utf8');res.on('data',chunk=>body+=chunk);res.on('end',()=>resolve({status:res.statusCode,body}));
    });req.on('timeout',()=>req.destroy(new Error('HTTP timeout')));req.on('error',reject);req.end();
  });
}
const health=await request('/api/health');
assert.equal(health.status,200);
assert.deepEqual(JSON.parse(health.body),{ok:true,version:47,capacity:64,inputDiagnostic:'input-rejection-preview-v1'});
assert.equal((await request('/api/health','bay-drive.swyxio.workers.dev')).status,403);
assert.equal((await request('/api/radio/example')).status,403);
assert.equal((await request('/api/room/bay')).status,403);
const outcome=await new Promise((resolve,reject)=>{
  const socket=new WebSocket(`wss://127.0.0.1:${port}/api/room/gha-1-1`,{servername:host,rejectUnauthorized:false,headers:{host}});
  const neutral={throttle:0,steer:0,boost:false,hover:false,roll:0,brake:false,jump:0,flip:0,cockpit:false};
  let epoch,identified=false,sent=false,receivedLate=false,receivedRevision=false,applied=false,done=false;
  const timer=setTimeout(()=>finish(new Error('WebSocket smoke timed out')),12000);
  const finish=(error)=>{if(done)return;done=true;clearTimeout(timer);socket.terminate();error?reject(error):resolve({late:receivedLate,revision:receivedRevision,applied});};
  socket.on('error',finish);
  socket.on('close',(code)=>{if(!done)finish(new Error(`WebSocket closed before completion: ${code}`));});
  socket.on('message',data=>{
    try{
      const message=JSON.parse(data.toString());
      if(message.type==='welcome'){epoch=message.roomEpoch;socket.send(JSON.stringify({type:'identity',code:null,requestId:1}));}
      if(message.type==='identityResult'){assert.equal(message.ok,true);identified=true;}
      if(message.type==='state'&&identified&&epoch&&!sent&&message.tick>=7){
        sent=true;
        const {revision,actionSeq}=message.control;
        const send=(seq,targetTick,controlRevision)=>socket.send(JSON.stringify({type:'input',seq,targetTick,roomEpoch:epoch,controlRevision,actionSeq,input:neutral}));
        send(1,message.tick+4,revision);send(2,1,revision);send(3,1,revision+1);
      }
      if(message.type==='inputRejected'&&message.seq===2){
        assert.equal(message.reason,'late');assert.equal(message.diagnostic.source,'scheduler');
        assert.ok(message.diagnostic.receiveTick>=7);assert.equal(message.diagnostic.control.receivedSeq,2);
        assert.equal(message.diagnostic.control.watchdogBeforeArmed,true);
        assert.equal(message.diagnostic.control.watchdogBeforeElapsed,false);
        assert.equal(message.diagnostic.control.watchdogAfterArmed,true);
        assert.equal(message.diagnostic.control.timeoutProcessed,true);receivedLate=true;
      }
      if(message.type==='inputRejected'&&message.seq===3){
        assert.equal(message.reason,'revision');assert.equal(message.diagnostic.source,'scheduler');
        assert.equal(message.diagnostic.incomingRevision,message.diagnostic.control.revision+1);receivedRevision=true;
      }
      if(message.type==='state'&&message.control.appliedSeq>=1)applied=true;
      if(receivedLate&&receivedRevision&&applied)finish();
    }catch(error){finish(error);}
  });
});
console.log(JSON.stringify({health:true,wrongHostBlocked:true,nonRoomApiBlocked:true,publicRoomBlocked:true,...outcome}));
