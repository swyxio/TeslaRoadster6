// This source tree is for isolated Cloudflare preview diagnostics only.
export const INPUT_DIAGNOSTIC_MODE='input-rejection-preview-v1';
export function isDiagnosticPreview(url:URL,mode:unknown):boolean {
  return mode===INPUT_DIAGNOSTIC_MODE && url.protocol==='https:' && !url.port &&
    /^[0-9a-f]{8}-bay-drive-input-diag\.swyxio\.workers\.dev$/.test(url.hostname);
}
