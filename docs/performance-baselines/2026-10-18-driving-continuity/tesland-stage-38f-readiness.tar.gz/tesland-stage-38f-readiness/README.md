# Staged room diagnostic at 38f56a0 — remote execution disabled

Baseline: `38f56a0b082c46fc931735d560aedc3c2900a39a`, protocol 49, reconstructed in a disposable directory. The lab adds diagnostic-only hooks, one Session callback, a local wrapper, and observation tools. It is not the exact candidate binary. No production source or binding was modified, no Worker was deployed, and no 64-driver load was run. `hosted-stage-driver.ts` unconditionally throws while `hostedRunEnabled=false`; preserve this hard-off. This package is an incomplete research fixture, not a release gate or capacity result.

## Evidence

- The exact candidate movement checker, `scripts/load-room.ts`, has SHA-256 `b2da959af63cd2e803dcb1e64a383e56f50f9808659fd28c846ac31edd4f6f91`. It requires coverage from valid short tick-bounded moving sample pairs, and fences malformed data and cross-block gaps.
- Exact-frame ACK observation hooks the Session handler after the same state frame has completed; the timestamp is captured on the Session's monotonic clock at handler entry. It credits only an exact new applied sequence actually sent during measurement. Missing frames, bad epochs, duplicate/reordered/unknown sequences, failed sends and raw overflow are fenced. The ACK block freshness/coverage rules are diagnostic completeness rules, not a release latency threshold. Send-to-observed-snapshot latency is an upper bound, not one-way or precise server processing time.
- `evidence/exact-frame-tests.log`: 27/27 focused ACK, movement, exact-frame and two mock-Socket Session tests passed, including cross-session isolation; `evidence/client-typecheck.log` and `evidence/lab-client-typecheck.log` passed. `evidence/server-hooks-tests.log`: 8/8 passed, including baseline physics parity and explicit unverified contact coverage; `evidence/server-typecheck.log` passed.
- Source-matched static preflight `evidence/preflight-authoritative-static.json` found 64 starting lanes, 1,100 m long with 12 m minimum initial center separation, testing the real candidate `solid()` at 2 m intervals and normal initial vehicle fit against seeded ambient traffic and preceding staged cars. This does not prove support or clearance between samples, movement, or runtime contacts. The lab export of `solid()` does not change its implementation.
- `evidence/local-smoke-2.log` records a successful isolated loopback Wrangler check, exit 0. Two real Sessions had unique staged poses and normal guest economy sessions, rejected a duplicate slot, observed advancing warmup snapshots, moved, and each credited an exact measured ACK. It sealed and exported real multi-substep trace entries and explicitly retained `authoritative-substep-hooks-unverified`; sustained ACK is unmeasured. This was a short functional check, not a timing, 64-driver or provider test. The local Worker was stopped; no live token or persistent state is required for reproduction. The config's repeated `a` token is a dummy local-only value.

## What remains before any remote diagnostic

1. Complete and audit authoritative collision/support/progression hooks (including ferry, landing, dome constraints and post-contact paths) against the exact source, with physics parity, explicit unsupported/overflow and negative controls. The current partial trace cannot establish no contact. Its 200,000-pose cap holds fewer than 390 complete 64-car eight-substep ticks, or about 19.5 simulated seconds, below the required 57 seconds; design and test a bounded scheme suitable for the full sample and quantify observer cost.
2. Port the rejected-input server metadata to this baseline or explicitly treat its absence as incomplete. The driver currently expects a receive-tick/revision/watchdog diagnostic shape that 38f and this local wrapper do not emit. Validate watchdog/edge behavior without changing the production contract.
3. Independently prove the exact instrumented source/build and a separate Cloudflare Preview with distinct Worker and nonproduction Durable Object namespaces and no production bindings. The old identity checker is not wired for this wrapper or secret and has synthetic provider-schema tests only. Pin and verify pre/post identity, health, assets and drift. A hostname or protocol value alone does not establish isolation.
4. Review and locally test four-generator barrier, all unique slots, socket lifecycle, trace export and per-driver reporting. Establish 64 simultaneous advancing normal Sessions, normal traffic and economy behavior, every driver's sustained movement and full measurement coverage; never convert missing contact/queue/ACK data into zero. Guest economy initialization precedes test relocation; saved-driver writes and workload equivalence are not proven. Synthetic corridors are not representative dense-city traffic. Measure observer overhead in matched alternating comparisons using independent hosts and preserve raw outputs.
5. A validated provider-supported per-tick CPU/work distribution remains missing. Cloudflare Worker clocks may freeze between I/O; subtracting `Date.now()` or `performance.now()` around CPU work, client wall intervals or substep counts does not measure deployed tick CPU p95. Cloudflare sampled profiles/aggregate CPU may provide leads but not automatically the gate's per-tick p95.

## Throughput evidence and leads

The older distributed 6238845 normal-room diagnostic advanced approximately 59.9 simulated seconds in 60 seconds, but 25 drivers traveled under 1 m, there were 1,326 observed late rejections and movement coverage failed. Its 5,082.41 MiB is decoded application JSON, not wire bytes or measured Worker CPU. Another earlier local 64-client run shared a heavily loaded host with its generator; it cannot isolate the room bottleneck. Neither establishes 64-player playable capacity or identifies a cause.

The 38f room executes adaptive 1–8 substeps with physics and per-player economy/delivery/achievement work each substep, and sends complete recipient-specific snapshots to each socket every second tick. Common players/entities are already stringified once per broadcast; recipient filtering/array assembly and WebSocket sends still scale with recipients. `solid`/map queries, entity broadphase, traffic logic and rocket-pad scans are plausible workloads; a prior synthetic Node profile also sampled GC, `advance`, `solid`, `nearbyBuildings` and `updateRocketPickup`, but includes bootstrap and is not deployed-Worker attribution.

A prior separate `e8560ab`/`4dfd261` snapshot entity-array cache reduced process CPU in some synthetic same-runner pairs, with an owned-car stress case slower in one three-pair sample. Hosted staged runs still rejected inputs, used sandbox rather than normal economy, and were not comparable causal proof. It is a candidate optimization, not a verified fix. The current instrumentation observes exact applied ACKs, movement, snapshot gaps and partial contacts; it does not break down room CPU or queueing before Worker callback entry. A targeted fix requires profiling under the representative, isolated, fully observed workload and end-to-end comparisons; widening target tolerance cannot safely substitute for that evidence.

## Reproduction of bounded checks

From a disposable checkout of the exact SHA, install the locked dependencies, apply `patches/*.patch`, copy the included new lab/guard/observation files into matching paths, and never apply the patches to a release checkout. The run used Node `v22.22.2` and pnpm `10.33.1`; local dependencies were linked from another checkout and are not archived. Then:

```sh
pnpm exec tsx --test diagnostic-lab/multi-session-measurement.test.ts diagnostic-lab/session-ack.integration.test.ts diagnostic-lab/ack-observer.test.ts tests/load-room.test.ts
pnpm exec tsx --test diagnostic-lab/hosted-stage-core.test.ts
pnpm exec tsc -p diagnostic-lab/tsconfig.client.json --noEmit
pnpm exec tsc -p diagnostic-lab/tsconfig.worker.json --noEmit
pnpm exec tsx diagnostic-lab/hosted-stage-preflight.ts
```

A fresh loopback-only functional smoke, with no other process on port 19331:

```sh
pnpm exec wrangler dev --config diagnostic-lab/wrangler.local-smoke.jsonc --local --local-protocol https --ip 127.0.0.1 --port 19331 --inspector-port 0 --persist-to /tmp/tesland-stage-fresh-local-state --log-level warn
# in another terminal, after local /api/health reports protocol 49:
pnpm exec tsx diagnostic-lab/hosted-stage-local-smoke.ts
# stop Wrangler; delete the disposable local state if desired
```

The packaged source and evidence are intentionally nonproduction and must not be deployed or used to launch hosted load. Results are incomplete and do not authorize merge or deployment.
