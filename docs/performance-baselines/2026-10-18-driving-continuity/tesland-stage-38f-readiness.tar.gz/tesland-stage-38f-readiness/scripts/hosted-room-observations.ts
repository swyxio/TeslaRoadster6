// Preview-only shape; candidate 38f56a0 does not emit this instrumentation.
type InputDiagnostic = {revision:number;actionSeq:number;edgeFloorRevision:number;receivedSeq:number;appliedSeq:number;
  watchdogBeforeArmed:boolean;watchdogBeforeAgeMs:number|null;watchdogBeforeElapsed:boolean;
  watchdogAfterArmed:boolean;timeoutProcessed:boolean};
export type SentInput = {at:number;utc:string;targetTick:number;lastSnapshotTick:number|null;lastSnapshotAgeMs:number|null};
export type RejectionDiagnostic = {receiveTick:number;source:'epoch'|'attachPending'|'scheduler';
  incomingRevision:number;incomingActionSeq:number;control:InputDiagnostic};
export function snapshotAge(now:number,receivedAt:number|null):number|null {
  return receivedAt!==null&&Number.isFinite(now)&&Number.isFinite(receivedAt)&&now>=receivedAt?now-receivedAt:null;
}
export function isRejectionDiagnostic(value:unknown):value is RejectionDiagnostic {
  if(!value||typeof value!=='object')return false;
  const d=value as Record<string,unknown>, c=d.control;
  if(!c||typeof c!=='object')return false;
  const control=c as Record<string,unknown>;
  const integer=(v:unknown)=>Number.isSafeInteger(v)&&Number(v)>=0;
  return integer(d.receiveTick)&&['epoch','attachPending','scheduler'].includes(String(d.source))&&
    integer(d.incomingRevision)&&integer(d.incomingActionSeq)&&
    ['revision','actionSeq','edgeFloorRevision','receivedSeq','appliedSeq'].every(k=>integer(control[k]))&&
    ['watchdogBeforeArmed','watchdogBeforeElapsed','watchdogAfterArmed','timeoutProcessed'].every(k=>typeof control[k]==='boolean')&&
    (control.watchdogBeforeAgeMs===null||(typeof control.watchdogBeforeAgeMs==='number'&&Number.isFinite(control.watchdogBeforeAgeMs)))&&
    control.watchdogBeforeArmed===(control.watchdogBeforeAgeMs!==null);
}
