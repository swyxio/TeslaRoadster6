// Four Actions runners each use 16 real Sessions in one disposable preview room.
// The test is bounded and intentionally cannot target production or arbitrary URLs.
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { cpus, loadavg, totalmem } from 'node:os';
import { join } from 'node:path';
import { monitorEventLoopDelay } from 'node:perf_hooks';
import { gzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { Session } from '../src/session';
import { WarmupGate } from './hosted-stage-core';
import { NEUTRAL, PROTOCOL_VERSION, type World } from '../shared/game';
import { FUTURE_TICKS } from '../shared/tick-input';
import { allPlayersPresent } from '../scripts/load-room';
import { createDriverMeasurement,sendObserved,type DriverMeasurement } from './driver-measurement';
import { snapshotAge, isRejectionDiagnostic, type SentInput, type RejectionDiagnostic } from '../scripts/hosted-room-observations';

const preview = process.env.TARGET_PREVIEW_URL ?? '';
const candidateSha = process.env.TARGET_SOURCE_SHA ?? '';
const group = Number(process.env.CAPACITY_GROUP);
const runId = process.env.GITHUB_RUN_ID ?? '';
const attempt = process.env.GITHUB_RUN_ATTEMPT ?? '';
const runnerTemp = process.env.RUNNER_TEMP ?? '';
const stageToken=process.env.LAB_STAGE_TOKEN??'';
// Deliberately hard disabled until the provider guard, authoritative contact
// hooks, exact source and observer overhead have been independently reviewed.
const hostedRunEnabled:boolean=false;
if(!hostedRunEnabled)throw new Error('Hosted staged diagnostic is not ready');
if (!/^[0-9a-f]{64}$/.test(stageToken) || !/^https:\/\/[0-9a-f]{8}-bay-drive-input-diag\.swyxio\.workers\.dev$/.test(preview) ||
    !/^[0-9a-f]{40}$/.test(candidateSha) || execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()!==candidateSha ||
    !!execFileSync('git',['status','--porcelain','--untracked-files=normal'],{encoding:'utf8'}).trim() ||
    !Number.isInteger(group) || group < 1 || group > 4 ||
    !/^\d{1,20}$/.test(runId) || !/^\d{1,4}$/.test(attempt) || !runnerTemp ||
    process.env.GITHUB_REPOSITORY !== 'swyxio/TeslaRoadster6' ||
    process.env.GITHUB_REF !== 'refs/heads/codex/preview-input-instrumentation') {
  throw new Error('Only the four Actions jobs on the diagnostic branch may test the pinned PR preview');
}
const room = `gha-${runId}-${attempt}`;
if (room.length > 32) throw new Error('Diagnostic room name is too long');
const socketUrl = `wss://${new URL(preview).host}/api/room/${room}`;
const stageHeaders={Authorization:`Bearer ${stageToken}`};
let stageStartTick:number|null=null;let warmupGate:WarmupGate|null=null;
const stageStatusUrl=`${preview}/api/lab/status/${room}`,stageBeginUrl=`${preview}/api/lab/begin/${room}`;
const sourceFiles = [
  'diagnostic-lab/hosted-stage-driver.ts','diagnostic-lab/hosted-stage-worker.ts','diagnostic-lab/hosted-stage-core.ts','diagnostic-lab/preflight-result.json',
  'diagnostic-lab/driver-measurement.ts','diagnostic-lab/ack-observer.ts',
  'scripts/hosted-room-observations.ts', 'scripts/load-room.ts',
  'src/session.ts', 'src/motion-clock.ts', 'src/tick-prediction.ts',
  'worker/index.ts', 'worker/snapshot.ts', 'shared/tick-input.ts', 'wrangler.jsonc',
];
const sourceSha256 = Object.fromEntries(sourceFiles.map(path =>
  [path, createHash('sha256').update(readFileSync(path)).digest('hex')]));
const outputDir = join(runnerTemp, 'capacity-preview-diagnostic');
const sessions:Session[] = [];
const loop = monitorEventLoopDelay({resolution:20});
const loadSamples:{utc:string;load:number[];cpuMicros:NodeJS.CpuUsage}[] = [];
const iso = () => new Date().toISOString();
const delay = (ms:number) => new Promise(resolve => setTimeout(resolve,ms));
const deadline = performance.now() + 210_000;
let measurementStart = Infinity, measurementEnd = Infinity;
let startedUtc:string|null = null, endedUtc:string|null = null;
let barrierTick:number|null = null, targetTick:number|null = null;
let markedReady = false, saw64 = false, stopping = false;
let failure:string|null = null, highestTick = -1, lastProgressAt = performance.now();
let timer:ReturnType<typeof setInterval>|undefined,keepalive:ReturnType<typeof setInterval>|undefined;
let health:unknown = null;
let healthHeaders:Record<string,string|null> = {};
let traceExportError:string|null=null,traceSummary:unknown=null;
let expectedPlayers:string[]=[];

type Rejection = {client:number;reason:string;seq:number;targetTick:number;sentAt:number|null;sentUtc:string|null;
  receivedAt:number;receivedUtc:string;lastTickAtSend:number|null;lastTickAtReceive:number|null;
  lastSnapshotAgeAtSendMs:number|null;lastSnapshotAgeAtReceiveMs:number|null;diagnostic:RejectionDiagnostic|null};
type Slot = {socket?:WebSocket;lastTick:number|null;lastSnapshotAt:number|null;lastMeasuredAt:number;snapshots:number;gaps:number[];bytes:number;
  firstTime:number|null;lastTime:number|null;firstTick:number|null;lastMeasuredTick:number|null;lastPlayers:number;
  sent:Map<number,SentInput>;sentCounts:Record<string,number>;sentDropped:number;rejections:Rejection[];
  closed:{code:number;reason:string;wasClean:boolean;utc:string;phase:string}[];
  measurement:DriverMeasurement|null;
  firstSnapshot:{elapsedMs:number;tick:number;worldTime:number}|null;lastSnapshot:{elapsedMs:number;tick:number;worldTime:number}|null;
  queues:{samples:number;levels:number;jump:number;flip:number;historySamples:number;history:number;historyOverflow:boolean;bufferedBytes:number};damage:boolean;impulse:boolean;initialHealth:number|null;
  rawSamples:unknown[];rawInputs:unknown[];rawOverflow:boolean};
const slots:Slot[] = Array.from({length:16},()=>({lastTick:null,lastSnapshotAt:null,lastMeasuredAt:0,snapshots:0,gaps:[],bytes:0,
  firstTime:null,lastTime:null,firstTick:null,lastMeasuredTick:null,lastPlayers:0,sent:new Map(),
  sentCounts:{warmup:0,measured:0,drain:0,unknown:0},sentDropped:0,rejections:[],closed:[],measurement:null,firstSnapshot:null,lastSnapshot:null,queues:{samples:0,levels:0,jump:0,flip:0,historySamples:0,history:0,historyOverflow:false,bufferedBytes:0},
  damage:false,impulse:false,initialHealth:null,rawSamples:[],rawInputs:[],rawOverflow:false}));
const fail = (reason:string) => { failure ??= reason; };
const interrupt = () => fail('Interrupted by the runner');
process.once('SIGINT', interrupt);
process.once('SIGTERM', interrupt);

// One parser remains in Session; this observer only parses small rejection and
// outgoing input frames. State metadata is read after Session handles each event.
const NativeWebSocket = globalThis.WebSocket;
let nextSlot = 0;
class MonitoringWebSocket extends NativeWebSocket {
  private readonly index:number;
  constructor(url:string | URL, protocols?:string|string[]) {
    if (String(url) !== socketUrl) throw new Error('Unexpected WebSocket target');
    const index=nextSlot++;
    if(index>=16)throw new Error('Unexpected extra socket');
    // Node 22's Undici WebSocketInit adds headers for this test transport only.
    super(url,{protocols,headers:{...stageHeaders,'x-lab-slot':String((group-1)*16+index)}} as any);
    this.index=index;
    const slot = slots[this.index];
    slot.socket = this;
    this.addEventListener('message',event=>{
      const receivedAt = performance.now(), raw = String(event.data);
      if (raw.startsWith('{"type":"inputRejected"')) {
        const message = JSON.parse(raw) as {seq:number;targetTick:number;reason:string;diagnostic?:unknown};
        const sent = slot.sent.get(message.seq);
        const diagnostic=isRejectionDiagnostic(message.diagnostic)?message.diagnostic:null;
        if(!diagnostic)fail('Rejected input did not carry valid preview-only diagnostic metadata');
        slot.rejections.push({client:(group-1)*16+this.index+1,reason:message.reason,seq:message.seq,targetTick:message.targetTick,
          sentAt:sent?.at??null,sentUtc:sent?.utc??null,receivedAt,receivedUtc:iso(),
          lastTickAtSend:sent?.lastSnapshotTick??null,lastTickAtReceive:slot.lastTick,
          lastSnapshotAgeAtSendMs:sent?.lastSnapshotAgeMs??null,lastSnapshotAgeAtReceiveMs:snapshotAge(receivedAt,slot.lastSnapshotAt),diagnostic});
        if(sent?.at===undefined)fail('Rejected input has no retained send record');
        if(sent?.at===undefined||phase(sent.at)==='measured')slot.measurement?.invalidate('input-rejected');
      }
    });
    this.addEventListener('close',event=>{
      slot.closed.push({code:event.code,reason:event.reason,wasClean:event.wasClean,utc:iso(),phase:phase(performance.now())});
      if (!stopping) {slot.measurement?.invalidate('socket-closed');fail(`Client ${this.index+1} closed: ${event.code} ${event.reason}`);}
    });
  }
  override send(data:string | ArrayBufferLike | Blob | ArrayBufferView):void {
    if (typeof data !== 'string' || !data.startsWith('{"type":"input"')) {super.send(data);return;}
    const value=JSON.parse(data) as {seq:number;targetTick:number;controlRevision:number;actionSeq:number;input:unknown};
    const slot=slots[this.index],at=performance.now();
    if(phase(at)==='measured'&&!slot.measurement)fail('Measured input has no bound observer');
    // sendObserved records only after the synchronous send succeeds.
    sendObserved(slot.measurement,value.seq,at,()=>super.send(data));
    slot.sentCounts[phase(at)]++;
    slot.sent.set(value.seq,{at,utc:iso(),targetTick:value.targetTick,lastSnapshotTick:slot.lastTick,
      lastSnapshotAgeMs:snapshotAge(at,slot.lastSnapshotAt)});
    if(slot.rawInputs.length>=4096){slot.rawOverflow=true;slot.measurement?.invalidate('raw-overflow');}
    else slot.rawInputs.push({at,utc:iso(),seq:value.seq,targetTick:value.targetTick,controlRevision:value.controlRevision,actionSeq:value.actionSeq,input:value.input,lastSnapshotTick:slot.lastTick,lastSnapshotAgeMs:snapshotAge(at,slot.lastSnapshotAt)});
    if(slot.sent.size>4096){slot.sent.delete(slot.sent.keys().next().value!);slot.sentDropped++;slot.measurement?.invalidate('raw-overflow');}
  }
}

// Invoked synchronously by the Session after this exact frame was processed.
function acceptedFrame(index:number,value:unknown,receivedAt:number,raw:string):void {
  const slot=slots[index],session=sessions[index];
  try {
    const frame=value as {tick:number;poseRevision:number;roomEpoch:string;world:World;control:any};
    const {world,tick,control}=frame;
    if(!world||!Array.isArray(world.players)||!Array.isArray(world.entities))throw new Error('Invalid world');
    if(world.players.length===64)saw64=true;
    if(markedReady&&world.players.length!==64)throw new Error('Room no longer has 64 players');
    if(warmupGate)warmupGate.observe(index,tick,receivedAt);
    if(index===0&&targetTick!==null&&warmupGate?.ready(receivedAt)&&measurementStart===Infinity&&tick>=targetTick){
      if(tick!==targetTick)throw new Error('Missed common start tick');
      const ids=world.players.map(player=>player.id);
      if(ids.length!==64||!allPlayersPresent(world.players,ids))throw new Error('Invalid start identities');
      const epoch=(session as any).roomEpoch;
      if(!epoch||sessions.some(s=>!s.id||(s as any).roomEpoch!==epoch||!ids.includes(s.id))||new Set(sessions.map(s=>s.id)).size!==16)
        throw new Error('Session identities or epochs do not match');
      expectedPlayers=ids;measurementStart=performance.now();measurementEnd=measurementStart+60_000;
      for(let i=0;i<16;i++)slots[i].measurement=createDriverMeasurement(epoch,sessions[i].id,measurementStart);
      startedUtc=iso();lastProgressAt=measurementStart;loop.enable();
    }
    if(receivedAt>=measurementStart&&receivedAt<measurementEnd){
      const m=slot.measurement;
      if(!m||session.id!==m.playerId||(session as any).roomEpoch!==m.epoch){m?.invalidate('identity-changed');throw new Error('Session identity changed');}
      if(!allPlayersPresent(world.players,expectedPlayers))throw new Error('Measured state lost a staged identity');
      m.accepted(frame,receivedAt);
      if(slot.lastMeasuredAt)slot.gaps.push(receivedAt-slot.lastMeasuredAt);
      slot.lastMeasuredAt=receivedAt;slot.snapshots++;slot.bytes+=Buffer.byteLength(raw);
      if(!Number.isFinite(world.time))throw new Error('Invalid world time');
      slot.firstTime??=world.time;slot.lastTime=world.time;slot.firstTick??=tick;slot.lastMeasuredTick=tick;slot.lastPlayers=world.players.length;
      const sample={elapsedMs:receivedAt-measurementStart,tick,worldTime:world.time};slot.firstSnapshot??=sample;slot.lastSnapshot=sample;
      const player=world.players.find(item=>item.id===session.id);
      const car=world.entities.find(item=>item.id===player?.entityId&&item.driver===session.id)??null;
      if(slot.rawSamples.length>=4096){slot.rawOverflow=true;m.invalidate('raw-overflow');}
      else slot.rawSamples.push({...sample,poseRevision:frame.poseRevision,
        car:car?{x:car.x,y:car.y,z:car.z,speed:car.speed,health:car.health,support:car.supportId,pushX:car.pushX,pushZ:car.pushZ}:null,
        control:control?{receivedSeq:control.receivedSeq,appliedSeq:control.appliedSeq,queued:control.queued?.length,jump:control.jump?.pending?.length,flip:control.flip?.pending?.length}:null});
      if(control&&Array.isArray(control.queued)&&Array.isArray(control.jump?.pending)&&Array.isArray(control.flip?.pending)){
        slot.queues.samples++;slot.queues.levels=Math.max(slot.queues.levels,control.queued.length);
        slot.queues.jump=Math.max(slot.queues.jump,control.jump.pending.length);slot.queues.flip=Math.max(slot.queues.flip,control.flip.pending.length);
        const prediction=(session as any).prediction;
        if(Array.isArray(prediction?.pending)){slot.queues.historySamples++;slot.queues.history=Math.max(slot.queues.history,prediction.pending.length);}
      }
      if(car){slot.initialHealth??=car.health;slot.damage||=car.health<slot.initialHealth-.001;slot.impulse||=Math.hypot(car.pushX,car.pushZ)>.1;}
    }
  } catch(error){fail(`Exact state observer: ${String(error)}`);}
}

const waitUntil = async (ready:()=>boolean, description:string) => {
  while (!ready()) {
    if (failure) throw new Error(failure);
    if (performance.now() >= deadline) throw new Error(`Deadline while ${description}`);
    await delay(25);
  }
  if (failure) throw new Error(failure);
};
const phase = (at:number|null) => at === null ? 'unknown' : at < measurementStart ? 'warmup' : at < measurementEnd ? 'measured' : 'drain';
const distribution = (values:number[]) => {
  const sorted = [...values].sort((a,b)=>a-b);
  const at = (q:number) => sorted.length ? +sorted[Math.min(sorted.length-1,Math.floor(sorted.length*q))].toFixed(2) : null;
  return {count:sorted.length,p50:at(.5),p95:at(.95),max:at(1)};
};

try {
  const response = await fetch(`${preview}/api/health`,{redirect:'error',signal:AbortSignal.timeout(8000)});
  if (!response.ok) throw new Error(`Preview health HTTP ${response.status}`);
  health = await response.json();
  if (!(health as {ok?:boolean}).ok || (health as {version?:number}).version !== PROTOCOL_VERSION ||
      (health as {capacity?:number}).capacity !== 64 ||
      (health as {inputDiagnostic?:string}).inputDiagnostic !== 'input-rejection-preview-v1') throw new Error(`Unexpected preview health: ${JSON.stringify(health)}`);
  healthHeaders = Object.fromEntries(['date','cf-ray','etag'].map(name=>[name,response.headers.get(name)]));
  Object.defineProperty(globalThis,'WebSocket',{value:MonitoringWebSocket,configurable:true,writable:true});
  Object.defineProperty(globalThis,'location',{value:new URL(preview),configurable:true});
  Object.defineProperty(globalThis,'window',{value:globalThis,configurable:true});
  let heartbeatId=10000;
  keepalive=setInterval(()=>{if(!markedReady)for(const slot of slots)if(slot.socket?.readyState===WebSocket.OPEN)
    slot.socket.send(JSON.stringify({type:'identity',code:null,requestId:heartbeatId++}));},5000);
  for (let i=0;i<16;i++) {
    const session = new Session(); sessions.push(session);
    session.onDiagnosticAcceptedState=(frame,at,raw)=>acceptedFrame(i,frame,at,raw);
    const clock = (session as any).clock;
    const observe = clock.observe.bind(clock);
    clock.observe = (tick:number,at:number):boolean => {
      const valid = observe(tick,at);
      if (valid) {
        slots[i].lastTick = tick;slots[i].lastSnapshotAt=at;
        if (tick > highestTick) { highestTick = tick; lastProgressAt = performance.now(); }
      }
      return valid;
    };
    session.join(room,`probe-${group}-${i+1}`,'roadster');
  }
  let lastFrame = performance.now(), lastLoadSample = 0;
  timer = setInterval(()=>{
    try {
      const now = performance.now(), dt = Math.min((now-lastFrame)/1000,.1); lastFrame = now;
      if (now-lastLoadSample >= 5000) {loadSamples.push({utc:iso(),load:loadavg(),cpuMicros:process.cpuUsage()});lastLoadSample=now;}
      if (highestTick >= 0 && now-lastProgressAt > 10_000) fail('No observed room progress for ten seconds');
      if (now >= deadline) fail('Diagnostic deadline exceeded');
      for(const slot of slots)slot.queues.bufferedBytes=Math.max(slot.queues.bufferedBytes,slot.socket?.bufferedAmount??0);
      if (slots.some(slot=>slot.queues.bufferedBytes>1_000_000)) fail('Client send buffer exceeded 1 MB');
      if (failure) return;
      for (let i=0;i<sessions.length;i++) {
        const session = sessions[i],player=session.world.players.find(item=>item.id===session.id);
        const car=session.world.entities.find(item=>item.id===player?.entityId&&item.driver===session.id);
        const age=slots[i].lastSnapshotAt===null?Infinity:now-slots[i].lastSnapshotAt!;
        const input=!markedReady||!car||age>500?NEUTRAL:car.speed>13?{...NEUTRAL,brake:true}:{...NEUTRAL,throttle:Math.max(0,Math.min(.1,(12-car.speed)*.06))};
        session.tick(dt,input);
        slots[i].queues.historyOverflow ||= !!(session as any).prediction?.overflow;
        if (session.status === 'online') {
          // Match the existing Session diagnostic's frame-cadenced clock calls;
          // there is no renderer and no prediction render in this sample.
          const clock = (session as any).clock, at = performance.now();
          clock.remote(at);clock.target(at);clock.estimate(at);clock.alpha(at);
        }
      }
    } catch (error) { fail(`Frame loop: ${String(error)}`); }
  },16);
  await waitUntil(()=>sessions.every(session=>session.status==='online'&&session.identityResult?.ok===true), 'identifying 16 sessions');
  let staged=false;
  while(!staged){
    if(failure||performance.now()>=deadline)throw new Error(failure??'Staging timed out');
    const response=await fetch(stageStatusUrl,{headers:stageHeaders,redirect:'error',signal:AbortSignal.timeout(8000)});
    if(!response.ok)throw new Error(`Staging status HTTP ${response.status}`);
    const status=await response.json() as {ready:boolean;started:boolean;startedAtTick:number|null;tick:number;expectedDrivers:number};
    if(status.expectedDrivers!==64)throw new Error('Staging did not require 64 drivers');
    if(status.ready&&group===1){
      const begin=await fetch(stageBeginUrl,{method:'POST',headers:stageHeaders,redirect:'error',signal:AbortSignal.timeout(8000)});
      if(!begin.ok)throw new Error(`Staging begin HTTP ${begin.status}`);
      const result=await begin.json() as {ok:boolean;tick:number};if(!result.ok)throw new Error('Staging begin failed');
      stageStartTick=result.tick;staged=true;
    }else if(status.started){
      if(!Number.isSafeInteger(status.startedAtTick)||status.startedAtTick===null)throw new Error('Missing shared start tick');
      stageStartTick=status.startedAtTick;staged=true;
    }
    else await delay(250);
  }
  // Paused snapshots repeat a tick. Every Session must see progressing warmup.
  // All groups use the same authoritative begin tick.
  if(stageStartTick===null)throw new Error('Missing authoritative begin tick');
  barrierTick=stageStartTick;targetTick=stageStartTick+80;warmupGate=new WarmupGate(16,stageStartTick);
  markedReady=true;
  await waitUntil(()=>saw64, 'waiting for all 64 staged players');
  await waitUntil(()=>measurementStart!==Infinity, 'waiting for progressing warmup and shared start tick');
  await waitUntil(()=>performance.now()>=measurementEnd, 'measuring');
  measurementEnd = performance.now(); endedUtc = iso(); loop.disable();
  if (timer) {clearInterval(timer);timer=undefined;}
  // A bounded drain captures some delayed replies, not necessarily every reply.
  await delay(1000);
  if (failure) throw new Error(failure);
} catch (error) {
  fail(error instanceof Error ? error.message : String(error));
  if (measurementStart !== Infinity && !endedUtc) {measurementEnd=performance.now();endedUtc=iso();}
} finally {
  stopping = true;
  if (timer) clearInterval(timer);
  if (keepalive) clearInterval(keepalive);
  loop.disable();
  if(markedReady){
    try{
      const done=await fetch(`${preview}/api/lab/done/${room}`,{method:'POST',headers:{...stageHeaders,'x-lab-group':String(group)},redirect:'error',signal:AbortSignal.timeout(8000)});
      if(!done.ok)throw new Error(`Staging done HTTP ${done.status}`);
      if(group===1){
        const until=performance.now()+120_000;let finished=false;
        while(performance.now()<until){
          const status=await fetch(stageStatusUrl,{headers:stageHeaders,redirect:'error',signal:AbortSignal.timeout(8000)});
          if(!status.ok)throw new Error(`Staging status HTTP ${status.status}`);
          if((await status.json() as {doneGroups:number}).doneGroups===4){finished=true;break;}
          await delay(250);
        }
        if(!finished)throw new Error('Not all runner groups sealed the trace');
        const raw:{poses:unknown[];events:unknown[]}={poses:[],events:[]};let total=1;
        for(let offset=0;offset<total;offset+=1000){
          const response=await fetch(`${preview}/api/lab/trace/${room}?offset=${offset}&limit=1000`,{headers:stageHeaders,redirect:'error',signal:AbortSignal.timeout(8000)});
          if(!response.ok)throw new Error(`Trace HTTP ${response.status}`);
          const page=await response.json() as {summary:{poses:number;events:number};poses:unknown[];events:unknown[]};
          traceSummary=page.summary;total=Math.max(page.summary.poses,page.summary.events);
          raw.poses.push(...page.poses);raw.events.push(...page.events);
        }
        mkdirSync(outputDir,{recursive:true});writeFileSync(join(outputDir,'stage-substep-trace.json.gz'),gzipSync(JSON.stringify({summary:traceSummary,...raw})));
      }
    }catch(error){traceExportError=error instanceof Error?error.message:String(error);}
  }
  const onlineAtEnd = sessions.filter(session=>session.status==='online').length;
  const clientsWithAppliedInput = sessions.filter(session=>((session as any).prediction.control?.appliedSeq??0)>0).length;
  const roomEpochs = [...new Set(sessions.map(session=>(session as any).roomEpoch).filter(Boolean))];
  for (const session of sessions) session.disconnect();
  process.removeListener('SIGINT',interrupt);process.removeListener('SIGTERM',interrupt);
  const rejections = slots.flatMap(slot=>slot.rejections).map(item=>({...item,sendPhase:phase(item.sentAt),receivePhase:phase(item.receivedAt)}));
  const sentCounts:Record<string,number> = {warmup:0,measured:0,drain:0,unknown:0};
  for (const slot of slots) for (const key of Object.keys(sentCounts)) sentCounts[key]+=slot.sentCounts[key];
  const countRejections = (key:'sendPhase'|'receivePhase') => {
    const counts:Record<string,Record<string,number>> = {warmup:{},measured:{},drain:{},unknown:{}};
    for (const item of rejections) counts[item[key]][item.reason]=(counts[item[key]][item.reason]??0)+1;
    return counts;
  };
  const elapsedSeconds = measurementStart===Infinity ? null : +(Math.max(0,measurementEnd-measurementStart)/1000).toFixed(3);
  const advances = slots.map(slot=>slot.firstTime===null||slot.lastTime===null?0:+(slot.lastTime-slot.firstTime).toFixed(2)).sort((a,b)=>a-b);
  const measuredRejections = rejections.filter(item=>item.sendPhase==='measured');
  const measurements=slots.map(slot=>slot.measurement?.summary()??null);
  const incomplete:string[]=[];
  if(failure)incomplete.push('runner-failure');
  if(traceExportError)incomplete.push('staged-trace-export-failed');
  if(elapsedSeconds===null||elapsedSeconds<60)incomplete.push('less-than-60-wall-seconds');
  if(advances[0]<57)incomplete.push('less-than-57-simulated-seconds');
  if(slots.some(slot=>slot.closed.length))incomplete.push('client-disconnected');
  if(slots.some(slot=>slot.lastPlayers!==64))incomplete.push('not-all-clients-observed');
  if(measurements.some(item=>!item||item.movement.blocks.some(block=>!block.complete)))incomplete.push('not-all-drivers-sustained-moving');
  if(measurements.some(item=>!item||item.ack.blocks.some(block=>!block.complete)))incomplete.push('sustained-acknowledgement-unmeasured');
  // The partial authoritative hooks are not a complete contact audit. Never
  // claim an unobstructed measurement without authoritative substep hooks.
  incomplete.push('authoritative-substep-contact-coverage-unavailable');
  if(measuredRejections.length)incomplete.push('input-rejected');
  if(slots.some(slot=>!slot.queues.samples||!slot.queues.historySamples))incomplete.push('missing-queue-or-history-observations');
  if(slots.some(slot=>slot.queues.levels>FUTURE_TICKS||slot.queues.jump>FUTURE_TICKS||slot.queues.flip>FUTURE_TICKS))incomplete.push('sampled-control-queue-bound-exceeded');
  if(slots.some(slot=>slot.queues.historyOverflow))incomplete.push('prediction-history-overflow-observed');
  if(slots.some(slot=>slot.sentDropped)||measurements.some(item=>!item||item.ack.reasons.length))incomplete.push('ack-observation-incomplete');
  if(slots.some(slot=>slot.rawOverflow))incomplete.push('raw-client-trace-overflow');
  const result = {
    preview,room,health,healthHeaders,group,runId,attempt,candidateSha,diagnosticSha:process.env.GITHUB_SHA??null,sourceSha256,
    failure,traceExportError,traceSummary,startedUtc,endedUtc,elapsedSeconds,barrierTick,targetTick,highestTick,markedReady,saw64,
    clients:16,onlineAtEnd,roomEpochs,clientsSeeingAll:slots.filter(slot=>slot.lastPlayers===64).length,
    clientsWithAppliedInput,
    snapshots:slots.reduce((sum,slot)=>sum+slot.snapshots,0),minSnapshots:Math.min(...slots.map(slot=>slot.snapshots)),
    snapshotGapMs:distribution(slots.flatMap(slot=>slot.gaps)),simulatedSeconds:{min:advances[0],median:advances[8]},
    decodedJsonMiB:+(slots.reduce((sum,slot)=>sum+slot.bytes,0)/1048576).toFixed(2),
    clientEventLoopP95Ms:measurementStart===Infinity?null:+(loop.percentile(95)/1e6).toFixed(2),
    inputsSent:sentCounts,rejectionsBySendWindow:countRejections('sendPhase'),rejectionsByReceiveWindow:countRejections('receivePhase'),
    measuredRejectionReplyMs:distribution(measuredRejections.flatMap(item=>item.sentAt===null?[]:[item.receivedAt-item.sentAt])),
    appliedObservationUpperBoundMs:distribution(measurements.flatMap(item=>item?.ack.samples.map(sample=>sample.upperBoundMs)??[])),
    slots:slots.map((slot,i)=>({snapshots:slot.snapshots,firstTick:slot.firstTick,lastTick:slot.lastMeasuredTick,
      firstTime:slot.firstTime,lastTime:slot.lastTime,firstSnapshot:slot.firstSnapshot,lastSnapshot:slot.lastSnapshot,
      lastPlayers:slot.lastPlayers,closed:slot.closed,movement:measurements[i]?.movement??null,acknowledgements:measurements[i]?.ack??null,
      queues:slot.queues,damageObserved:slot.damage,impulseObserved:slot.impulse,
      sentCounts:slot.sentCounts,sentDropped:slot.sentDropped})),
    diagnosticCoverageComplete:incomplete.length===0,incomplete,
    rejections,loadSamples,host:{platform:process.platform,node:process.version,cpus:cpus().length,totalMemoryBytes:totalmem()},
    note:'Four independent 16-Session runners use staged synthetic corridors. Source and provider isolation must be independently verified; partial substep hooks do not establish unobstructed movement. All four artifacts must be combined. ACKs measure only exact sequences observed in snapshots; received sequences can include rejected inputs. Sampled queues/history and damage/impulse cannot prove inter-snapshot bounds or absence of contact. Decoded bytes are not wire bytes. A one-second drain can miss replies. No server tick-work, browser-rendering, physical-device or capacity claim.',
  };
  mkdirSync(outputDir,{recursive:true});
  writeFileSync(join(outputDir,`group-${group}-raw.json.gz`),gzipSync(JSON.stringify(slots.map(slot=>({samples:slot.rawSamples,inputs:slot.rawInputs,overflow:slot.rawOverflow})))));
  writeFileSync(join(outputDir,`group-${group}.json.gz`),gzipSync(JSON.stringify(result)));
  console.log(JSON.stringify({...result,rejections:`${rejections.length} details in gzip`},null,2));
  const runFailed=!!failure||incomplete.length>0;
  if (runFailed) process.exitCode=1;
  // A wedged close handshake must not keep the job alive after evidence exists.
  setTimeout(()=>process.exit(runFailed?1:0),2000).unref();
}
