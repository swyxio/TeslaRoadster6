import {test} from 'node:test';
import assert from 'node:assert/strict';
import {SlotAdmissions,WarmupGate,ContactTrace,unsupportedPose} from './hosted-stage-core';
import {MotionClock} from '../src/motion-clock';

test('slots are unique, finite and cannot be reused after sealing',()=>{
  const slots=new SlotAdmissions(2);
  assert.equal(slots.reserve(0),true);assert.equal(slots.reserve(0),false);
  assert.equal(slots.reserve(2),false);assert.equal(slots.reserve(-1),false);
  assert.equal(slots.stage(1),false);assert.equal(slots.stage(0),true);
  assert.equal(slots.seal(),false);assert.equal(slots.reserve(1),true);
  assert.equal(slots.stage(1),true);assert.equal(slots.stage(1),false);
  assert.equal(slots.complete,true);assert.equal(slots.seal(),true);
  assert.equal(slots.reserve(0),false);assert.equal(slots.seal(),false);
});

test('paused equal-tick snapshots never satisfy warmup; actual Session clock needs progressing ticks',()=>{
  const gate=new WarmupGate(2,10),clock=new MotionClock();
  assert.equal(clock.observe(10,0),true);gate.observe(0,10,0);gate.observe(1,10,0);
  assert.equal(clock.observe(10,1000),true);gate.observe(0,10,1000);gate.observe(1,10,1000);
  assert.equal(clock.stale(1000),true);assert.equal(gate.ready(1000),false);
  clock.observe(11,1050);gate.observe(0,11,1050);gate.observe(1,11,1050);
  gate.observe(0,13,1150);assert.equal(gate.ready(1150),false);
  gate.observe(1,13,1150);assert.equal(clock.stale(1150),false);assert.equal(gate.ready(1150),true);
  assert.equal(gate.ready(1700),false);
});

test('contact, missing observations, unsupported coverage and overflow fail closed',()=>{
  const pose=(slot:number,substeps=1)=>({tick:1,substep:0,substeps,slot,x:slot,y:0,z:0,speed:1,support:'ground'});
  const unverified=new ContactTrace(2,2,4096,false,1);unverified.substep(1,0,1,[pose(0),pose(1)]);unverified.seal(1);
  assert.equal(unverified.summary().complete,false);
  assert.ok(unverified.summary().reasons.includes('authoritative-substep-hooks-unverified'));
  const hit=new ContactTrace(2,2,1,true,1);hit.substep(1,0,1,[pose(0),pose(1)]);
  hit.event({tick:1,substep:0,slot:0,kind:'entity'});
  assert.ok(hit.summary().reasons.includes('obstruction-observed'));
  hit.event({tick:1,substep:0,slot:1,kind:'solid'});
  assert.ok(hit.summary().reasons.includes('trace-overflow'));
  const partial=new ContactTrace(2,2,1,true,1);partial.substep(1,0,1,[pose(0)]);
  assert.ok(partial.summary().reasons.includes('invalid-or-missing-substep-data'));
  const overflow=new ContactTrace(2,1,1,true,1);overflow.substep(1,0,1,[pose(0),pose(1)]);
  assert.ok(overflow.summary().reasons.includes('trace-overflow'));
  const missing=new ContactTrace(2,10,1,true,1);missing.substep(1,0,2,[pose(0,2),pose(1,2)]);
  const next=(slot:number)=>({...pose(slot),tick:2});missing.substep(2,0,1,[next(0),next(1)]);missing.seal(2);
  assert.ok(missing.summary().reasons.includes('invalid-or-missing-substep-data'));
  const uninterrupted=new ContactTrace(2,4,1,true,1);
  uninterrupted.substep(1,0,2,[pose(0,2),pose(1,2)]);
  uninterrupted.substep(1,1,2,[{...pose(0,2),substep:1},{...pose(1,2),substep:1}]);
  assert.ok(uninterrupted.summary().reasons.includes('trace-not-sealed'));
  uninterrupted.seal(1);assert.equal(uninterrupted.summary().complete,true);
  const unsupported=new ContactTrace(1,1,0,true,1);
  unsupported.substep(1,0,1,[pose(0)]);
  unsupported.event({tick:1,substep:0,slot:0,kind:'unsupported',reason:'ferry-secured'});unsupported.seal(1);
  assert.ok(unsupported.summary().reasons.includes('unsupported-simulation-path'));
  assert.ok(unsupported.summary().reasons.includes('trace-overflow'));
});

test('unsupported special surfaces and out-of-corridor poses are explicit',()=>{
  const lane={x:20},pose={x:20,z:3500,supportId:'ground',inDome:false,loopAngle:null};
  assert.equal(unsupportedPose(pose,lane,4100,3000),null);
  assert.equal(unsupportedPose({...pose,supportId:'ferry'},lane,4100,3000),'special-surface-or-flight');
  assert.equal(unsupportedPose({...pose,inDome:true},lane,4100,3000),'special-surface-or-flight');
  assert.equal(unsupportedPose({...pose,loopAngle:0},lane,4100,3000),'special-surface-or-flight');
  assert.equal(unsupportedPose({...pose,x:24},lane,4100,3000),'outside-staged-corridor');
  assert.equal(unsupportedPose({...pose,z:NaN},lane,4100,3000),'outside-staged-corridor');
});

test('authoritative decision hooks run for each substep without changing physics',async()=>{
  const {createEmptyWorld,makeEntity,step}=await import('../shared/game');
  const {BUILDINGS}=await import('../shared/map');
  const world=createEmptyWorld();
  world.entities.push(makeEntity('a','roadster',0,4100,'one'),makeEntity('b','roadster',0,4100,'two'),
    makeEntity('wall','roadster',BUILDINGS[0].x,BUILDINGS[0].z,'three'));
  const control=structuredClone(world),order:string[]=[],events:string[]=[];
  step(control,new Map(),.05,{substeps:2});
  step(world,new Map(),.05,{substeps:2,diagnostic:{
    begin:(i,count)=>order.push(`begin:${i}/${count}`),
    event:(i,kind,a,b)=>events.push(`${i}:${kind}:${a.id}:${b?.id??''}`),
    end:(i,count)=>order.push(`end:${i}/${count}`),
  }});
  assert.deepEqual(world,control);
  assert.deepEqual(order,['begin:0/2','end:0/2','begin:1/2','end:1/2']);
  assert.ok(events.some(event=>event.includes(':entity:a:b')));
  assert.ok(events.some(event=>event.includes(':solid:wall:')));
});

test('the progression gate reports the blocked player inside the simulation',async()=>{
  const {createEmptyWorld,addPlayer,step}=await import('../shared/game');
  const world=createEmptyWorld(),player=addPlayer(world,'gate-driver','Gate');
  const car=world.entities.find(entity=>entity.id===player.entityId)!;
  Object.assign(car,{x:109.9,z:60,y:0,yaw:-Math.PI/2,speed:70,supportId:'ground'});
  const events:string[]=[];
  step(world,new Map(),.05,{diagnostic:{begin:()=>{},event:(_i,kind,entity)=>events.push(`${kind}:${entity.id}`),end:()=>{}}});
  assert.ok(events.includes(`progression:${car.id}`));
  assert.equal(player.delivery.lastBlocked?.level,1);
});

test('real Session resumes input after staged equal-tick snapshots begin advancing',async()=>{
  const {Session}=await import('../src/session');
  const {createWorld,addPlayer,NEUTRAL,PROTOCOL_VERSION}=await import('../shared/game');
  const {ScheduledInput}=await import('../shared/tick-input');
  const original={WebSocket:globalThis.WebSocket,window:globalThis.window,location:globalThis.location};
  let last:FakeSocket|undefined,now=0;
  class FakeSocket {
    static OPEN=1;readyState=1;onmessage:((event:{data:string})=>void)|null=null;onclose:((event:{code:number;reason:string})=>void)|null=null;onerror:(()=>void)|null=null;
    sent:unknown[]=[];constructor(_url:string){last=this;}
    send(data:string){this.sent.push(JSON.parse(data));}
    close(){this.readyState=3;this.onclose?.({code:1000,reason:''});}
    emit(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
  }
  try{
    Object.defineProperty(globalThis,'WebSocket',{value:FakeSocket,configurable:true,writable:true});
    Object.defineProperty(globalThis,'window',{value:globalThis,configurable:true,writable:true});
    Object.defineProperty(globalThis,'location',{value:new URL('https://example.invalid'),configurable:true,writable:true});
    const world=createWorld(0);addPlayer(world,'test-driver','Test');
    const session=new Session(()=>now);session.join('gha-1-1','Test');assert.ok(last);
    last.emit({type:'welcome',id:'test-driver',version:PROTOCOL_VERSION,tick:10,roomEpoch:'epoch',poseRevision:0,capacity:2});
    const control=new ScheduledInput({...NEUTRAL}).snapshot();
    const state=(tick:number)=>last!.emit({type:'state',world,tick,roomEpoch:'epoch',poseRevision:1,substeps:1,control});
    state(10);assert.equal(session.status,'online');
    now=1000;state(10);session.tick(.05,{...NEUTRAL,throttle:1});
    assert.equal(last.sent.filter((v:any)=>v.type==='input').length,0);
    now=1050;state(11);session.tick(.05,{...NEUTRAL,throttle:1});
    assert.equal(last.sent.filter((v:any)=>v.type==='input').length,1);
    session.disconnect();
  }finally{
    for(const [key,value] of Object.entries(original)){
      if(value===undefined)delete (globalThis as any)[key];else Object.defineProperty(globalThis,key,{value,configurable:true,writable:true});
    }
  }
});

test('Node WebSocket transport sends admission headers only to loopback',async()=>{
  const {createServer}=await import('node:http');
  const server=createServer();
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
  const address=server.address();assert.ok(address&&typeof address!=='string');
  let timeout:ReturnType<typeof setTimeout>|undefined;
  try{
    const observed=new Promise<{authorization:unknown;slot:unknown}>((resolve,reject)=>{
      timeout=setTimeout(()=>reject(new Error('Upgrade not observed')),3000);
      server.once('upgrade',(request,socket)=>{resolve({authorization:request.headers.authorization,slot:request.headers['x-lab-slot']});socket.destroy();});
    });
    const socket=new (WebSocket as any)(`ws://127.0.0.1:${address.port}/`,{headers:{Authorization:'Bearer test-only','x-lab-slot':'7'}});
    socket.addEventListener('error',()=>{});
    assert.deepEqual(await observed,{authorization:'Bearer test-only',slot:'7'});
  }finally{if(timeout)clearTimeout(timeout);await new Promise<void>(resolve=>server.close(()=>resolve()));}
});
