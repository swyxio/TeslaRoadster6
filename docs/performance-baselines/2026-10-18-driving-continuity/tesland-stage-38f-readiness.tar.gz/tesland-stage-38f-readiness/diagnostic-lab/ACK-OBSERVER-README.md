# Exact applied-input observer: separate diagnostic prototype

This standalone module is not integrated into the staged driver and is not release or capacity evidence. It was developed against the older diagnostic checkout at `a53d0998ef83ead142ca498d6bfbedc57d628c65` (gameplay candidate `623884560ed3d902090c36ff04b790d1c714bb84`). Source, protocol and identity must be rechecked against the final candidate. The staged driver's imported `movementTracker` must first be replaced with the **final pushed** corrected tracker and its regression tests rerun against that exact source. The current checkout contains the old tracker. No remote load was run.

## Meaning and diagnostic-only rule

One observer belongs to one socket, one Session and its welcome `roomEpoch`. On each successful measured input send, record its exact increasing `seq` and the same generator's `performance.now()` timestamp. Pass each raw state frame, its arrival timestamp and `acceptedFrame=true` only after that **same frame** has been successfully validated and processed by Session. The observer independently checks epoch, tick, applied/received sequence metadata and their ordering. An increasing `appliedSeq` is credited only if its exact sequence was recorded in this measurement window. Skipped IDs do not create ACK or latency samples. Previous warmup-only controls, duplicate applied sequences and stale ticks do not count. Unknown measured sequences, advancing-tick sequence regression, malformed frames, epoch changes, clock reversal, impossible observation-before-send and bounded-buffer overflow fence the whole report; later samples cannot recover it. The caller must also call `invalidate` on measured-window rejection, socket close/reconnect, changed identity, failed send or raw loss.

For each exact observation, `upperBoundMs` is time from this generator's send timestamp to receipt of that state frame. Since application happened before the state was observed, this is an upper bound on send-to-application time, including network, serialization and generator scheduling; it is not a direct RTT, individual server work time, or proof of when application occurred. A skipped sequence might still have applied, but this observer cannot establish it. Preserve the exact samples and host/load context; do not infer unobserved acknowledgements or fill them in.

The following are **prototype completeness criteria**, not release latency thresholds: a full ten-second block needs measured sends and exact ACKs, at least 90% of its wall interval covered by pairs of distinct increasing ACKs no more than 1,000 ms and 24 room ticks apart, no uncovered gap over 1,000 ms including both block boundaries, and no unsupported pair spanning any part of that block. A pair that spans a boundary and exceeds either bound invalidates both affected blocks, even if each part of the gap is under one second. This detects incomplete observations; short pairs and coverage do not prove smooth input application between endpoints. A partial final block is incomplete. These thresholds do not impose a pass/fail limit on the measured latency upper bounds.

Only states received between measurement start and end, inclusive at the final endpoint, contribute. Inputs sent before start or at/after end never count. Drain observations are excluded from block coverage because their apply time may be outside the window. Retain overflow and incomplete reasons; do not report missing data as zero. The two bounded per-client stores hold at most 4,096 sends and 4,096 exact samples. Their overhead is unmeasured.

## Integration is still required

The old `hosted-stage-driver.ts` attaches a state listener, queues a microtask, and reads the Session's mutable `prediction.control` later. Closely bunched frames can associate the wrong control with a frame's arrival time. It does not satisfy this observer's contract. Add and test an exact-frame post-processing hook in the final candidate's real `Session` path before calling `state`: it must run only after that specific frame completed Session processing successfully, carrying that frame's unmodified raw metadata and callback arrival time. In the old Session, `snapshotVersion` increments before all processing finishes, so its increment alone does not prove that the frame was accepted. Do not substitute a later Session snapshot, infer acceptance from a tick, or turn `acceptedFrame` on unconditionally. Bind the epoch, player identity and observer lifecycle to one socket and prove send timestamps are captured immediately before a successful synchronous `send` on that same clock.

Before any hosted diagnostic, also finish provider/source/asset and Durable Object isolation checks, 64-driver staged motion and full substep-contact coverage, the cross-boundary movement tracker, group barriers and export, and a paired observer-overhead study. A Session with a closed/reconnected socket or an unavailable/inconsistent input or frame must fail closed. Cloudflare Worker in-callback clock deltas cannot establish p95 tick CPU. The driving-continuity and production performance gates remain separate.

## Focused verification

From the older diagnostic checkout with its existing lockfile dependencies:

```sh
pnpm exec tsx --test /private/tmp/tesland-ack-observer/diagnostic-lab/ack-observer.test.ts
pnpm exec tsc --noEmit --target ES2022 --module ESNext --moduleResolution Bundler --skipLibCheck --types node /private/tmp/tesland-ack-observer/diagnostic-lab/ack-observer.ts /private/tmp/tesland-ack-observer/diagnostic-lab/ack-observer.test.ts
```

Eleven tests and the typecheck passed. Cases include warmup-only, early stall, duplicate and reordered state, skipped and unknown sequences, changed epoch, malformed and unvalidated frames, lifecycle/overflow faults, excessive tick gaps, a 9,050→10,950 ms boundary gap, and 20 Hz sends with 10 Hz snapshots. No Worker, browser, hosted runner or load test was run for this module.
