import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Session} from '../src/session';
import {createWorld,addPlayer,NEUTRAL,PROTOCOL_VERSION} from '../shared/game';
import {ScheduledInput} from '../shared/tick-input';
import {createAckObserver} from './ack-observer';

let clock=0;
class Socket {
  static OPEN=1;static last:Socket;
  readyState=1;onmessage?: (event:{data:string})=>void;
  onclose?: (event:{code:number;reason:string})=>void;onerror?:()=>void;
  onSent?:(seq:number,at:number)=>void;
  constructor(_url:string){Socket.last=this;}
  send(data:string){const msg=JSON.parse(data);if(msg.type==='input')this.onSent?.(msg.seq,clock);}
  close(){this.readyState=3;}
  receive(data:unknown){this.onmessage?.({data:JSON.stringify(data)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'lab.example'}});
function init(){
  clock=0;const s=new Session(()=>clock);s.join('lab','Driver');const socket=Socket.last;
  socket.receive({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'e',tick:0,poseRevision:0});
  const world=createWorld(0);addPlayer(world,'p','Driver');
  const control=new ScheduledInput(NEUTRAL).snapshot();
  const frame=(tick:number,seq:number)=>({type:'state',roomEpoch:'e',tick,poseRevision:0,substeps:1,world,
    control:{...control,receivedSeq:seq,appliedSeq:seq}});
  socket.receive(frame(0,0));
  return {s,socket,frame};
}

test('exact frames observed after actual Session processing credit only successful measured sends',()=>{
  const {s,socket,frame}=init();
  const observer=createAckObserver({epoch:'e',startMs:100,durationMs:10_000});
  const frames:number[]=[];
  socket.onSent=(seq,at)=>observer.measuredSend(seq,at);
  s.onDiagnosticAcceptedState=(value,at)=>{frames.push((value as {tick:number}).tick);observer.state(value,at,true);};
  clock=100;s.tick(.05,{...NEUTRAL,throttle:1});
  clock=120;socket.receive(frame(1,1));
  clock=150;s.tick(.05,{...NEUTRAL,throttle:1});
  clock=170;socket.receive(frame(2,2));
  const result=observer.summary();
  assert.deepEqual(frames,[1,2]);
  assert.deepEqual(result.samples.map(sample=>[sample.seq,sample.sendAtMs,sample.observedAtMs]),[[1,100,120],[2,150,170]]);
  assert.equal(result.blocks[0].complete,false,'two samples are not sustained coverage');
  s.disconnect();
});

test('a frame throwing after snapshotVersion changes is never reported as accepted',()=>{
  const {s,socket,frame}=init();let accepted=0;
  s.onDiagnosticAcceptedState=()=>accepted++;
  const old=console.error;console.error=()=>{};
  try{clock=100;socket.receive({...frame(1,0),world:{players:null,entities:null}});}finally{console.error=old;}
  assert.equal(s.snapshotVersion,2,'the legacy counter changes before processing is complete');
  assert.equal(socket.readyState,3);assert.equal(accepted,0);
  s.disconnect();
});

test('changed epoch or malformed control never reaches the accepted-state hook',()=>{
  for(const alter of [{roomEpoch:'other'},{control:null}]){
    const {s,socket,frame}=init();let accepted=0;s.onDiagnosticAcceptedState=()=>accepted++;
    const old=console.error;console.error=()=>{};
    try{clock=100;socket.receive({...frame(1,0),...alter});}finally{console.error=old;}
    assert.equal(socket.readyState,3);assert.equal(accepted,0);s.disconnect();
  }
});
