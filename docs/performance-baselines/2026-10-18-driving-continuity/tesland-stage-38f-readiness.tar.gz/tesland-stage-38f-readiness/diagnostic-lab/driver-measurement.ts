// Diagnostic-lab only: one exact Session, socket, player and room epoch.
import {createAckObserver} from './ack-observer';
import {movementSample,movementTracker} from '../scripts/load-room';
import type {World} from '../shared/game';

export function createDriverMeasurement(epoch:string,playerId:string,startMs:number,durationMs=60_000){
  if(typeof playerId!=='string'||!playerId)throw new Error('Missing measurement player');
  const ack=createAckObserver({epoch,startMs,durationMs}),movement=movementTracker(durationMs),endMs=startMs+durationMs;
  return {
    epoch,playerId,
    sent(seq:unknown,at:number){if(at>=startMs&&at<endMs)ack.measuredSend(seq,at);},
    // Only the post-processing callback of the same Session may call this.
    accepted(frame:unknown,at:number){
      ack.state(frame,at,true);
      if(at>=startMs&&at<endMs){
        const message=frame as {tick:number;poseRevision:number;roomEpoch?:string;world?:World};
        movement.observe(movementSample(at-startMs,playerId,epoch,message));
      }
    },
    invalidate(reason:'socket-closed'|'identity-changed'|'input-rejected'|'raw-overflow'|'send-error'){ack.invalidate(reason);},
    summary(){return {ack:ack.summary(),movement:movement.summary()};},
  };
}
export type DriverMeasurement=ReturnType<typeof createDriverMeasurement>;

// Record only after the exact synchronous socket send succeeds.
export function sendObserved(measurement:DriverMeasurement|null,seq:unknown,at:number,send:()=>void){
  try{send();}catch(error){measurement?.invalidate('send-error');throw error;}
  measurement?.sent(seq,at);
}
