// Two-client functional smoke against loopback Wrangler only. Not a performance test.
import assert from 'node:assert/strict';
import https from 'node:https';
// Existing pinned pnpm transitive dependency; no install or network needed.
// @ts-ignore test-only absolute pnpm store module has no direct type declaration
import WS from '../node_modules/.pnpm/ws@8.21.0/node_modules/ws/index.js';
import {Session} from '../src/session';
import {NEUTRAL,PROTOCOL_VERSION} from '../shared/game';
import {WarmupGate} from './hosted-stage-core';
import {createDriverMeasurement,sendObserved,type DriverMeasurement} from './driver-measurement';

const host='1234abcd-bay-drive-input-diag.swyxio.workers.dev',port=19331,room='gha-1-1',token='a'.repeat(64);
const expected=`wss://${host}/api/room/${room}`;
let gate:WarmupGate|null=null,next=0;const measurements:(DriverMeasurement|null)[]=[null,null];
class LocalSocket extends WS {
  private slot:number;
  constructor(url:string){
    if(url!==expected)throw new Error('Only local smoke target allowed');const slot=next++;
    super(`wss://127.0.0.1:${port}/api/room/${room}`,{servername:host,rejectUnauthorized:false,
      headers:{Host:host,Authorization:`Bearer ${token}`,'x-lab-slot':String(slot)}});
    this.slot=slot;
    (this as unknown as WebSocket).addEventListener('message',event=>{const m=JSON.parse(String(event.data));if(m.type==='state')gate?.observe(slot,m.tick,performance.now());});
  }
  send(data:any,...args:any[]){
    if(typeof data==='string'&&data.startsWith('{"type":"input"')){
      const value=JSON.parse(data),at=performance.now();
      return sendObserved(measurements[this.slot],value.seq,at,()=>super.send(data,...args));
    }
    return super.send(data,...args);
  }
}
async function request(path:string,options:{method?:string;authorized?:boolean;host?:string;group?:number}={}){
  return await new Promise<{status:number;body:string}>((resolve,reject)=>{
    const headers:Record<string,string>={Host:options.host??host};if(options.authorized)headers.Authorization=`Bearer ${token}`;
    if(options.group!==undefined)headers['x-lab-group']=String(options.group);
    const req=https.request({hostname:'127.0.0.1',port,path,servername:host,rejectUnauthorized:false,method:options.method??'GET',headers,timeout:4000},res=>{
      let body='';res.setEncoding('utf8');res.on('data',chunk=>body+=chunk);res.on('end',()=>resolve({status:res.statusCode??0,body}));
    });req.on('timeout',()=>req.destroy(new Error('HTTP timeout')));req.on('error',reject);req.end();
  });
}
const wait=async(fn:()=>boolean,description:string)=>{const end=performance.now()+10000;while(!fn()){if(performance.now()>end)throw new Error(`Timed out ${description}`);await new Promise(resolve=>setTimeout(resolve,20));}};
const sessions:Session[]=[];let timer:ReturnType<typeof setInterval>|undefined,drive=false;
try{
  assert.equal((await request('/api/health',{host:'bay-drive.swyxio.workers.dev'})).status,403);
  assert.equal((await request(`/api/lab/status/${room}`)).status,401);
  assert.equal((await request('/api/room/bay',{authorized:true})).status,404);
  const health=JSON.parse((await request('/api/health')).body);assert.equal(health.version,PROTOCOL_VERSION);
  Object.defineProperty(globalThis,'WebSocket',{value:LocalSocket,configurable:true,writable:true});
  Object.defineProperty(globalThis,'location',{value:new URL(`https://${host}`),configurable:true,writable:true});
  Object.defineProperty(globalThis,'window',{value:globalThis,configurable:true,writable:true});
  for(let i=0;i<2;i++){const session=new Session();sessions.push(session);session.onDiagnosticAcceptedState=(frame,at)=>measurements[i]?.accepted(frame,at);session.join(room,`Driver ${i}`);}
  timer=setInterval(()=>{for(const s of sessions)s.tick(.016,drive?{...NEUTRAL,throttle:1}:NEUTRAL);},16);
  await wait(()=>sessions.every(s=>s.status==='online'&&s.identityResult?.ok===true),'for real Session identity');
  let status:any;
  const statusUntil=performance.now()+10000;
  do{const r=await request(`/api/lab/status/${room}`,{authorized:true});assert.equal(r.status,200);status=JSON.parse(r.body);if(status.ready)break;await new Promise(resolve=>setTimeout(resolve,30));}while(performance.now()<statusUntil);
  assert.equal(status.ready,true);assert.equal(status.expectedDrivers,2);
  assert.deepEqual(status.staged.map((item:any)=>item.slot).sort(),[0,1]);assert.ok(status.staged.every((item:any)=>item.exact&&item.economy));
  const duplicate=await new Promise<number>((resolve,reject)=>{
    const socket=new WS(`wss://127.0.0.1:${port}/api/room/${room}`,{servername:host,rejectUnauthorized:false,
      headers:{Host:host,Authorization:`Bearer ${token}`,'x-lab-slot':'0'}});
    socket.on('unexpected-response',(_request:unknown,response:{statusCode:number;resume:()=>void})=>{response.resume();resolve(response.statusCode);});
    socket.on('open',()=>{socket.close();reject(new Error('Duplicate slot was admitted'));});socket.on('error',reject);
  });
  assert.equal(duplicate,409);
  const poses=sessions.map(s=>{const p=s.world.players.find(x=>x.id===s.id)!;return s.world.entities.find(e=>e.id===p.entityId)!.z;});
  const begin=await request(`/api/lab/begin/${room}`,{authorized:true,method:'POST'});assert.equal(begin.status,200);
  const started=JSON.parse(begin.body);assert.equal(started.ok,true);gate=new WarmupGate(2,started.tick);drive=true;
  await wait(()=>!!gate?.ready(performance.now()),'for advancing snapshots');
  const measurementStart=performance.now();
  sessions.forEach((session,i)=>{measurements[i]=createDriverMeasurement((session as any).roomEpoch,session.id,measurementStart,10_000);});
  await wait(()=>measurements.every(m=>!!m&&m.summary().ack.samples.length>0),'for exact measured ACKs on each Session');
  assert.ok(measurements.every(m=>m&&m.summary().ack.reasons.length===0));
  assert.ok(measurements.every(m=>m&&!m.summary().ack.blocks[0].complete),'a short smoke is not sustained ACK coverage');
  await wait(()=>sessions.every((s,i)=>{const p=s.world.players.find(x=>x.id===s.id);const car=s.world.entities.find(e=>e.id===p?.entityId);return !!car&&poses[i]-car.z>.01;}),'for each Session to move');
  const substepDeadline=performance.now()+10000;
  do{status=JSON.parse((await request(`/api/lab/status/${room}`,{authorized:true})).body);if(status.substeps>1)break;await new Promise(resolve=>setTimeout(resolve,30));}while(performance.now()<substepDeadline);
  assert.ok(status.substeps>1,'expected an actual adaptive multi-substep tick');
  assert.equal(status.started,true);assert.ok(status.tick>=started.tick+3);
  assert.equal(status.trace.complete,false);assert.ok(status.trace.reasons.includes('authoritative-substep-hooks-unverified'));
  assert.equal((await request(`/api/lab/trace/${room}`,{authorized:true})).status,409);
  for(let group=1;group<=4;group++)assert.equal((await request(`/api/lab/done/${room}`,{authorized:true,method:'POST',group})).status,200);
  const exported=await request(`/api/lab/trace/${room}?offset=0&limit=1000`,{authorized:true});assert.equal(exported.status,200);
  const trace=JSON.parse(exported.body);assert.ok(trace.poses.length>0);assert.equal(trace.summary.complete,false);
  assert.ok(trace.summary.reasons.includes('authoritative-substep-hooks-unverified'));
  assert.ok(!trace.summary.reasons.includes('invalid-or-missing-substep-data'));
  assert.ok(trace.poses.every((pose:any)=>Number.isInteger(pose.substep)&&pose.substep>=0&&pose.substep<pose.substeps&&pose.substeps<=8));
  assert.ok(trace.poses.some((pose:any)=>pose.substep>0));
  assert.deepEqual([...new Set(trace.poses.map((pose:any)=>pose.slot))].sort(),[0,1]);
  console.log(JSON.stringify({local:true,realSessions:2,uniqueSlots:true,normalEconomy:true,advancingWarmup:true,eachMoved:true,eachExactMeasuredAck:true,sustainedAckNotMeasured:true,contactEvidenceIncomplete:true,traceSealedAndExported:true,substepIndexes:[...new Set(trace.poses.map((pose:any)=>pose.substep))].sort()}));
}finally{
  if(timer)clearInterval(timer);for(const s of sessions)s.disconnect();
}
