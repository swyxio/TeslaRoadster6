import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createAckObserver} from './ack-observer';

const state=(tick:number,appliedSeq:number,roomEpoch='epoch')=>({type:'state',roomEpoch,tick,control:{appliedSeq,receivedSeq:appliedSeq}});
const observe=(observer:ReturnType<typeof createAckObserver>,value:unknown,at:number)=>observer.state(value,at,true);

test('warmup-only or unobserved input cannot complete a measured block',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:1000,durationMs:10_000});
  observe(observer,state(10,4),900);
  observe(observer,state(11,4),1000);
  observer.measuredSend(5,1100);
  observe(observer,state(12,4),1200);
  const result=observer.summary();
  assert.equal(result.samples.length,0);assert.equal(result.warmupUnmatched,2);
  assert.equal(result.blocks[0].complete,false);assert.equal(result.blocks[0].coveredMs,0);
});

test('20 Hz sends and 10 Hz snapshots credit only exact observed sequences',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  for(let t=0;t<10_000;t+=50){
    observer.measuredSend(t/50+1,t);
    if(t>0&&t%100===0)observe(observer,state(t/50,t/50),t);
  }
  observe(observer,state(200,200),10_000);
  const result=observer.summary(),block=result.blocks[0];
  assert.equal(result.reasons.length,0);assert.equal(block.sent,200);assert.equal(block.exactAcks,100);
  assert.equal(block.coveredMs,9900);assert.equal(block.maxUncoveredMs,100);assert.equal(block.complete,true);
  assert.ok(result.samples.every(sample=>sample.upperBoundMs===50));
  assert.ok(result.samples.every(sample=>sample.seq%2===0));
});

test('a brief early burst followed by duplicate applied sequences is incomplete',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  for(let t=0;t<=1000;t+=100){observer.measuredSend(t/100+1,t);observe(observer,state(t/50,t/100+1),t);}
  for(let t=1100;t<=10_000;t+=100)observe(observer,state(t/50,11),t);
  const result=observer.summary();
  assert.equal(result.samples.length,11);assert.equal(result.duplicates,90);
  assert.equal(result.blocks[0].coveredMs,1000);assert.equal(result.blocks[0].maxUncoveredMs,9000);
  assert.equal(result.blocks[0].complete,false);
});

test('a gap spanning the boundary invalidates both blocks even if each side is under one second',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:20_000});
  let seq=0;
  for(let t=50;t<=20_000;t+=100){
    if(t>9050&&t<10_950)continue;
    seq++;const sentAt=t===20_000?19_999:t-1;observer.measuredSend(seq,sentAt);
    observe(observer,state(t/50,seq),t);
  }
  const result=observer.summary();
  assert.equal(result.reasons.length,0);
  assert.deepEqual(result.blocks.map(block=>block.invalidBridges),[1,1]);
  assert.deepEqual(result.blocks.map(block=>block.complete),[false,false]);
  assert.ok(result.blocks.every(block=>block.maxUncoveredMs<=1000));
  assert.ok(result.blocks.every(block=>block.coveredMs>=9000));
});

test('duplicate and reordered snapshots do not create additional acknowledgements',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  observer.measuredSend(1,0);observer.measuredSend(3,50);
  observe(observer,state(1,1),60);
  observe(observer,state(2,1),70);
  observe(observer,state(1,3),80); // older tick: cannot establish a new applied value
  observe(observer,state(3,3),100);
  assert.deepEqual(observer.summary().samples.map(sample=>sample.seq),[1,3]);
  assert.equal(observer.summary().duplicates,1);assert.equal(observer.summary().staleSnapshots,1);
  observe(observer,state(4,1),110); // sequence regression at a newer tick fences the run
  assert.ok(observer.summary().reasons.includes('applied-sequence-regressed'));
  observer.measuredSend(4,120);observe(observer,state(5,4),130);
  assert.deepEqual(observer.summary().samples.map(sample=>sample.seq),[1,3]);
  assert.equal(observer.summary().blocks[0].complete,false);
});

test('unknown applied sequence fences the run even when surrounding sent IDs exist',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  observer.measuredSend(1,0);observer.measuredSend(3,50);
  observe(observer,state(1,1),60);observe(observer,state(2,2),70);
  observe(observer,state(3,3),100);
  const result=observer.summary();
  assert.equal(result.unknown,1);assert.ok(result.reasons.includes('unknown-applied-sequence'));
  assert.deepEqual(result.samples.map(sample=>sample.seq),[1]);assert.equal(result.blocks[0].complete,false);
});

test('epoch changes and malformed states fence later samples',()=>{
  const badValues=[null,{},state(-1,1),state(1,NaN),{...state(1,1),control:null},
    {...state(1,2),control:{appliedSeq:2,receivedSeq:1}},state(1,1,'other')];
  for(const bad of badValues){
    const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
    observer.measuredSend(1,0);observe(observer,bad,10);observe(observer,state(2,1),20);
    const result=observer.summary();
    assert.ok(result.reasons.length>0);assert.equal(result.samples.length,0);assert.equal(result.blocks[0].complete,false);
    if(bad===badValues.at(-1))assert.ok(result.reasons.includes('room-epoch-changed'));
  }
});

test('an unvalidated frame cannot be credited even if its acknowledgement is known',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  observer.measuredSend(1,0);observer.state(state(1,1),10,false);observe(observer,state(2,1),20);
  assert.ok(observer.summary().reasons.includes('state-not-session-validated'));
  assert.equal(observer.summary().samples.length,0);
});

test('future send times, clocks that go backwards and buffer exhaustion fail closed',()=>{
  const future=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  future.measuredSend(1,100);observe(future,state(1,1),50);
  assert.ok(future.summary().reasons.includes('acknowledgement-before-send'));
  const backwards=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  observe(backwards,state(1,0),100);observe(backwards,state(2,0),99);
  assert.ok(backwards.summary().reasons.includes('malformed-or-reordered-state'));
  const overflow=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000,maxRecords:1});
  overflow.measuredSend(1,0);overflow.measuredSend(2,10);observe(overflow,state(1,1),20);
  assert.ok(overflow.summary().reasons.includes('send-record-overflow'));
  assert.equal(overflow.summary().samples.length,0);
});

test('a short wall interval with an excessive tick jump cannot cover the block',()=>{
  const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
  observer.measuredSend(1,0);observe(observer,state(1,1),0);
  observer.measuredSend(2,50);observe(observer,state(26,2),100);
  const block=observer.summary().blocks[0];
  assert.equal(block.invalidBridges,1);assert.equal(block.coveredMs,0);assert.equal(block.complete,false);
});

test('observed warmup sequence and external lifecycle failures fence reuse',()=>{
  const reused=createAckObserver({epoch:'epoch',startMs:1000,durationMs:10_000});
  observe(reused,state(10,8),900);reused.measuredSend(8,1000);
  assert.ok(reused.summary().reasons.includes('malformed-or-reordered-send'));
  for(const reason of ['socket-closed','identity-changed','input-rejected','raw-overflow','send-error'] as const){
    const observer=createAckObserver({epoch:'epoch',startMs:0,durationMs:10_000});
    observer.measuredSend(1,0);observe(observer,state(1,1),10);observer.invalidate(reason);
    observer.measuredSend(2,100);observe(observer,state(2,2),120);
    assert.ok(observer.summary().reasons.includes(reason));assert.equal(observer.summary().samples.length,1);
    assert.equal(observer.summary().blocks[0].complete,false);
  }
});
