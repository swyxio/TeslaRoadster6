// Standalone, diagnostic-only observer. Times are from one generator's monotonic clock.
const BLOCK_MS=10_000, MAX_PAIR_MS=1_000, MAX_PAIR_TICKS=24, MIN_COVERAGE=.9;
type AckSample={seq:number;sendAtMs:number;observedAtMs:number;tick:number;upperBoundMs:number};
type Block={startMs:number;endMs:number;sent:number;exactAcks:number;coveredMs:number;firstCoveredMs:number|null;lastCoveredMs:number|null;internalGapMs:number;invalidBridges:number;maxUpperBoundMs:number|null};
const whole=(value:unknown):value is number=>typeof value==='number'&&Number.isSafeInteger(value)&&value>=0;
const finite=(value:unknown):value is number=>typeof value==='number'&&Number.isFinite(value);

export function createAckObserver(options:{epoch:string;startMs:number;durationMs:number;maxRecords?:number}){
  const {epoch,startMs,durationMs,maxRecords=4096}=options;
  if(typeof epoch!=='string'||!epoch.length||epoch.length>256||!finite(startMs)||startMs<0||
    !finite(durationMs)||durationMs<=0||durationMs>120_000||!whole(maxRecords)||maxRecords<1||maxRecords>4096)
    throw new Error('Invalid acknowledgement observer configuration');
  const endMs=startMs+durationMs;
  if(!finite(endMs))throw new Error('Invalid acknowledgement window');
  const blocks:Block[]=Array.from({length:Math.ceil(durationMs/BLOCK_MS)},(_,i)=>({
    startMs:startMs+i*BLOCK_MS,endMs:Math.min(endMs,startMs+(i+1)*BLOCK_MS),sent:0,exactAcks:0,
    coveredMs:0,firstCoveredMs:null,lastCoveredMs:null,internalGapMs:0,invalidBridges:0,maxUpperBoundMs:null,
  }));
  const sent=new Map<number,number>(),samples:AckSample[]=[],reasons=new Set<string>();
  let firstMeasuredSeq:number|null=null,lastSentSeq=0,lastSendAt=-Infinity,lastStateAt=-Infinity,lastStateTick=-1,lastObservedSeq=0;
  let lastAck:AckSample|null=null,warmupUnmatched=0,duplicates=0,staleSnapshots=0,unknown=0;
  const fence=(reason:string)=>{reasons.add(reason);};
  const blockAt=(at:number)=>blocks[Math.min(blocks.length-1,Math.floor((at-startMs)/BLOCK_MS))];
  const notePair=(a:AckSample,b:AckSample)=>{
    const gap=b.observedAtMs-a.observedAtMs,ticks=b.tick-a.tick;
    const supported=gap>0&&gap<=MAX_PAIR_MS&&ticks>0&&ticks<=MAX_PAIR_TICKS;
    for(const block of blocks){
      const left=Math.max(a.observedAtMs,block.startMs),right=Math.min(b.observedAtMs,block.endMs);
      if(right<=left)continue;
      // An overlong pair marks *every* crossed block, including when its two
      // partial pieces are individually shorter than the boundary allowance.
      if(!supported){block.invalidBridges++;continue;}
      if(block.firstCoveredMs===null){block.firstCoveredMs=left;block.lastCoveredMs=left;}
      block.internalGapMs=Math.max(block.internalGapMs,left-block.lastCoveredMs!);
      const newStart=Math.max(left,block.lastCoveredMs!);
      if(right>newStart)block.coveredMs+=right-newStart;
      block.lastCoveredMs=Math.max(block.lastCoveredMs!,right);
    }
  };
  return {
    // Callers must fence evidence on connection/identity/rejection or raw-data loss.
    invalidate(reason:'socket-closed'|'identity-changed'|'input-rejected'|'raw-overflow'|'send-error'):void{
      if(!['socket-closed','identity-changed','input-rejected','raw-overflow','send-error'].includes(reason)){
        fence('invalid-external-fence');return;
      }
      fence(reason);
    },
    // Call only after WebSocket.send succeeds; capture `at` immediately before
    // that synchronous call, and call this immediately afterwards.
    measuredSend(seq:unknown,at:unknown):void{
      if(reasons.size)return;
      if(!whole(seq)||seq===0||!finite(at)||at<startMs||at>=endMs||seq<=lastSentSeq||at<lastSendAt||
        (firstMeasuredSeq===null&&seq<=lastObservedSeq)){fence('malformed-or-reordered-send');return;}
      if(sent.size>=maxRecords){fence('send-record-overflow');return;}
      sent.set(seq,at);firstMeasuredSeq??=seq;lastSentSeq=seq;lastSendAt=at;blockAt(at).sent++;
    },
    // `acceptedFrame` must refer to this exact raw frame's Session validation,
    // never a later mutable Session control snapshot.
    state(value:unknown,at:unknown,acceptedFrame:unknown):void{
      if(reasons.size)return;
      if(acceptedFrame!==true){fence('state-not-session-validated');return;}
      if(!finite(at)||at<0||at<lastStateAt||!value||typeof value!=='object'){fence('malformed-or-reordered-state');return;}
      const state=value as Record<string,unknown>,control=state.control;
      if(state.type!=='state'||typeof state.roomEpoch!=='string'||!state.roomEpoch.length||state.roomEpoch.length>256||
        !whole(state.tick)||!control||typeof control!=='object'||!whole((control as Record<string,unknown>).appliedSeq)||
        !whole((control as Record<string,unknown>).receivedSeq)||
        Number((control as Record<string,unknown>).appliedSeq)>Number((control as Record<string,unknown>).receivedSeq)){
        fence('malformed-state');return;
      }
      if(state.roomEpoch!==epoch){fence('room-epoch-changed');return;}
      lastStateAt=at;
      if(state.tick<=lastStateTick){staleSnapshots++;return;}
      lastStateTick=state.tick;
      const seq=(control as {appliedSeq:number}).appliedSeq;
      if(seq<lastObservedSeq){fence('applied-sequence-regressed');return;}
      lastObservedSeq=seq;
      if(at<startMs||at>endMs)return;
      if(lastAck&&seq===lastAck.seq){duplicates++;return;}
      if(firstMeasuredSeq===null||seq<firstMeasuredSeq){warmupUnmatched++;return;}
      const sendAt=sent.get(seq);
      if(sendAt===undefined){unknown++;fence('unknown-applied-sequence');return;}
      if(sendAt>at){fence('acknowledgement-before-send');return;}
      if(samples.length>=maxRecords){fence('ack-record-overflow');return;}
      const sample={seq,sendAtMs:sendAt,observedAtMs:at,tick:state.tick,upperBoundMs:at-sendAt};
      samples.push(sample);
      const block=blockAt(at);block.exactAcks++;block.maxUpperBoundMs=Math.max(block.maxUpperBoundMs??0,sample.upperBoundMs);
      if(lastAck)notePair(lastAck,sample);
      lastAck=sample;
    },
    summary(){
      return {epoch,window:{startMs,endMs},reasons:[...reasons],warmupUnmatched,duplicates,staleSnapshots,unknown,
        samples:samples.map(sample=>({...sample})),blocks:blocks.map(block=>{
          const duration=block.endMs-block.startMs;
          const maxUncoveredMs=block.firstCoveredMs===null||block.lastCoveredMs===null?duration:
            Math.max(block.firstCoveredMs-block.startMs,block.endMs-block.lastCoveredMs,block.internalGapMs);
          const complete=reasons.size===0&&duration===BLOCK_MS&&block.sent>0&&block.exactAcks>0&&
            block.coveredMs>=duration*MIN_COVERAGE&&maxUncoveredMs<=MAX_PAIR_MS&&block.invalidBridges===0;
          return {...block,durationMs:duration,maxUncoveredMs,complete};
        })};
    },
  };
}
