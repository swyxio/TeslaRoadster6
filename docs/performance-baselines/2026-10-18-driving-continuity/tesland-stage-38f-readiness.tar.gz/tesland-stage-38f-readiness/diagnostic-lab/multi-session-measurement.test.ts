import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Session} from '../src/session';
import {createWorld,addPlayer,NEUTRAL,PROTOCOL_VERSION} from '../shared/game';
import {ScheduledInput} from '../shared/tick-input';
import {createDriverMeasurement,sendObserved,type DriverMeasurement} from './driver-measurement';

let now=0;
class Socket {
  static OPEN=1;static last:Socket;
  readyState=1;onmessage?: (event:{data:string})=>void;onclose?: (event:{code:number;reason:string})=>void;
  onerror?:()=>void;measurement:DriverMeasurement|null=null;lastSent=0;failNext=false;
  constructor(_url:string){Socket.last=this;}
  send(data:string){
    const msg=JSON.parse(data);
    if(msg.type!=='input')return;
    sendObserved(this.measurement,msg.seq,now,()=>{
      if(this.failNext){this.failNext=false;throw new Error('synthetic send failure');}
      this.lastSent=msg.seq;
    });
  }
  close(){this.readyState=3;}
  receive(data:unknown){this.onmessage?.({data:JSON.stringify(data)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'lab.example'}});

test('two real Sessions bind exact sends and frames independently and cover one moving block',()=>{
  now=0;
  const world=createWorld(0);addPlayer(world,'p1','One');addPlayer(world,'p2','Two');
  const sessions:Session[]=[],sockets:Socket[]=[],observers:DriverMeasurement[]=[];
  const control=new ScheduledInput(NEUTRAL).snapshot();
  for(const id of ['p1','p2']){
    const s=new Session(()=>now);s.join('lab',id);const socket=Socket.last;
    socket.receive({type:'welcome',id,version:PROTOCOL_VERSION,capacity:64,roomEpoch:'epoch',tick:0,poseRevision:0});
    socket.receive({type:'state',roomEpoch:'epoch',tick:0,poseRevision:0,substeps:1,world,control});
    const observer=createDriverMeasurement('epoch',id,100,10_000);
    socket.measurement=observer;s.onDiagnosticAcceptedState=(frame,at)=>observer.accepted(frame,at);
    sessions.push(s);sockets.push(socket);observers.push(observer);
  }
  const cars=['p1','p2'].map(id=>world.entities.find(e=>e.driver===id)!);
  const origins=cars.map(car=>car.x);
  for(let elapsed=0;elapsed<10_000;elapsed+=50){
    now=100+elapsed;
    for(const s of sessions)s.tick(.05,{...NEUTRAL,throttle:1});
    if(elapsed>0&&elapsed%100===0){
      world.time=elapsed/1000;
      cars.forEach((car,i)=>{car.x=origins[i]+elapsed/100;car.vx=10;car.vy=0;car.vz=0;});
      sockets.forEach(socket=>socket.receive({type:'state',roomEpoch:'epoch',tick:elapsed/50,poseRevision:0,substeps:1,world,
        control:{...control,receivedSeq:socket.lastSent,appliedSeq:socket.lastSent}}));
    }
  }
  for(const observer of observers){
    const result=observer.summary();
    assert.equal(result.ack.reasons.length,0);assert.equal(result.ack.blocks[0].complete,true);
    assert.equal(result.movement.blocks[0].complete,true);assert.equal(result.ack.samples.length,99);
    assert.ok(result.ack.samples.every(sample=>sample.seq>0&&sample.upperBoundMs>=0));
  }
  sessions.forEach(s=>s.disconnect());
});

test('a failed socket send fences its observer and never registers an acknowledgement',()=>{
  const observer=createDriverMeasurement('epoch','p1',0,10_000);
  assert.throws(()=>sendObserved(observer,1,100,()=>{throw new Error('send failed');}));
  const result=observer.summary();
  assert.deepEqual(result.ack.reasons,['send-error']);assert.equal(result.ack.blocks[0].sent,0);
  assert.equal(result.ack.samples.length,0);assert.equal(result.ack.blocks[0].complete,false);
});

test('unknown applied sequence fences only its own Session and cannot borrow another sender',()=>{
  now=0;const world=createWorld(0);addPlayer(world,'p1','One');addPlayer(world,'p2','Two');
  const control=new ScheduledInput(NEUTRAL).snapshot(),sessions:Session[]=[],sockets:Socket[]=[],observers:DriverMeasurement[]=[];
  for(const id of ['p1','p2']){
    const session=new Session(()=>now);session.join('lab',id);const socket=Socket.last;
    socket.receive({type:'welcome',id,version:PROTOCOL_VERSION,capacity:64,roomEpoch:'epoch',tick:0,poseRevision:0});
    socket.receive({type:'state',roomEpoch:'epoch',tick:0,poseRevision:0,substeps:1,world,control});
    const observer=createDriverMeasurement('epoch',id,100,10_000);
    socket.measurement=observer;session.onDiagnosticAcceptedState=(frame,at)=>observer.accepted(frame,at);
    sessions.push(session);sockets.push(socket);observers.push(observer);
  }
  now=100;sessions.forEach(session=>session.tick(.05,{...NEUTRAL,throttle:1}));
  now=150;
  sockets[0].receive({type:'state',roomEpoch:'epoch',tick:1,poseRevision:0,substeps:1,world,
    control:{...control,receivedSeq:1,appliedSeq:1}});
  sockets[1].receive({type:'state',roomEpoch:'epoch',tick:1,poseRevision:0,substeps:1,world,
    control:{...control,receivedSeq:99,appliedSeq:99}});
  assert.deepEqual(observers[0].summary().ack.samples.map(sample=>sample.seq),[1]);
  assert.equal(observers[0].summary().ack.reasons.length,0);
  assert.deepEqual(observers[1].summary().ack.reasons,['unknown-applied-sequence']);
  assert.equal(observers[1].summary().ack.samples.length,0);
  sessions.forEach(session=>session.disconnect());
});
