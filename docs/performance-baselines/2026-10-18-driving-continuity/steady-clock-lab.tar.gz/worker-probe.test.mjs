import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import ts from 'typescript';
import { continuityWorkerSource } from './scripts/continuity-worker-template.mjs';

for (const native of [false, true]) test(`the same room records actual substeps${native ? ' inside native clock marks' : ''}`, () => {
  const stage = `class StageRoom {
    ctx: any; env: any; world: any; sessions: any; tickCount = 0;
    constructor(ctx: any, env: any) {
      this.ctx=ctx; this.env=env; this.world={entities:[],players:[{id:'driver',entityId:'car'}],time:0};
      this.sessions=new Map([[{}, {id:'driver',poseRevision:4}]]);
    }
    tick() {
      (globalThis as any).events.push('tick');
      const probe=(globalThis as any).__teslandContinuityProbe;
      for(let i=0;i<2;i++){
        probe.boundary(this.world,'before'); this.world.entities[0].x+=.3;
        probe.boundary(this.world,'after');
      }
      this.tickCount++; this.world.time+=.05;
    }
  }`;
  const transformed = stage + '\n' + continuityWorkerSource('/target/stage.ts', { grounded: true, native })
    .replace(/^import base,.*$/m, '').replace(/^export \{.*$/m, '')
    .replace('export class GameRoom', 'class GameRoom').replace('export default {', 'const worker = {') + '\nglobalThis.result = { GameRoom };';
  const transpiled = ts.transpileModule(transformed, { reportDiagnostics: true, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } });
  assert.deepEqual((transpiled.diagnostics ?? []).filter(d => d.category === ts.DiagnosticCategory.Error), []);
  const events = [];
  const context = { URL, Response, TextEncoder, events, performance: native ? { now: () => { events.push('marker'); return 1700000000000 + events.length; } } : performance,
    base: { fetch: () => new Response('game') } };
  vm.runInNewContext(transpiled.outputText, context);
  const env = { ROOMS: { idFromName: name => name } };
  const room = new context.result.GameRoom({ id: { equals: id => id === 'motion-abc' } }, env);
  room.world.entities.push({ id: 'car', x: 0, y: 0, z: 0, yaw: 0, vx: 12, vy: 0, vz: 0, supportId: 'ground', inDome: false, loopAngle: null });
  assert.equal(room.traceClock('motion-abc').tick, 0); events.length = 0; room.tick();
  if (native) assert.deepEqual(events, ['marker', 'tick', 'marker']);
  assert.equal(room.traceClock('motion-abc').tick, 1); assert.equal(room.traceClock('motion-abc').poseRevision, 4);
  const result = room.traceRead('motion-abc'), sample = result.ticks[0];
  assert.equal(result.format, 'substep-v1'); assert.equal(sample.start.x, 0);
  if (native) assert.ok(sample.nativeBeforeMs < sample.nativeAfterMs);
  assert.deepEqual(Array.from(sample.substeps, p => p.x), [.3, .6]);
  assert.equal(sample.contactReasons.length, 0); assert.equal(result.clock.continuityVerified, false);
});
