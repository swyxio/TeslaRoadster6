import test from 'node:test';
import assert from 'node:assert/strict';
import { assessSteadyCapture } from './scripts/steady-capture.mjs';

function fixture() {
  const neutral = { throttle:0, steer:0, brake:false, boost:false, hover:false, jump:0, flip:0, roll:0 };
  const drive = { ...neutral, throttle:1 };
  const point = ms => ({ x:-280 + Math.max(0, Math.min(ms - 101, 15000)) * .05, y:0, z:-2100, supportId:'ground' });
  const frames = [], states = [], sent = [], ticks = [];
  for (let t=100, i=0; t<=16100; t+=50, i++) {
    const p=point(t);
    frames.push({atMs:t, visual:{...p}, body:{...p},menu:false});
    sent.push({atMs:t,seq:i+1,input: t < 101 || t >= 15101 ? {...neutral} : {...drive}});
    ticks.push({tick:i+1,poseRevision:1,simTime:i*.05,vx:50,vy:0,vz:0,yaw:-Math.PI/2,...p,contactReasons:[],start:{...p},substeps:[{...p}]});
    if(i%2===0) states.push({atMs:t,tick:i+1,poseRevision:1,otherEntities:0,car:{...p}});
  }
  return {
    trace:{frames,states,sent, controls:[{atMs:0,...neutral},{atMs:110,...drive},{atMs:15110,...neutral}],
      events:[{atMs:101,type:'keydown',code:'KeyW',trusted:true,repeat:false},{atMs:15101,type:'keyup',code:'KeyW',trusted:true,repeat:false}],
      marks:[{atMs:100,label:'drive-start'},{atMs:16100,label:'drive-end'}],turnarounds:[{receivedAtMs:200,elapsedMs:5}],
      dropped:Object.fromEntries(['frames','states','sent','controls','events','marks','turnarounds'].map(k=>[k,0])),errors:0},
    authority:{format:'substep-v1',collisionCoverage:'grounded-path-v1',complete:true,dropped:0,failed:0,ticks},
    profile:'zero',routed:{profile:'zero',overflow:false,sendsFailed:0,droppedEvents:0},connections:1,pageErrors:0,consoleErrors:0,networkErrors:0,pending:0,connectionAtEnd:'LIVE',cleanAfter:true,
  };
}
test('complete trusted steady scenario is diagnostic only',()=>{
 const result=assessSteadyCapture(fixture());
 assert.deepEqual(result.invalid,[]); assert.equal(result.complete,true);assert.equal(result.gateEligible,false);
 assert.equal(result.heldMs,15000);assert.ok(result.keyToFirstMotionObservedMs > 0);
});
test('empty and malformed captures are incomplete',()=>{
 assert.equal(assessSteadyCapture({}).complete,false);
 const f=fixture(); f.authority.ticks[4]=null;
 assert.equal(assessSteadyCapture(f).complete,false);
});
for (const [name, mutate, reason] of [
 ['missing key release',f=>f.trace.events.pop(),'missing-trusted-held-w'],
 ['untrusted key',f=>f.trace.events[0].trusted=false,'missing-trusted-held-w'],
 ['repeated key',f=>f.trace.events[0].repeat=true,'missing-trusted-held-w'],
 ['input rejected',f=>f.trace.events.push({atMs:500,type:'inputRejected'}),'missing-trusted-held-w'],
 ['early release',f=>f.trace.events[1].atMs=10000,'missing-trusted-held-w'],
 ['missing input state',f=>f.trace.controls=[],'incomplete-controls'],
 ['steering during hold',f=>f.trace.controls.splice(2,0,{...f.trace.controls[1],atMs:8000,steer:1}),'incomplete-controls'],
 ['missing sent command',f=>f.trace.sent=[],'incomplete-sent-inputs'],
 ['sent throttle discontinuity',f=>f.trace.sent[100].input.throttle=0,'incomplete-sent-inputs'],
 ['sent gap',f=>f.trace.sent.splice(50,15),'incomplete-sent-inputs'],
 ['no motion',f=>{for(const x of f.trace.frames) x.visual.x=x.body.x=-280;},'missing-first-motion'],
 ['out of corridor',f=>f.authority.ticks[100].substeps[0].z=-2090,'incomplete-ground-authority-or-contact'],
 ['ground contact',f=>f.authority.ticks[100].contactReasons=['building'],'incomplete-ground-authority-or-contact'],
 ['wrong support',f=>f.trace.frames[100].body.supportId='bridge','out-of-route-or-state-tick-range'],
 ['missing tick',f=>f.authority.ticks.splice(100,1),'incomplete-ground-authority-or-contact'],
 ['no steady interval',f=>{for(const [i,t] of f.authority.ticks.entries())t.vx=i%2?20:50;},'missing-steady-simulation-interval'],
 ['relocation',f=>f.authority.ticks[100].poseRevision=2,'incomplete-ground-authority-or-contact'],
 ['trace loss',f=>f.trace.dropped.frames=1,'incomplete-browser-trace'],
 ['stale final snapshot',f=>f.trace.states.splice(-10),'incomplete-window-snapshots'],
 ['missing end frames',f=>f.trace.frames.splice(-20),'incomplete-window-frames'],
 ['incomplete authority',f=>f.authority.complete=false,'incomplete-ground-authority-or-contact'],
 ['different profile',f=>f.profile='gap250','relay-or-page-error'],
]) test(`fails closed: ${name}`,()=>{
 const f=fixture(); mutate(f);const r=assessSteadyCapture(f);assert.equal(r.complete,false);assert.ok(r.invalid.includes(reason),JSON.stringify(r.invalid));
});
