// Local diagnostic only: no inference about same-instant reference speed.
// The audited contact hooks cover the grounded route, not arbitrary surfaces.
const list = x => Array.isArray(x) ? x : [];
const ordered = a => a.every((x, i) => Number.isFinite(x?.atMs) && (!i || x.atMs >= a[i - 1].atMs));
const pos = p => ['x', 'y', 'z'].every(k => Number.isFinite(p?.[k]));
const distance = (a, b) => pos(a) && pos(b) ? Math.hypot(a.x - b.x, a.z - b.z) : null;
const route = p => pos(p) && p.x >= -283 && p.x <= 603 && Math.abs(p.z + 2100) <= 4;
const neutral = c => c?.throttle === 0 && c.steer === 0 && c.brake === false && c.boost === false && c.hover === false && c.jump === 0 && c.flip === 0 && c.roll === 0;
const drive = c => c?.throttle === 1 && c.steer === 0 && c.brake === false && c.boost === false && c.hover === false && c.jump === 0 && c.flip === 0 && c.roll === 0;

// Existence check only. It does not assign any rendered frame to this period.
// Eligibility and all sample ratios remain the analyzer's separate decision.
function longestSteadySimulationSeconds(ticks) {
  let best = 0;
  for (let start = 0; start < ticks.length; start++) {
    let min = Infinity, max = -Infinity;
    for (let end = start; end < ticks.length; end++) {
      const t = ticks[end], speed = Math.hypot(t?.vx, t?.vz);
      if (!Number.isFinite(t?.simTime) || !Number.isFinite(speed) || speed <= 10 || t.vx <= 0 ||
          (end > start && Math.abs(t.simTime - ticks[end-1]?.simTime - .05) > 1e-6)) break;
      min = Math.min(min, speed); max = Math.max(max, speed);
      if (max - min > Math.max(1, .05 * min)) break;
      best = Math.max(best, t.simTime - ticks[start].simTime);
    }
  }
  return best;
}

export function assessSteadyCapture({ trace, authority, profile, routed, connections, pageErrors, consoleErrors, networkErrors, pending, connectionAtEnd, cleanAfter }) {
  const invalid = [], fail = (reason, ok) => { if (!ok) invalid.push(reason); };
  const marks = list(trace?.marks), starts = marks.filter(x => x?.label === 'drive-start'), ends = marks.filter(x => x?.label === 'drive-end');
  const startMs = starts[0]?.atMs, endMs = ends[0]?.atMs;
  const windowOK = starts.length === 1 && ends.length === 1 && Number.isFinite(startMs) && Number.isFinite(endMs) && endMs > startMs;
  const inside = x => windowOK && Number.isFinite(x?.atMs) && x.atMs >= startMs && x.atMs <= endMs;
  const frames = list(trace?.frames).filter(inside), states = list(trace?.states).filter(inside), events = list(trace?.events).filter(inside);
  const controls = list(trace?.controls), sent = list(trace?.sent).filter(inside), ticks = list(authority?.ticks);
  const keys = events.filter(e => e?.type === 'keydown' || e?.type === 'keyup');
  const down = keys[0], up = keys[1], downMs = down?.atMs, upMs = up?.atMs;
  const keyOK = keys.length === 2 && down?.type === 'keydown' && up?.type === 'keyup' && down?.code === 'KeyW' && up?.code === 'KeyW' &&
    down.trusted === true && up.trusted === true && down.repeat === false && up.repeat === false &&
    Number.isFinite(downMs) && Number.isFinite(upMs) && upMs - downMs >= 14900 && upMs - downMs <= 18000;
  const beforeControl = controls.filter(c => c?.atMs < downMs).at(-1);
  const changes = controls.filter(c => c?.atMs >= downMs && c.atMs <= endMs);
  const controlOK = ordered(controls) && neutral(beforeControl) && changes.length === 2 && drive(changes[0]) && neutral(changes[1]) &&
    changes[0].atMs >= downMs && changes[0].atMs <= downMs + 500 && changes[0].atMs < upMs &&
    changes[1].atMs >= upMs && changes[1].atMs <= upMs + 500;
  const firstDrive = sent.findIndex(s => drive(s?.input));
  const release = sent.findIndex((s, i) => i > firstDrive && s.atMs >= upMs && neutral(s.input));
  const held = firstDrive >= 0 && release > firstDrive ? sent.slice(firstDrive, release) : [];
  const sentOK = ordered(sent) && sent.length > 20 && firstDrive >= 0 && release > firstDrive &&
    sent[firstDrive].atMs >= downMs && sent[firstDrive].atMs <= downMs + 500 &&
    sent[release].atMs >= upMs && sent[release].atMs <= upMs + 500 &&
    held.every(s => drive(s.input)) && held.at(-1)?.atMs >= upMs - 500 &&
    sent.slice(0, firstDrive).every(s => neutral(s.input)) && sent.slice(release).every(s => neutral(s.input)) &&
    sent.every((s, i) => Number.isSafeInteger(s.seq) && (!i || s.seq > sent[i - 1].seq)) &&
    held.every((s, i) => !i || s.atMs - held[i - 1].atMs <= 500);
  const beforeFrame = list(trace?.frames).filter(f => Number.isFinite(f?.atMs) && f.atMs <= downMs).at(-1);
  const firstMotion = frames.find(f => f.atMs > downMs && f.atMs < upMs && distance(beforeFrame?.visual, f.visual) > .05 && distance(beforeFrame?.body, f.body) > .05);
  const frameIntervals = frames.slice(1).map((f, i) => f.atMs - frames[i].atMs);
  const stateIntervals = states.slice(1).map((s, i) => s.atMs - states[i].atMs);
  const lastSnapshotAgeMs = states.length ? endMs - states.at(-1).atMs : null;
  const rev = ticks[0]?.poseRevision;
  const steadySimulationSeconds = longestSteadySimulationSeconds(ticks);
  const tickOK = authority?.format === 'substep-v1' && authority.collisionCoverage === 'grounded-path-v1' &&
    authority.complete === true && authority.failed === 0 && authority.dropped === 0 && Number.isSafeInteger(rev) && ticks.length > 20 &&
    ticks.every((t, i) => Number.isSafeInteger(t?.tick) && (!i || t.tick === ticks[i - 1]?.tick + 1) && t.poseRevision === rev &&
      ['vx','vy','vz','yaw','simTime'].every(k => Number.isFinite(t[k])) && (!i || Math.abs(t.simTime - ticks[i - 1].simTime - .05) <= 1e-6) &&
      t.supportId === 'ground' && Array.isArray(t.contactReasons) && t.contactReasons.length === 0 && route(t) && route(t.start) && t.start.supportId === 'ground' &&
      Array.isArray(t.substeps) && t.substeps.length > 0 && t.substeps.length <= 8 && t.substeps.every(p => route(p) && p.supportId === 'ground'));
  const stateTicksCovered = states.length > 0 && states.every(s => Number.isSafeInteger(s.tick) && s.poseRevision === rev &&
    s.tick >= ticks[0]?.tick && s.tick <= ticks.at(-1)?.tick && s.otherEntities === 0 && route(s.car) && s.car.supportId === 'ground');
  const frameRoute = frames.every(f => route(f.visual) && route(f.body) && f.body.supportId === 'ground' && f.menu === false);
  const turnarounds = list(trace?.turnarounds).filter(t => Number.isFinite(t.receivedAtMs) && t.receivedAtMs >= startMs && t.receivedAtMs <= endMs && Number.isFinite(t.elapsedMs) && t.elapsedMs > 0);
  fail('invalid-window', windowOK);
  fail('missing-trusted-held-w', keyOK && ordered(events) && !events.some(e => e.type === 'inputRejected'));
  fail('incomplete-controls', controlOK);
  fail('incomplete-sent-inputs', sentOK);
  fail('incomplete-window-frames', frames.length >= 30 && ordered(frames) && frames[0]?.atMs - startMs <= 500 && endMs - frames.at(-1)?.atMs <= 500 && frameIntervals.every(dt => dt > 0 && dt <= 1000));
  fail('incomplete-window-snapshots', states.length >= 5 && ordered(states) && states[0]?.atMs - startMs <= 500 && lastSnapshotAgeMs >= 0 && lastSnapshotAgeMs <= 500 && stateIntervals.every(dt => dt > 0 && dt <= 1000));
  fail('missing-first-motion', !!beforeFrame && downMs - beforeFrame.atMs <= 500 && !!firstMotion && distance(frames[0]?.visual, frames.at(-1)?.visual) > 100 && distance(states[0]?.car, states.at(-1)?.car) > 100 && distance(ticks[0], ticks.at(-1)) > 100);
  fail('incomplete-ground-authority-or-contact', tickOK);
  fail('missing-steady-simulation-interval', steadySimulationSeconds >= 2);
  fail('out-of-route-or-state-tick-range', frameRoute && stateTicksCovered);
  fail('missing-turnaround', turnarounds.length > 0);
  fail('incomplete-browser-trace', trace?.errors === 0 && ['frames','states','sent','controls','events','marks','turnarounds'].every(k => trace?.dropped?.[k] === 0) && Object.values(trace?.dropped ?? {}).every(n => n === 0));
  fail('relay-or-page-error', profile === 'zero' && routed?.profile === 'zero' && connections === 1 && pageErrors === 0 && consoleErrors === 0 && networkErrors === 0 && pending === 0 && routed?.overflow === false && routed?.sendsFailed === 0 && routed?.droppedEvents === 0);
  fail('connection-or-target-changed', connectionAtEnd?.includes('LIVE') === true && cleanAfter === true);
  return { complete: invalid.length === 0, invalid, startMs, endMs, frames: frames.length, states: states.length,
    heldMs: keyOK ? upMs - downMs : null, firstMotionFrameMs: firstMotion?.atMs ?? null,
    keyToFirstMotionObservedMs: firstMotion ? firstMotion.atMs - downMs : null,
    firstMotionNote: 'Observed first qualifying submitted frame only; not a proven input-response or display-latency bound.',
    maxFrameGapMs: frameIntervals.length ? Math.max(...frameIntervals) : null, lastSnapshotAgeMs, steadySimulationSeconds,
    diagnosticOnly: true, gateEligible: false };
}
