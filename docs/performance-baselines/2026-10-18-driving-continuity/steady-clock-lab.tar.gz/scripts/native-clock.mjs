// Parse a local-only native probe. Raw Mach ticks are deliberately retained as
// BigInt until they are scaled; ambiguous mappings are never guessed.
import { readFile, readdir } from 'node:fs/promises';
const MAGIC = 0x5445534c4d414348n, HEADER = 64, RECORD = 48;
export function parseNativeClock(buffer) {
  const fail = reason => ({ valid: false, reason });
  if (!Buffer.isBuffer(buffer) || buffer.length < HEADER) return fail('missing-native-header');
  const u = at => buffer.readBigUInt64LE(at), i = at => buffer.readBigInt64LE(at);
  const [magic,version,pid,numer,denom,capacity,count,dropped] = [0,8,16,24,32,40,48,56].map(u);
  if(magic!==MAGIC || version!==1n || !pid || !numer || !denom || !capacity || capacity>1000000n ||
     count>capacity || dropped!==0n || buffer.length!==HEADER+Number(capacity)*RECORD) return fail('invalid-or-overflowed-native-log');
  const events=[];
  for(let index=0;index<Number(count);index++) {
    const at=HEADER+index*RECORD;
    const before=u(at),after=u(at+8),sec=i(at+16),nsec=i(at+24),thread=u(at+32),committed=u(at+40);
    if(committed!==1n || !thread || before>after || sec<0n || nsec<0n || nsec>=1000000000n) return fail('incomplete-native-record');
    const ms=sec*1000n+nsec/1000000n;
    if(ms>BigInt(Number.MAX_SAFE_INTEGER)) return fail('invalid-epoch');
    events.push({index,before,after,ms:Number(ms),thread});
  }
  return {valid:true,pid:Number(pid),numer,denom,events};
}
// JS markers occur synchronously around the whole tick in the SAME thread.
// A match is usable only if there is exactly one ordered pair over all threads;
// none of its native records may also be assigned to another observation.
export function matchAuthorityMarks(native, ticks) {
  if(!native?.valid || !Array.isArray(ticks) || !ticks.length) return {valid:false,reason:'missing-authority-marks',matches:[]};
  const byMs=new Map();
  for(const event of native.events){const list=byMs.get(event.ms)||[];list.push(event);byMs.set(event.ms,list);}
  const used=new Set(), matches=[];
  for(const tick of ticks) {
    const a=tick?.nativeBeforeMs,b=tick?.nativeAfterMs;
    if(!Number.isSafeInteger(tick?.tick)||!Number.isSafeInteger(a)||!Number.isSafeInteger(b)) return {valid:false,reason:'invalid-authority-mark',matches};
    const pairs=[];
    for(const x of byMs.get(a)||[]) for(const y of byMs.get(b)||[]) {
      if(x.index!==y.index && x.thread===y.thread && x.after<=y.before) pairs.push([x,y]);
      if(pairs.length>1) return {valid:false,reason:'ambiguous-authority-mark',matches,tick:tick.tick};
    }
    if(pairs.length!==1) return {valid:false,reason:pairs.length?'ambiguous-authority-mark':'missing-native-authority-mark',matches,tick:tick.tick};
    const [x,y]=pairs[0];
    if(used.has(x.index)||used.has(y.index)) return {valid:false,reason:'reused-native-record',matches};
    used.add(x.index);used.add(y.index);
    const min=x.before*native.numer/native.denom;
    // Round the upper bound up, to avoid truncating a possible later instant.
    const max=(y.after*native.numer+native.denom-1n)/native.denom;
    if(max<min) return {valid:false,reason:'invalid-native-bracket',matches};
    if(matches.length && min<BigInt(matches.at(-1).maxNs)) return {valid:false,reason:'overlapping-or-out-of-order-native-ticks',matches};
    matches.push({tick:tick.tick,minNs:min.toString(),maxNs:max.toString(),beforeRecord:x.index,afterRecord:y.index});
  }
  return {valid:true,matches};
}
// Diagnostic hull over every same-process, same-thread, ordered candidate.
// The hull is conditional on an independently unproven source-to-native clock
// correspondence; neither numerical proximity nor this function proves it.
export function boundAuthorityMarks(natives, ticks) {
  const fail = (reason, matches = [], tick) => ({ valid: false, reason, matches, tick,
    sourceToNativeClockProven: false, clockMappingProven: false });
  if (!Array.isArray(natives) || !natives.length || !natives.every(n => n?.valid) ||
      new Set(natives.map(n => n.pid)).size !== natives.length || !Array.isArray(ticks) || !ticks.length)
    return fail('invalid-native-logs-or-marks');
  const indexed = natives.map(n => {
    const byMs = new Map();
    for (const event of n.events) { const list = byMs.get(event.ms) || []; list.push(event); byMs.set(event.ms, list); }
    return { ...n, byMs };
  });
  const matches = [];
  for (const tick of ticks) {
    const a = tick?.nativeBeforeMs, b = tick?.nativeAfterMs;
    if (!Number.isSafeInteger(tick?.tick) || !Number.isSafeInteger(a) || !Number.isSafeInteger(b) ||
        (matches.length && tick.tick !== matches.at(-1).tick + 1)) return fail('invalid-or-skipped-authority-mark', matches, tick?.tick);
    let min = null, max = null, pairs = 0, examined = 0; const processes = new Set();
    for (const n of indexed) for (const x of n.byMs.get(a) || []) for (const y of n.byMs.get(b) || []) {
      if (++examined > 1000000) return fail('excess-native-candidates', matches, tick.tick);
      if (x.index === y.index || x.thread !== y.thread || x.after > y.before) continue;
      ++pairs;
      const lo = x.before * n.numer / n.denom;
      const hi = (y.after * n.numer + n.denom - 1n) / n.denom;
      if (hi < lo) return fail('invalid-native-bracket', matches, tick.tick);
      if (min === null || lo < min) min = lo;
      if (max === null || hi > max) max = hi;
      processes.add(n.pid);
    }
    if (!pairs) return fail('missing-native-authority-mark', matches, tick.tick);
    if (matches.length && min <= BigInt(matches.at(-1).maxNs)) return fail('overlapping-or-out-of-order-native-ticks', matches, tick.tick);
    matches.push({ tick: tick.tick, minNs: min.toString(), maxNs: max.toString(), candidatePairs: pairs, processes: [...processes].sort((x, y) => x - y) });
  }
  return { valid: true, matches, sourceToNativeClockProven: false, clockMappingProven: false };
}
// Each currently live mmap must have two identical complete snapshots and the
// process inventory must remain stable. Retain bytes even on diagnostic failure.
export async function readStableNativeLogs(dir, io = { readFile, readdir }) {
  const names = (await io.readdir(dir)).filter(n => /^clock-\d+\.bin$/.test(n)).sort();
  const diagnostics = [];
  if (!names.length || names.length > 8) return { valid: false, reason: 'missing-or-excess-native-logs', names, diagnostics };
  for (const name of names) {
    let bytes, stable = false;
    for (let attempt = 0; attempt < 3 && !stable; attempt++) {
      const first = await io.readFile(`${dir}/${name}`), second = await io.readFile(`${dir}/${name}`);
      bytes = second; stable = first.equals(second);
    }
    diagnostics.push({ name, bytes, stable });
  }
  const after = (await io.readdir(dir)).filter(n => /^clock-\d+\.bin$/.test(n)).sort();
  if (names.join('\n') !== after.join('\n')) return { valid: false, reason: 'native-log-inventory-changed', names, diagnostics };
  if (diagnostics.some(d => !d.stable)) return { valid: false, reason: 'unstable-native-log-snapshot', names, diagnostics };
  const logs = diagnostics.map(d => parseNativeClock(d.bytes));
  if (logs.some((n, i) => !n.valid || String(n.pid) !== names[i].slice(6, -4))) return { valid: false, reason: 'invalid-native-log-or-pid', names, diagnostics };
  return { valid: true, names, diagnostics, logs };
}
// Chromium trace events are decoded but clock equivalence and source build
// attestation remain separately required; mere numerical proximity proves none.
export function matchBrowserMarkers(events, frames) {
  if(!Array.isArray(events)||!Array.isArray(frames)||!frames.length) return {valid:false,reason:'missing-browser-markers'};
  const map=new Map();
  for(const e of events){
    const message=e?.args?.data?.message;
    if(e?.name!=='TimeStamp'||typeof message!=='string'||!/^tesland-frame-(start|end):\d+$/.test(message)) continue;
    const list=map.get(message)||[];list.push(e);map.set(message,list);
  }
  const matches=[];
  for(let id=0;id<frames.length;id++){
    const a=map.get(`tesland-frame-start:${id}`),b=map.get(`tesland-frame-end:${id}`);
    if(a?.length!==1||b?.length!==1||!Number.isFinite(a[0]?.ts)||!Number.isFinite(b[0]?.ts)||
       !Number.isSafeInteger(a[0]?.pid)||!Number.isSafeInteger(a[0]?.tid)||a[0].ts>b[0].ts||a[0].pid!==b[0].pid||a[0].tid!==b[0].tid)
      return {valid:false,reason:'missing-duplicate-or-invalid-browser-marker',id};
    if(id && (a[0].pid!==matches[0].pid || a[0].tid!==matches[0].tid || a[0].ts<matches[id-1].maxUs))
      return {valid:false,reason:'browser-marker-thread-or-order-changed',id};
    matches.push({id,minUs:Math.floor(a[0].ts)-1,maxUs:Math.ceil(b[0].ts)+1,pid:a[0].pid,tid:a[0].tid});
  }
  return {valid:true,matches,clockMappingProven:false};
}
