# Local driving-clock diagnostic: provenance and remaining blockers

This lab does not establish a performance-gate pass. The straight, grounded, W-only collector has focused tests but has not yet been run in a coordinated quiet window. It exercises a reduced-ambient local Wrangler room, zero added delay and desktop keyboard input; it does not cover touch, other controls or the full release gate.

## What is supported by pinned source

- The checkout locks workerd `1.20261012.1` and Playwright `1.64.1` with Chromium `156.0.8078.4`. In the corresponding workerd source, [`performance.now()` calls `dateNow()`](https://github.com/cloudflare/workerd/blob/v1.20261012.1/src/workerd/api/performance.c%2B%2B), which [reads the current I/O context](https://github.com/cloudflare/workerd/blob/v1.20261012.1/src/workerd/io/io-util.c%2B%2B); the [local WorkerService timer calls the precise calendar clock](https://github.com/cloudflare/workerd/blob/v1.20261012.1/src/workerd/server/server.c%2B%2B). The [pinned Cap’n Proto implementation](https://github.com/capnproto/capnproto/blob/e866bdbaa3078a4bda9e4287d2d4a773c0986902/c%2B%2B/src/kj/time.c%2B%2B) uses `clock_gettime(CLOCK_REALTIME)` for that clock on this OS. The alternative [`precise_timers` branch rounds to 3 ms](https://github.com/cloudflare/workerd/blob/v1.20261012.1/src/workerd/io/io-context.c%2B%2B) and must not be confused with the local default. Production Workers may freeze their clocks during CPU execution; this is local evidence only.
- In [Chromium 156’s Apple clock source](https://chromium.googlesource.com/codesearch/chromium/src/+/refs/tags/156.0.8078.4/base/time/time_apple.mm), high-resolution `TimeTicks` uses `mach_absolute_time` converted to integer microseconds. The [timestamp payload source](https://chromium.googlesource.com/codesearch/chromium/src/+/refs/tags/156.0.8078.4/third_party/blink/renderer/core/inspector/inspector_trace_events.cc) also maps explicitly supplied `performance.now()` values through its internal time origin. These facts alone do not establish the clock of the exported JSON `TimeStamp.ts` field.

## What remains unproven

1. Attest the exact effective workerd configuration, loaded binary hash/source identity, and that each authority `performance.now()` marker is backed by a successfully recorded interposed native read. Preserve all process logs; reject dropped, incomplete, changing or ambiguously incomplete inventories. The all-candidate hull in this lab is deliberately **conditional** on this provenance.
2. Establish that the actual Chromium build’s DevTools event emission and JSON export preserve an unshifted Mach `TimeTicks` origin and quantify rounding; also bound frame, event and input-control observation times. Each browser frame is currently surrounded by trace markers, but control changes are not. A numerical match or a before/after average does not prove a per-event error bound. Detect sleep/wake or clock discontinuities and fail closed.
3. Define and justify a common-clock substep interpolation convention. The simulation advances discretely; the lab’s piecewise-linear reference is an explicit numerical model, not a directly observed continuous physical path. Every qualifying sample must have valid endpoint bounds, audited ground/contact coverage and a fully observed control history; broad or overlapping bounds remain unavailable. A long plateau does not establish wall-time cadence.
4. Measure observer effects with repeated randomized, matched instrumented and uninstrumented runs, identical source, renderer, inputs, occupancy, scene and network profile, with host contention documented and a noninferiority margin fixed in advance. Report confidence intervals and run-to-run variation. A single pair cannot establish negligible overhead, and even many runs do not give a deterministic zero-overhead guarantee.

The old busy-host native capture had conditional candidate-hull p95 width **0.751 ms**, maximum **5.647 ms**; mapping, origin and overhead were unproven, so these are sensitivity-study numbers only. The tick hull and all-candidate choices do not by themselves prove any usable reference ratio. The analyzer and capture metadata retain `gateEligible: false`.

## Commands

After the target revision is committed and a quiet window has been coordinated (the collector requires a clean target checkout, macOS arm64 and no inherited `DYLD_INSERT_LIBRARIES`):

```sh
node /private/tmp/tesland-gate-lab-bUdLYT/scripts/driving-continuity-capture.mjs \
  --root /private/tmp/tesland-continuity-throughput \
  --out /private/tmp/tesland-continuity-evidence/steady-candidate-01 \
  --scenario steady --profile zero --gpu metal --unpolled --native-clock
```

The output directory must not already exist. The drive lasts approximately 16 seconds plus build/startup/teardown. Raw authority and browser traces, native files, network events, long tasks and metadata are retained. The exact shared/worker/stage source tuple must already be audited by the collector. The existing analyzer is polling-based and will correctly report `unavailable` for this unpolled native capture:

```sh
node /private/tmp/tesland-gate-lab-bUdLYT/substep-continuity-gate.mjs \
  /private/tmp/tesland-continuity-evidence/steady-candidate-01/capture.json
```

Focused, non-browser checks:

```sh
cd /private/tmp/tesland-gate-lab-bUdLYT
node --test steady-capture.test.mjs native-clock.test.mjs substep-continuity-gate.test.mjs worker-probe.test.mjs
```

The latest focused run passed 44/44 tests. No overhead comparison or tight same-clock bound has been established.
