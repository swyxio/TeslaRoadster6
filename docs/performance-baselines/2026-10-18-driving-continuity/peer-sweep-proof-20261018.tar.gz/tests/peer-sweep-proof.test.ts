import test from 'node:test';
import assert from 'node:assert/strict';
import { createEmptyWorld, makeEntity } from '../shared/game';
import { body, contact, dimensions } from '../shared/physics';
import { provePlanarPeerSweep } from '../src/peer-sweep-proof.lab';

const make=(id:string,x:number,z:number,yaw=0)=>Object.assign(makeEntity(id,'roadster',x,z),{yaw,supportId:'ground' as const});
const ferry=()=>createEmptyWorld().ferry;

test('head-on crossing with clear endpoints is unavailable',()=>{
  const a=make('a',-6,0,-Math.PI/2),b=make('b',6,0,-Math.PI/2),aa={...a,x:6},bb={...b,x:-6},f=ferry();
  assert.equal(contact(body(a),body(b)),null);assert.equal(contact(body(aa),body(bb)),null);
  assert.ok(contact(body({...a,x:0}),body({...b,x:0})));
  assert.equal(provePlanarPeerSweep(a,aa,b,bb,f,f).kind,'unavailable');
});

test('exact axis-aligned tangent pairs can remain co-moving or withdraw',()=>{
  const a=make('a',0,0),width=dimensions(a.kind).width,b=make('b',width,0),f=ferry();
  const aa={...a,z:4},bb={...b,z:4};
  assert.equal(contact(body(a),body(b)),null);
  const proof=provePlanarPeerSweep(a,aa,b,bb,f,f);
  assert.equal(proof.kind,'tangent');
  for(let i=0;i<=64;i++){
    const z=4*i/64;
    // Shared relative frame preserves zero clearance; independently rounded
    // renderer coordinates require their own numerical proof.
    assert.equal(contact(body({...a,z}),body({...b,z})),null);
  }
  assert.equal(provePlanarPeerSweep(a,a,b,{...b,x:width+.5},f,f).kind,'tangent');
  assert.equal(provePlanarPeerSweep(a,a,b,{...b,x:width-.5},f,f).kind,'unavailable');
  const barelyInside={...b,x:width-Number.EPSILON};
  assert.equal(provePlanarPeerSweep(a,a,barelyInside,barelyInside,f,f).kind,'unavailable');
  assert.equal(provePlanarPeerSweep(a,{...a,yaw:1e-8},b,b,f,f).kind,'unavailable');
});

test('fixed-yaw affine separation handles close non-tangent relative motion',()=>{
  const a=make('a',0,0),b=make('b',4,0),aa={...a,z:8},bb={...b,z:-6},f=ferry();
  assert.equal(provePlanarPeerSweep(a,aa,b,bb,f,f).kind,'clear');
});

test('rotation can create an intermediate collision between clear endpoints',()=>{
  const a=make('a',0,0),size=dimensions(a.kind);
  const maximum=Math.hypot(size.width/2,size.length/2)+size.width/2;
  const endExtent=size.length/2+size.width/2;
  const b=make('b',(maximum+endExtent)/2,0),aa={...a,yaw:Math.PI/2},f=ferry();
  const mid={...a,yaw:Math.atan2(size.length,size.width)};
  assert.equal(contact(body(a),body(b)),null);assert.equal(contact(body(aa),body(b)),null);
  assert.ok(contact(body(mid),body(b)));
  assert.equal(provePlanarPeerSweep(a,aa,b,b,f,f).kind,'unavailable');
});

test('dome, ferry transitions, support changes and invalid inputs are unavailable',()=>{
  const a=make('a',0,0),b=make('b',20,0),f=ferry();
  assert.equal(provePlanarPeerSweep({...a,inDome:true},a,b,b,f,f).kind,'unavailable');
  const departing={...f,phase:'to-island' as const};
  assert.equal(provePlanarPeerSweep(a,a,b,b,f,departing).kind,'unavailable');
  const boarded={...f,passengers:[{entityId:a.id,x:0,z:0}]};
  assert.equal(provePlanarPeerSweep(a,a,b,b,f,boarded).kind,'unavailable');
  assert.equal(provePlanarPeerSweep(a,{...a,supportId:null},b,b,f,f).kind,'unavailable');
  assert.equal(provePlanarPeerSweep(a,{...a,x:NaN},b,b,f,f).kind,'unavailable');
});

test('accepted rotating sweeps have no contact in independently sampled poses',()=>{
  let seed=0x56b6104,accepted=0,adaptive=0;const f=ferry();
  const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
  for(let n=0;n<350;n++){
    const a=make('a',(random()-.5)*12,(random()-.5)*12,(random()-.5)*Math.PI*2);
    const b=make('b',(random()-.5)*12,(random()-.5)*12,(random()-.5)*Math.PI*2);
    const aa={...a,x:a.x+(random()-.5)*4,z:a.z+(random()-.5)*4,yaw:a.yaw+(random()-.5)};
    const bb={...b,x:b.x+(random()-.5)*4,z:b.z+(random()-.5)*4,yaw:b.yaw+(random()-.5)};
    const proof=provePlanarPeerSweep(a,aa,b,bb,f,f);if(proof.kind!=='clear')continue;
    accepted++;adaptive+=proof.reason.startsWith('adaptive')?1:0;
    for(let i=0;i<=64;i++){
      const t=i/64,angle=(x:number,y:number)=>x+Math.atan2(Math.sin(y-x),Math.cos(y-x))*t;
      const pa={...a,x:a.x+(aa.x-a.x)*t,z:a.z+(aa.z-a.z)*t,yaw:angle(a.yaw,aa.yaw)};
      const pb={...b,x:b.x+(bb.x-b.x)*t,z:b.z+(bb.z-b.z)*t,yaw:angle(b.yaw,bb.yaw)};
      assert.equal(contact(body(pa),body(pb)),null,`case ${n} sample ${i} ${JSON.stringify(proof)}`);
    }
  }
  console.log('PEER_SWEEP_SAMPLE',JSON.stringify({cases:350,accepted,adaptive,samplesPerCase:65}));
  assert.ok(accepted>50,`accepted ${accepted}`);assert.ok(adaptive>50,`adaptive ${adaptive}`);
});
