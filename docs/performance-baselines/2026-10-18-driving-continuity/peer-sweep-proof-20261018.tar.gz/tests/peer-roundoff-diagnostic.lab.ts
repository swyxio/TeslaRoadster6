import {makeEntity,createEmptyWorld} from '../shared/game';
import {body,contact,dimensions} from '../shared/physics';
import {provePlanarPeerSweep} from '../src/peer-sweep-proof.lab';
const a=makeEntity('a','roadster',0,0),w=dimensions(a.kind).width,b=makeEntity('b','roadster',w,0),f=createEmptyWorld().ferry;
for(let i=1;i<500;i++){
 const delta=i/128,aa={...a,x:a.x+delta},bb={...b,x:b.x+delta};
 const proof=provePlanarPeerSweep(a,aa,b,bb,f,f);
 if(proof.kind!=='tangent')continue;
 for(let j=1;j<256;j++){
  const t=j/256,pa={...a,x:a.x+(aa.x-a.x)*t},pb={...b,x:b.x+(bb.x-b.x)*t};
  const hit=contact(body(pa),body(pb));if(hit){console.log(JSON.stringify({delta,t,width:w,pa:pa.x,pb:pb.x,depth:hit.depth,proof}));process.exit(0);}
 }
}
console.log('no numerical counterexample in this diagnostic search');
