# Standalone planar peer-sweep research, 2026-10-18

STATUS: LAB ONLY. Not integrated into playback, not production ready, and not a driving-continuity or performance gate result.

The code takes two entities' start/end poses and ferry state and tests straight x/z interpolation with shortest-path yaw interpolation. It ignores vertical separation and is therefore conservatively planar; it rejects dome input, ferry phase or passenger-membership changes, identity/support changes, unsupported numeric inputs, and unresolved intervals. An unavailable result does not claim a collision. It does not solve for a joint pose, preserve input responsiveness, detect unknown future peer commands, test renderer output, or handle 3-D dome geometry, ferry transitions, non-linear paths or protocol lineage.

For separated intervals, a midpoint rectangle is expanded by half-interval bounds on relative translation and each rectangle's circumradius times angular change. A separating axis for the two expanded shapes proves separation in the real-number motion model. Uncertain intervals subdivide through depth 12 and then fail closed. An additional fixed-yaw signed-axis proof uses endpoint gaps. Axis-aligned zero-clearance endpoints use exact dyadic comparisons over input doubles and return `tangent` separately; this is an exact-real trajectory result, NOT a machine-precision renderer guarantee. A renderer must keep a shared relative frame or establish an independent floating-point bound. The 1e-8 padding is an engineering margin; it is not a formal JavaScript Math.sin/Math.cos roundoff proof. BigInt allocation and worst-case subdivision costs are unmeasured.

Run from the lab with its existing dependencies:

```
./node_modules/.bin/tsx --test tests/peer-sweep-proof.test.ts
./node_modules/.bin/tsc --noEmit
```

Six focused tests pass. A deterministic randomized test accepts 237 of 350 moving/rotating scenarios and verifies 65 sampled poses per accepted scenario; sampling is validation, not the interval proof. Clear-endpoint crossing, an intermediate rotational collision, actual tiny penetration, unresolved tiny rotation, dome inputs, ferry changes, support changes, and NaN fail closed. Exact axis-aligned co-moving/withdrawing contact returns `tangent`, not `clear`.

This lab is separate from `/private/tmp/tesland-presentation-contact-followup-20261018` and the combined lab; neither was changed by this work. The active follow-up playback patch separately retains the original wall-margin test conflict and cannot be released.
