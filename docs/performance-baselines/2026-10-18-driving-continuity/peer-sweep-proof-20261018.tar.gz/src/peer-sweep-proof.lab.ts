import type { Entity } from '../shared/game';
import type { Ferry } from '../shared/ferry';
import { body, contact, dimensions } from '../shared/physics';

// Standalone lab only. It describes straight-line x/z and shortest-yaw paths,
// not projected ground paths, renderer frames, unknown inputs, or a joint solver.
// "tangent" is an exact-real, axis-aligned proof: a renderer must maintain a
// shared relative frame or separately bound floating-point roundoff at contact.
type Result = {kind:'clear'|'tangent'|'unavailable'; reason:string; intervals:number};
const margin=1e-8;
const maxCoordinate=1e6;
const shortest=(a:number,b:number)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
const axes=(yaw:number)=>[[Math.cos(yaw),-Math.sin(yaw)],[-Math.sin(yaw),-Math.cos(yaw)]];

// A double is an exact dyadic rational. Compare 2*(positive-negative)-sizeA-sizeB
// without losing the sign at zero through floating-point cancellation.
function dyadic(n:number):{mantissa:bigint;exponent:number} {
  const view=new DataView(new ArrayBuffer(8));view.setFloat64(0,n,false);
  const bits=view.getBigUint64(0,false),negative=(bits>>63n)!==0n;
  const exponent=Number((bits>>52n)&0x7ffn),fraction=bits&((1n<<52n)-1n);
  const mantissa=(exponent===0?fraction:(1n<<52n)|fraction)*(negative?-1n:1n);
  return {mantissa,exponent:exponent===0?-1074:exponent-1023-52};
}
function exactAxisGap(positive:number,negative:number,sizeA:number,sizeB:number):number {
  const terms=[[positive,1],[-negative,1],[-sizeA,0],[-sizeB,0]] as const;
  const parts=terms.map(([n,power])=>{const v=dyadic(n);return {...v,exponent:v.exponent+power};});
  const min=Math.min(...parts.map(p=>p.exponent));
  const sum=parts.reduce((total,p)=>total+(p.mantissa<<BigInt(p.exponent-min)),0n);
  return sum===0n?0:sum>0n?1:-1;
}
function sameMembership(a:Ferry,b:Ferry):boolean {
  const ids=(f:Ferry)=>f.passengers.map(p=>p.entityId).sort();
  const before=ids(a),after=ids(b);
  return a.phase===b.phase&&before.length===after.length&&before.every((id,i)=>id===after[i]);
}

/** Purely geometrical, fail-closed planar interval proof; unavailable is not a collision claim. */
export function provePlanarPeerSweep(a0:Entity,a1:Entity,b0:Entity,b1:Entity,f0:Ferry,f1:Ferry):Result {
  const unavailable=(reason:string,intervals=0):Result=>({kind:'unavailable',reason,intervals});
  if(!sameMembership(f0,f1))return unavailable('ferry phase or passenger membership changed');
  if([a0,a1,b0,b1].some(e=>e.inDome||e.supportId==='dome'))return unavailable('dome geometry is unavailable');
  if(a0.id!==a1.id||b0.id!==b1.id||a0.id===b0.id||a0.kind!==a1.kind||b0.kind!==b1.kind||
    a0.supportId!==a1.supportId||b0.supportId!==b1.supportId)return unavailable('identity or support transition');
  if([a0,a1,b0,b1].some(e=>![e.x,e.z,e.yaw].every(Number.isFinite)||Math.abs(e.x)>maxCoordinate||Math.abs(e.z)>maxCoordinate))
    return unavailable('unsupported numeric input');
  const da=dimensions(a0.kind),db=dimensions(b0.kind);
  if(![da.width,da.length,db.width,db.length].every(n=>Number.isFinite(n)&&n>0&&n<1000))return unavailable('unsupported body dimensions');
  const fixed=a0.yaw===a1.yaw&&b0.yaw===b1.yaw;
  if(fixed&&a0.yaw===0&&b0.yaw===0){
    // For exact axis-aligned poses, signed separation is affine in time.
    // Exact dyadic comparisons cover true zero-clearance resting contact.
    for(const [axis,sizeA,sizeB] of [['x',da.width,db.width],['z',da.length,db.length]] as const){
      for(const reverse of [false,true]){
        const start=reverse?exactAxisGap(a0[axis],b0[axis],sizeA,sizeB):exactAxisGap(b0[axis],a0[axis],sizeA,sizeB);
        const end=reverse?exactAxisGap(a1[axis],b1[axis],sizeA,sizeB):exactAxisGap(b1[axis],a1[axis],sizeA,sizeB);
        if(start>=0&&end>=0&&(start===0||end===0))return {kind:'tangent',reason:'exact axis-aligned affine separation, including contact',intervals:1};
      }
    }
  }
  if(fixed){
    const aa=axes(a0.yaw),bb=axes(b0.yaw);
    for(const [x,z] of [...aa,...bb]){
      const radius=(dirs:number[][],w:number,d:number)=>(Math.abs(x*dirs[0][0]+z*dirs[0][1])*w+Math.abs(x*dirs[1][0]+z*dirs[1][1])*d)/2;
      const extent=radius(aa,da.width,da.length)+radius(bb,db.width,db.length);
      const start=(b0.x-a0.x)*x+(b0.z-a0.z)*z,end=(b1.x-a1.x)*x+(b1.z-a1.z)*z;
      if(start>extent+margin&&end>extent+margin||start< -extent-margin&&end< -extent-margin)
        return {kind:'clear',reason:'fixed-yaw affine separating axis',intervals:1};
    }
  }
  const yawA=shortest(a0.yaw,a1.yaw),yawB=shortest(b0.yaw,b1.yaw);
  const relativeDistance=Math.hypot((a1.x-a0.x)-(b1.x-b0.x),(a1.z-a0.z)-(b1.z-b0.z));
  const radiusA=Math.hypot(da.width,da.length)/2,radiusB=Math.hypot(db.width,db.length)/2;
  let intervals=0;
  const prove=(start:number,end:number,depth:number):boolean=>{
    intervals++;const mid=(start+end)/2,span=(end-start)/2;
    // Work in B's relative frame; a shared translation cancels exactly in the
    // real-number motion model. Each rotating rectangle is enlarged by its
    // maximum vertex displacement over this interval.
    const a={x:(a0.x-b0.x)+((a1.x-b1.x)-(a0.x-b0.x))*mid,
      z:(a0.z-b0.z)+((a1.z-b1.z)-(a0.z-b0.z))*mid,yaw:a0.yaw+yawA*mid,
      w:da.width+2*(span*(relativeDistance+radiusA*Math.abs(yawA))+margin),
      d:da.length+2*(span*(relativeDistance+radiusA*Math.abs(yawA))+margin)};
    const b={x:0,z:0,yaw:b0.yaw+yawB*mid,
      w:db.width+2*(span*radiusB*Math.abs(yawB)+margin),
      d:db.length+2*(span*radiusB*Math.abs(yawB)+margin)};
    if(!contact(a,b))return true;
    return depth<12&&prove(start,mid,depth+1)&&prove(mid,end,depth+1);
  };
  return prove(0,1,0)?{kind:'clear',reason:'adaptive relative-motion enclosing SAT',intervals}:
    unavailable('no separated envelope proved; joint resolution required',intervals);
}
