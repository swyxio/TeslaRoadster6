import test from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { addPlayer,createEmptyWorld,NEUTRAL,PROTOCOL_VERSION,step,type Input } from '../shared/game';
import { body,contact,verticalBounds } from '../shared/physics';
import { ScheduledInput,type InputCommand } from '../shared/tick-input';
import { BUILDINGS } from '../shared/map';
import { Session } from '../src/session';
import { MotionClock } from '../src/motion-clock';
import {NonceLease} from './nonce-lease.lab';
class Socket {static OPEN=1;static last:Socket;readyState=1;sent:string[]=[];onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}send(value:string){this.sent.push(value);}close(){this.readyState=3;}message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});

test('scheduled jump at a peer pinned near a wall stays responsive across FIFO bursts',()=>{
  let now=0,tick=0,read=0,lastDown=0,impact=false,pressedAt:number|undefined,shownJump:number|undefined,shownSteer:number|undefined;
  const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');addPlayer(world,'q','Other');
  const local=world.entities.find(e=>e.driver==='p')!,peer=world.entities.find(e=>e.driver==='q')!;world.entities=[local,peer];world.pickups=[];
  Object.assign(local,{x:-400,z:-30,y:0,yaw:-Math.PI/2,speed:0,vx:0,vz:0,supportId:'ground'});
  Object.assign(peer,{x:-354,z:-30,y:0,yaw:-Math.PI/2,speed:0,vx:0,vz:0,supportId:'ground'});
  const wall=BUILDINGS.find(b=>b.x===-340&&b.z===-30)!;assert.ok(wall);
  const lease=new NonceLease(true);let lastNonce:string|null=null,jumpNonce:string|null=null;
  const scheduler=new ScheduledInput(NEUTRAL),up:{at:number;command:InputCommand;level:string|null;jump:string|null}[]=[],down:{at:number;message:unknown}[]=[],records:unknown[]=[],receipts:unknown[]=[],edges:unknown[]=[],snaps:number[]=[];
  const state=()=>({type:'state',freshnessNonce:lease.issue(now),world:structuredClone(world),roomEpoch:'room',tick,control:scheduler.snapshot(),poseRevision:0,substeps:5});
  const initial=state();lastNonce=initial.freshnessNonce;socket.message(initial);(Reflect.get(session,'clock') as MotionClock).observeTurnaround(350);
  const enqueue=(at:number,message:unknown)=>{lastDown=Math.max(lastDown,at);down.push({at:lastDown,message});};
  let input:Input={...NEUTRAL,throttle:1},maxDepth=0,maxAuthDepth=0,maxStep=0,prior:{x:number;y:number;z:number}|undefined,maxHeld=0,held=0,rejected=0,authWall=false;
  const depth=(a:typeof local,b:typeof peer)=>{const av=verticalBounds(a),bv=verticalBounds(b);return av.min>=bv.max||bv.min>=av.max?0:contact(body(a),body(b))?.depth??0;};
  try{
    for(let frame=0;frame<=720;frame++){
      now=frame*1000/120;
      for(const arrival of up.filter(x=>x.at<=now+1e-8)){
        const result=scheduler.receive(arrival.command,tick,now,{levelUntil:lease.until(arrival.level,now),jumpUntil:lease.until(arrival.jump,now),flipUntil:null});receipts.push({now,tick,command:arrival.command,result});
        if(result.rejection){if(now>=2000)rejected++;enqueue(now+80,{type:'inputRejected',seq:arrival.command.seq,targetTick:arrival.command.targetTick,reason:result.rejection});}
        for(const o of result.outcomes){edges.push({now,...o});enqueue(now+80,{type:'inputEdge',...o});}
      }
      for(let i=up.length-1;i>=0;i--)if(up[i].at<=now+1e-8)up.splice(i,1);
      while((tick+1)*50<=now+1e-8){
        tick++;const advanced=scheduler.advance(tick,now);
        for(const o of advanced.outcomes){edges.push({now,...o});enqueue(now+80,{type:'inputEdge',...o});}
        step(world,new Map([['p',advanced.input],['q',NEUTRAL]]),.05,{substeps:5});impact||=local.health<100;
        maxAuthDepth=Math.max(maxAuthDepth,depth(local,peer));authWall||=!!contact(body(local),{...wall,yaw:0})||!!contact(body(peer),{...wall,yaw:0});
        if(tick%2===0){const delay=tick*50<700?200:tick*50<1500?500:0;enqueue(tick*50+delay,state());}
      }
      while(down.length&&down[0].at<=now+1e-8){const message=down.shift()!.message as {type:string;freshnessNonce?:string|null};if(message.type==='state')lastNonce=message.freshnessNonce??null;socket.message(message);}
      if(impact&&now>=2700&&pressedAt===undefined){pressedAt=now;input={...input,steer:1,jump:1};jumpNonce=lastNonce;session.queueEdge('jump',1);}
      session.tick(1/120,input);
      for(;read<socket.sent.length;read++){const message=JSON.parse(socket.sent[read]);if(message.type==='input')up.push({at:now+80,command:message,level:lastNonce,jump:jumpNonce});}
      const shown=session.renderWorld(),p=shown.entities.find(e=>e.driver==='p')!,q=shown.entities.find(e=>e.driver==='q')!;
      if(pressedAt!==undefined){if(shownJump===undefined&&p.y>.001)shownJump=now;if(shownSteer===undefined&&Math.abs(p.steering)>.001)shownSteer=now;}
      maxDepth=Math.max(maxDepth,depth(p,q));if(prior)maxStep=Math.max(maxStep,Math.hypot(p.x-prior.x,p.y-prior.y,p.z-prior.z));prior=p;
      held=Reflect.get(Reflect.get(session,'prediction'),'presentationHeld')?held+1:0;maxHeld=Math.max(maxHeld,held);
      if(session.takePresentationSnap())snaps.push(now);
      records.push({frame,now,tick,authority:structuredClone(local),peer:structuredClone(peer),shownLocal:structuredClone(p),shownPeer:structuredClone(q),control:scheduler.snapshot(),input,held:held>0,status:session.status,exhausted:Reflect.get(session,'presentationHistoryExhausted')});
    }
  }finally{if(process.env.TRACE_PATH)writeFileSync(process.env.TRACE_PATH,JSON.stringify({records,receipts,edges,snaps,summary:{impact,pressedAt,shownJump,shownSteer,maxDepth,maxAuthDepth,maxStep,maxHeld,rejected,authWall}}));session.disconnect();}
  console.log('PINNED_SCHEDULED',JSON.stringify({impact,pressedAt,shownJump,shownSteer,maxDepth,maxAuthDepth,maxStep,maxHeld,rejected,authWall,snaps,edges}));
  assert.ok(impact,'authority registered impact');assert.equal(authWall,false,'authority clears the wall');assert.ok(maxAuthDepth<.05,`authority penetration ${maxAuthDepth}`);
  assert.ok(pressedAt!==undefined&&shownJump!==undefined&&shownJump-pressedAt<=1000/120+50,`jump response ${(shownJump??Infinity)-(pressedAt??0)} ms`);
  assert.ok(shownSteer!==undefined&&shownSteer-pressedAt!<=1000/120+50,`steer response ${(shownSteer??Infinity)-(pressedAt??0)} ms`);
  assert.equal(rejected,0);assert.ok(maxDepth<.05,`displayed penetration ${maxDepth}`);assert.ok(maxStep<1,`display step ${maxStep}`);assert.deepEqual(snaps,[]);
  assert.ok(maxHeld<=6,`complete display held ${maxHeld} frames`);
});
