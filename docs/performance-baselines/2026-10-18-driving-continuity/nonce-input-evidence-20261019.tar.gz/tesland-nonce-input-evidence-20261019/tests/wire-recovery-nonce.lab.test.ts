import test from 'node:test';
import assert from 'node:assert/strict';
import { addPlayer,createEmptyWorld,NEUTRAL,PROTOCOL_VERSION,type Input } from '../shared/game';
import { ScheduledInput,type InputCommand } from '../shared/tick-input';
import { Session } from '../src/session';
import { MotionClock } from '../src/motion-clock';
import {NonceLease} from './nonce-lease.lab';

class Socket {
  static OPEN=1;static last:Socket;readyState=1;sent:string[]=[];
  onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}
  send(value:string){this.sent.push(value);}close(){this.readyState=3;}
  message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});

for(const scenario of [
  {name:'nominal',tickMs:50,delay:60},
  {name:'250 ms delay',tickMs:50,delay:250},
  {name:'500 ms delay',tickMs:50,delay:500},
  {name:'slow room with 500 ms delay',tickMs:100,delay:500},
  {name:'1800 ms delayed FIFO blackout',tickMs:50,delay:1800},
]) test(`wire input recovery, ${scenario.name}`,()=>{
  let now=0,tick=0,read=0,lastDown=0,releaseSeq=0,releaseApplied:number|undefined;
  const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld();addPlayer(world,'p','Driver');world.pickups=[];
  const scheduler=new ScheduledInput(NEUTRAL),lease=new NonceLease(true);
  let lastNonce:string|null=null,jumpNonce:string|null=null,flipNonce:string|null=null;
  const state=()=>({type:'state',freshnessNonce:lease.issue(now),world:structuredClone(world),roomEpoch:'room',tick,control:scheduler.snapshot(),poseRevision:0,substeps:1});
  const initial=state();lastNonce=initial.freshnessNonce;socket.message(initial);(Reflect.get(session,'clock') as MotionClock).observeTurnaround(350);
  const up:{at:number;command:InputCommand;level:string|null;jump:string|null;flip:string|null}[]=[],down:{at:number;message:unknown}[]=[];
  const receipts:{now:number;reason:string}[]=[],outcomes:{kind:string;id:number;status:string}[]=[];
  const applied:{now:number;seq:number;throttle:number}[]=[];
  const enqueue=(at:number,message:unknown)=>{lastDown=Math.max(lastDown,at);down.push({at:lastDown,message});};
  let jumpQueued=false,flipQueued=false;
  try {
    for(let frame=0;frame<=720;frame++){
      now=frame*1000/120;
      for(const arrival of up.filter(x=>x.at<=now+1e-8)){
        const result=scheduler.receive(arrival.command,tick,now,{levelUntil:lease.until(arrival.level,now),jumpUntil:lease.until(arrival.jump,now),flipUntil:lease.until(arrival.flip,now)});
        if(result.rejection){receipts.push({now,reason:result.rejection});enqueue(now+80,{type:'inputRejected',seq:arrival.command.seq,targetTick:arrival.command.targetTick,reason:result.rejection});}
        for(const outcome of result.outcomes){outcomes.push(outcome);enqueue(now+80,{type:'inputEdge',...outcome});}
      }
      for(let i=up.length-1;i>=0;i--)if(up[i].at<=now+1e-8)up.splice(i,1);
      while((tick+1)*scenario.tickMs<=now+1e-8){
        tick++;const result=scheduler.advance(tick,now);const seq=scheduler.snapshot().appliedSeq;
        applied.push({now,seq,throttle:result.input.throttle});
        if(releaseSeq&&seq>=releaseSeq&&result.input.throttle===0&&releaseApplied===undefined)releaseApplied=now;
        for(const outcome of result.outcomes){outcomes.push(outcome);enqueue(now+80,{type:'inputEdge',...outcome});}
        if(tick%2===0){const delay=now<700?200:now<1500?scenario.delay:0;enqueue(now+delay,state());}
      }
      while(down.length&&down[0].at<=now+1e-8){const message=down.shift()!.message as {type:string;freshnessNonce?:string|null};if(message.type==='state')lastNonce=message.freshnessNonce??null;socket.message(message);}
      if(now>=2200&&!jumpQueued){jumpNonce=lastNonce;session.queueEdge('jump',1);jumpQueued=true;}
      if(now>=2400&&!flipQueued){flipNonce=lastNonce;session.queueEdge('flip',1);flipQueued=true;}
      const input:Input={...NEUTRAL,throttle:now<2100?1:0,jump:jumpQueued?1:0,flip:flipQueued?1:0};
      session.tick(1/120,input);
      for(;read<socket.sent.length;read++){
        const message=JSON.parse(socket.sent[read]);if(message.type!=='input')continue;
        if(now>=2100&&releaseSeq===0)releaseSeq=message.seq;
        up.push({at:now+80,command:message,level:lastNonce,jump:jumpNonce,flip:flipNonce});
      }
    }
    const afterRelease=applied.filter(x=>releaseApplied!==undefined&&x.now>=releaseApplied);
    const summary={scenario:scenario.name,rejections:receipts.reduce<Record<string,number>>((counts,item)=>({...counts,[item.reason]:(counts[item.reason]??0)+1}),{}),lastRejection:receipts.at(-1)?.now??null,releaseSeq,releaseApplied,outcomes};
    console.log('WIRE_RECOVERY',JSON.stringify(summary));
    assert.ok(releaseSeq>0&&releaseApplied!==undefined&&releaseApplied<=3000,'the release reaches authority after recovery');
    assert.ok(afterRelease.every(x=>x.throttle===0),'no earlier throttle is reinstated after the release applies');
    assert.equal(outcomes.filter(x=>x.kind==='jump'&&x.id===1&&x.status==='processed').length,1);
    assert.equal(outcomes.filter(x=>x.kind==='flip'&&x.id===1&&x.status==='processed').length,1);
    assert.equal(receipts.filter(x=>x.reason==='future').length,0,'targets stay within the future window');
  } finally {session.disconnect();}
});
