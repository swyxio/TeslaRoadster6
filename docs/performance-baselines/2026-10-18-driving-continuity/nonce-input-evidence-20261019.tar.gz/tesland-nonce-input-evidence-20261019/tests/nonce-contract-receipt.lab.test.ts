import test from 'node:test';
import assert from 'node:assert/strict';
import {NEUTRAL} from '../shared/game';
import {ScheduledInput,type InputCommand} from '../shared/tick-input';
import {NonceLease} from './nonce-lease.lab';

const cmd=(seq:number,targetTick:number,throttle=1,jump=0,actionSeq=0,controlRevision=0):InputCommand=>({seq,targetTick,controlRevision,actionSeq,input:{...NEUTRAL,throttle,jump}});
const proof=(until:number|null,jump=until,flip=until)=>({levelUntil:until,jumpUntil:jump,flipUntil:flip});

test('tokens are per-connection, bounded, opaque, reusable only inside the lease, and expire',()=>{
  const a=new NonceLease(true,2),b=new NonceLease(true,2),first=a.issue(0)!;
  assert.match(first,/^[0-9a-f]{32}$/);assert.equal(b.until(first,10),null);
  assert.equal(a.until(first,10),300);assert.equal(a.until(first,20),300);
  const second=a.issue(30)!,third=a.issue(40)!;
  assert.notEqual(first,second);assert.notEqual(second,third);
  assert.equal(a.until(first,40),null);assert.equal(a.until(second,330),330);assert.equal(a.until(second,331),null);
  const reconnect=new NonceLease(true,2);assert.equal(reconnect.until(third,50),null);
});

test('unverified clock, rollback, expiry and observed discontinuities fail closed',()=>{
  assert.equal(new NonceLease(false).issue(0),null);
  const clock=new NonceLease(true),nonce=clock.issue(100)!;
  assert.equal(clock.until(nonce,200),400);assert.equal(clock.until(nonce,199),null);assert.equal(clock.issue(201),null);
  const forward=new NonceLease(true),n=forward.issue(100)!;assert.equal(forward.until(n,10000),null);
});

test('a stopped or unobservably slow host clock makes freshness undecidable',()=>{
  // The same server timestamps and token represent either a 20 ms packet or
  // a stale 2 s packet: no protocol using only those observations can tell.
  const a=new NonceLease(true),n=a.issue(100)!;
  assert.equal(a.until(n,120),400);const observedElapsed=120-100;
  assert.equal(observedElapsed,20);assert.ok(2000>300);
});

test('fresh late level recovers at next tick but cannot outlive issue deadline',()=>{
  const s=new ScheduledInput(NEUTRAL),now=200;
  const result=s.receive(cmd(1,1),10,now,proof(300));assert.equal(result.retimedTargetTick,11);
  assert.equal(s.advance(11,250).input.throttle,1);
  assert.equal(s.advance(12,301).input.throttle,0);
  assert.equal(s.receive(cmd(2,2),12,302,proof(null)).rejection,'proof');
});

test('future slot cannot apply after its freshness lease ends',()=>{
  const s=new ScheduledInput(NEUTRAL);
  assert.equal(s.receive(cmd(1,8),0,200,proof(300)).rejection,undefined);
  assert.equal(s.advance(8,301).input.throttle,0);
});

test('same nonce cannot replay a sequence or reinstall an older release',()=>{
  const s=new ScheduledInput(NEUTRAL);
  assert.equal(s.receive(cmd(1,2,1),0,100,proof(300)).rejection,undefined);
  assert.equal(s.receive(cmd(1,2,1),0,101,proof(300)).rejection,'order');
  assert.equal(s.receive(cmd(2,1,0),0,110,proof(300)).rejection,undefined);
  assert.equal(s.advance(1,120).input.throttle,0);assert.equal(s.advance(2,130).input.throttle,0);
});

test('unproved old levels are rejected even when their target is in the future',()=>{
  const s=new ScheduledInput(NEUTRAL);
  assert.equal(s.receive(cmd(1,6),1,500,proof(null)).rejection,'proof');
  assert.equal(s.advance(6,501).input.throttle,0);
});

test('action and revision generations fence otherwise fresh controls and edges',()=>{
  const s=new ScheduledInput(NEUTRAL);assert.ok(s.beginAction(1,{jump:0,flip:0}));
  const before=s.receive(cmd(1,1,1,1,0,0),0,100,proof(300));assert.equal(before.rejection,'action');assert.equal(before.outcomes[0]?.status,'expired');
  s.invalidate(NEUTRAL,{type:'relocation'});
  assert.equal(s.receive(cmd(2,2,1,1,1,0),0,101,proof(300)).rejection,'revision');
  assert.equal(s.receive(cmd(3,2,1,1,1,1),0,102,proof(300)).rejection,undefined);
  assert.equal(s.advance(2,103).input.throttle,1);
});

test('press nonce is captured at press, remains single-use by serial, and expires 300 ms after receipt',()=>{
  const s=new ScheduledInput(NEUTRAL);
  const rejected=s.receive(cmd(1,1,0,1),0,250,proof(500,null,500));assert.equal(rejected.outcomes[0]?.status,'expired');
  assert.equal(s.receive(cmd(2,2,0,1),0,251,proof(500)).outcomes.length,0);
  assert.equal(s.advance(1,260).outcomes.length,0);
  const accepted=s.receive(cmd(3,2,0,2),1,290,proof(500,300));assert.equal(accepted.rejection,undefined);
  assert.equal(s.advance(2,301).outcomes.find(x=>x.kind==='jump')?.status,'processed');
  assert.equal(s.advance(3,302).outcomes.length,0);
});

test('fresh proof does not retarget an edge beyond the existing tick window',()=>{
  const s=new ScheduledInput(NEUTRAL);
  const result=s.receive(cmd(1,1,1,1),10,100,proof(300));
  assert.equal(result.retimedTargetTick,11);assert.equal(result.outcomes[0]?.status,'expired');
  assert.equal(s.advance(11,101).input.jump,0);
});

test('sequence flood preserves the scheduler future queue bound',()=>{
  const s=new ScheduledInput(NEUTRAL);
  for(let seq=1;seq<=200;seq++)s.receive(cmd(seq,1+(seq%8)),0,100,proof(300));
  assert.ok(s.snapshot().queued.length<=8);
});


test('receipt-only proof preserves pending timeout but admits up to 599 ms issue-to-application age',()=>{
  const s=new ScheduledInput(NEUTRAL);
  // Token issued at 0, press at 1, received at 299. Tick 8 occurs at 599.
  const r=s.receive(cmd(1,8,0,1),0,299,proof(300,300));
  assert.equal(r.rejection,undefined);
  const step=s.advance(8,599);
  assert.equal(step.outcomes.find(x=>x.kind==='jump')?.status,'processed');
  assert.equal(599-299,300);assert.equal(599-1,598);
});

test('ordered distinct edges execute once, duplicates and invalidated edges cannot replay',()=>{
  const s=new ScheduledInput(NEUTRAL);
  assert.equal(s.receive(cmd(1,1,0,1),0,0,proof(300)).rejection,undefined);
  const second=s.receive(cmd(2,1,0,2),0,1,proof(300));
  assert.deepEqual(second.outcomes.map(x=>x.status),['rescheduled']);
  assert.equal(s.advance(1,50).outcomes.filter(x=>x.status==='processed').length,1);
  assert.equal(s.advance(2,100).outcomes.filter(x=>x.status==='processed').length,1);
  assert.equal(s.receive(cmd(3,3,0,2),2,110,proof(300)).outcomes.length,0);
  s.receive(cmd(4,4,0,3),2,111,proof(300));
  const invalidated=s.invalidate(NEUTRAL,{type:'relocation'});
  assert.deepEqual(invalidated.map(x=>x.status),['superseded']);
  assert.equal(s.receive(cmd(5,4,0,3,0,1),2,112,proof(300)).outcomes.length,0);
  assert.equal(s.advance(4,120).outcomes.length,0);
});

test('failed action still advances action sequence without invalidating revision',()=>{
  const s=new ScheduledInput(NEUTRAL);assert.ok(s.beginAction(1,{jump:0,flip:0}));
  const old=s.receive(cmd(1,1,1,1,0,0),0,10,proof(300));
  assert.equal(old.rejection,'action');assert.equal(old.outcomes[0]?.status,'expired');
  const next=s.receive(cmd(2,1,1,1,1,0),0,20,proof(300));
  assert.equal(next.rejection,undefined);assert.equal(next.outcomes.length,0);
  assert.equal(s.advance(1,30).input.throttle,1);
});

test('snapshot reconstruction loses server-only level deadline, so prediction requires more work',()=>{
  const s=new ScheduledInput(NEUTRAL);
  s.receive(cmd(1,1,1),0,200,proof(300));s.advance(1,250);
  const prediction=ScheduledInput.fromSnapshot(s.snapshot(),250);
  assert.equal(s.advance(2,301).input.throttle,0);
  assert.equal(prediction.advance(2,301).input.throttle,1);
});
