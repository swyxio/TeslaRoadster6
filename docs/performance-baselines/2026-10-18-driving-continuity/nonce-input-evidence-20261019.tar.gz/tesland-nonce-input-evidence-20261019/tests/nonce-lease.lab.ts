import {randomBytes} from 'node:crypto';

// Model only. `clockBounded` represents an independently verified guarantee,
// not a property claimed for Cloudflare. One instance is one socket incarnation.
export class NonceLease {
  private readonly issued = new Map<string,number>();
  private last:number|null=null;
  private healthy:boolean;
  constructor(clockBounded:boolean,private readonly capacity=16) {this.healthy=clockBounded;}
  private observe(now:number) {
    if(!Number.isFinite(now)||(this.last!==null&&now<this.last))this.healthy=false;
    this.last=now;
    return this.healthy;
  }
  issue(now:number):string|null {
    if(!this.observe(now))return null;
    const token=randomBytes(16).toString('hex');
    this.issued.set(token,now);
    while(this.issued.size>this.capacity)this.issued.delete(this.issued.keys().next().value!);
    return token;
  }
  until(token:string|null,now:number):number|null {
    if(!this.observe(now)||!token)return null;
    const at=this.issued.get(token);
    if(at===undefined||now-at>300)return null;
    return at+300;
  }
}
