import assert from 'node:assert/strict';
import test from 'node:test';
import { analyzeSubstepContinuity, bracketPolls, pollingOverhead } from './substep-continuity-gate.mjs';

const point = x => ({ x, y: 0, z: 0, supportId: 'ground' });
function fixture() {
  const ticks = Array.from({ length: 101 }, (_, tick) => ({ tick, poseRevision: 1, start: point((tick - 1) * .6),
    substeps: [point((tick - .5) * .6), point(tick * .6)], contactReasons: [] }));
  const events = ticks.flatMap(({ tick }) => [
    { tick, poseRevision: 1, sentAtMs: tick * 50 + .1, receivedAtMs: tick * 50 + .2 },
    { tick, poseRevision: 1, sentAtMs: tick * 50 + 49.5, receivedAtMs: tick * 50 + 49.6 },
  ]);
  const frames = Array.from({ length: 121 }, (_, i) => {
    const atMs = 600 + i * 1000 / 60;
    return { atMs, visual: point(atMs * 12 / 1000), menu: false };
  });
  return { trace: { frames, controls: [{ atMs: 0, throttle: 1, steer: 0, brake: false, boost: false, hover: false }],
    errors: 0, dropped: { frames: 0, states: 0, sent: 0, controls: 0, events: 0, marks: 0, turnarounds: 0 } },
    authority: { format: 'substep-v1', complete: true, dropped: 0, collisionCoverage: 'grounded-path-v1', ticks },
    polling: { complete: true, dropped: 0, errors: 0, sameAuthoritativeObject: true, serialTickReadsVerified: true, clockBoundVerified: true, clockResolutionBoundMs: 0, events },
    window: { startMs: frames[0].atMs, endMs: frames.at(-1).atMs } };
}

test('serial polls bracket each tick in the browser clock', () => {
  const { polling } = fixture(), result = bracketPolls(polling);
  assert.deepEqual(result.invalid, []);
  for (let tick = 1; tick < 100; tick++) {
    const bracket = result.bounds.get(tick);
    assert.ok(bracket.min <= tick * 50 && bracket.max >= tick * 50);
  }
  assert.ok(result.statistics.requestsPerSecond > 0);
});

test('constant-speed substep reference remains bounded over cross-boundary frames', () => {
  const report = analyzeSubstepContinuity(fixture());
  assert.equal(report.status, 'measured'); assert.equal(report.withinTarget, true);
  assert.ok(report.sampleCount >= 100); assert.ok(report.conservativeP05 >= .9); assert.ok(report.conservativeP95 <= 1.1);
  assert.equal(report.gateEligible, false); assert.equal(report.overhead.status, 'unavailable');
});

test('bounds enclose reference chords for varied tick times and a gently curved path', () => {
  const input = fixture(), curve = x => ({ x, y: .1 * Math.sin(x / 20), z: .2 * Math.sin(x / 30), supportId: 'ground' });
  input.authority.ticks.forEach(t => {
    t.start = curve(t.start.x); t.substeps = t.substeps.map(p => curve(p.x));
  });
  const report = analyzeSubstepContinuity(input), bounds = bracketPolls(input.polling).bounds;
  assert.equal(report.status, 'measured');
  let seed = 17;
  const random = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32);
  for (let trial = 0; trial < 20; trial++) {
    const times = input.authority.ticks.map((t, i) => {
      const b = bounds.get(t.tick); return b ? b.min + (b.max - b.min) * random() : i * 50;
    });
    const at = time => {
      let n = 1; while (n < times.length && times[n] < time) n++;
      const tick = input.authority.ticks[n], fraction = (time - times[n - 1]) / (times[n] - times[n - 1]);
      const scaled = fraction * tick.substeps.length, part = Math.min(tick.substeps.length - 1, Math.floor(scaled));
      const left = part === 0 ? tick.start : tick.substeps[part - 1], right = tick.substeps[part], u = scaled - part;
      return { x: left.x + (right.x - left.x) * u, y: left.y + (right.y - left.y) * u, z: left.z + (right.z - left.z) * u };
    };
    for (const sample of report.samples) {
      const a = at(sample.atMs - sample.frameMs), b = at(sample.atMs);
      const reference = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
      const ratio = sample.displayedM / reference;
      assert.ok(ratio >= sample.lowerRatio - 1e-10 && ratio <= sample.upperRatio + 1e-10);
    }
  }
});

test('unknown clocks, skipped polls and overlapping requests fail closed', () => {
  for (const mutate of [
    input => { input.polling.sameAuthoritativeObject = false; },
    input => { input.polling.serialTickReadsVerified = false; },
    input => { input.polling.clockBoundVerified = false; },
    input => { input.polling.events = input.polling.events.filter(e => e.tick !== 20); },
    input => { input.polling.events[10].sentAtMs = input.polling.events[9].sentAtMs; },
  ]) {
    const input = fixture(); mutate(input);
    assert.equal(analyzeSubstepContinuity(input).status, 'unavailable');
  }
});

test('control windows account for clock uncertainty at the frame boundary', () => {
  const input = fixture();
  input.polling.clockResolutionBoundMs = .1;
  const boundary = input.trace.frames[60].atMs;
  input.trace.controls.push({ atMs: boundary + .05, throttle: 0, steer: 0, brake: false, boost: false, hover: false });
  const report = analyzeSubstepContinuity(input);
  assert.ok(report.sampleCount > 30);
  assert.equal(report.samples.some(sample => sample.atMs === boundary), false);
});

test('wide time bounds and slow poll sampling remain unavailable', () => {
  const input = fixture(); input.polling.events = input.polling.events.filter((_, i) => i % 2 === 0);
  assert.equal(analyzeSubstepContinuity(input).withinTarget, null);
  assert.match(analyzeSubstepContinuity(input).status, /^unavailable/);
});

test('recurring rendered pauses remain failures instead of being excluded', () => {
  const input = fixture();
  for (let i = 7; i < input.trace.frames.length; i += 8) input.trace.frames[i].visual = { ...input.trace.frames[i - 1].visual };
  const report = analyzeSubstepContinuity(input);
  assert.equal(report.status, 'measured'); assert.equal(report.withinTarget, false);
});

test('contacts, missing authority ticks, and changed poses never become a pass', () => {
  const contact = fixture(); contact.authority.ticks.forEach(t => t.contactReasons.push('solid'));
  assert.equal(analyzeSubstepContinuity(contact).withinTarget, null);
  const missing = fixture(); missing.authority.ticks.splice(20, 1);
  assert.equal(analyzeSubstepContinuity(missing).status, 'unavailable');
  const changed = fixture(); changed.authority.ticks[20].start.x += 1;
  assert.equal(analyzeSubstepContinuity(changed).status, 'unavailable');
  const mismatch = fixture(); mismatch.authority.ticks[20].poseRevision = 2;
  assert.equal(analyzeSubstepContinuity(mismatch).status, 'unavailable');
});

test('overhead comparison reports observed deltas without claiming equivalence', () => {
  const metrics = { revision: 'abc', profile: 'zero', scenario: 'W', environment: 'desktop', elapsedMs: 10000, simulationSeconds: 9.8, frameP95Ms: 19 };
  const comparison = pollingOverhead({ unpolled: metrics, polled: { ...metrics, simulationSeconds: 9.6, frameP95Ms: 22 } });
  assert.equal(comparison.status, 'observed'); assert.ok(comparison.simulationRateDelta < 0); assert.equal(comparison.frameP95DeltaMs, 3);
  assert.equal(pollingOverhead({ unpolled: metrics, polled: { ...metrics, revision: 'other' } }).status, 'unavailable');
});
