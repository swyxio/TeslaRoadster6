// Offline sensitivity study only: clock equivalence and control timestamp
// errors are assumed, never asserted. No result from this is a release pass.
import {readFile,writeFile} from 'node:fs/promises';
import {parseNativeClock} from '/private/tmp/tesland-gate-lab-bUdLYT/scripts/native-clock.mjs';
const root='/private/tmp/tesland-continuity-evidence/native-candidate-02/';
const capture=JSON.parse(await readFile(root+'capture.json'));
const logs=await Promise.all(['native-clock-69800.bin','native-clock-69801.bin'].map(async n=>parseNativeClock(await readFile(root+n))));
if(logs.some(n=>!n.valid))throw Error('invalid native log');
const indexes=logs.map(n=>{const m=new Map();for(const e of n.events){const a=m.get(e.ms)||[];a.push(e);m.set(e.ms,a)}return m});
const bounds=new Map(), widths=[], counts=[];
for(const t of capture.authority.ticks){
 let lo=null,hi=null,pairs=0;
 for(let i=0;i<logs.length;i++){const n=logs[i],ix=indexes[i];for(const a of ix.get(t.nativeBeforeMs)||[])for(const b of ix.get(t.nativeAfterMs)||[]){
   if(a.index===b.index||a.thread!==b.thread||a.after>b.before)continue;
   const min=a.before*n.numer/n.denom,max=(b.after*n.numer+n.denom-1n)/n.denom;
   lo=lo===null||min<lo?min:lo;hi=hi===null||max>hi?max:hi;pairs++;
 }}
 if(lo===null)throw Error(`missing tick ${t.tick}`);
 bounds.set(t.tick,{min:Number(lo)/1e6-.001,max:Number(hi)/1e6+.001});
 widths.push(Number(hi-lo)/1e6);counts.push(pairs);
}
const marks=capture.nativeClock.browserMarkers.matches,frames=capture.trace.frames;
if(marks.length!==frames.length)throw Error('missing browser marker');
// Map a browser control change to the first frame known later under an
// explicitly assumed 0.1 ms worst-case performance.now() error per reading.
const controls=[];
for(const c of capture.trace.controls){const i=frames.findIndex(f=>f.atMs>c.atMs+.2);if(i<0)continue;
 controls.push({...c,atMs:marks[i].maxUs/1000+.001});}
const mapped=frames.map((f,i)=>({...f,atMs:(marks[i].minUs+marks[i].maxUs)/2000}));
const frameEpsilon=Math.max(...marks.map(m=>(m.maxUs-m.minUs)/2000))+.001;
const inWindow=frames.map((f,i)=>({f,i})).filter(x=>x.f.atMs>=capture.window.startMs+.2&&x.f.atMs<=capture.window.endMs-.2);
if(inWindow.length<2)throw Error('missing frame window');
const window={startMs:mapped[inWindow[0].i].atMs,endMs:mapped[inWindow.at(-1).i].atMs};
let source=await readFile('/private/tmp/tesland-gate-lab-bUdLYT/substep-continuity-gate.mjs','utf8');
const oldA='const polled = bracketPolls(polling), overhead = pollingOverhead(overheadComparison);';
const newA='const polled = {invalid:[],bounds:polling.diagnosticBounds,statistics:null}, overhead = pollingOverhead(overheadComparison);';
const oldB='const polls = polling.events, firstObservedTick = polls[0].tick, lastObservedTick = polls.at(-1).tick;';
const newB='const polls = [{poseRevision:authority.ticks[0].poseRevision}], firstObservedTick = authority.ticks[0].tick, lastObservedTick = authority.ticks.at(-1).tick;';
if(!source.includes(oldA)||!source.includes(oldB))throw Error('unexpected analyzer source');
source=source.replace(oldA,newA).replace(oldB,newB);
const historyCheck='if (!relevant.length || !finite(historyMin) || !(historyMin > 10) || historyMax - historyMin > Math.max(1, .05 * historyMin))';
if(!source.includes(historyCheck))throw Error('unexpected history check');
source=source.replace(historyCheck,`globalThis.__nativeHistory.push({min:historyMin,max:historyMax,relevant:relevant.length}); ${historyCheck}`);
globalThis.__nativeHistory=[];
const {analyzeSubstepContinuity}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const out=analyzeSubstepContinuity({trace:{...capture.trace,frames:mapped,controls},authority:capture.authority,
 polling:{diagnosticBounds:bounds,clockResolutionBoundMs:frameEpsilon},window});
const sorted=[...widths].sort((a,b)=>a-b),q=p=>sorted[Math.floor((sorted.length-1)*p)];
const steady=globalThis.__nativeHistory.filter(h=>h.relevant && Number.isFinite(h.min)&&h.min>10&&Number.isFinite(h.max));
const spreads=steady.map(h=>(h.max-h.min)/h.min).sort((a,b)=>a-b);
const result={diagnosticOnly:true,gateEligible:false,assumptions:['JS marker values identify native clock calls','all native files are stable and complete','Chrome trace timestamps share the native Mach clock','performance.now readings each have at most 0.1 ms error','substep-linear reference convention'],
 authorityHullMs:{p50:q(.5),p95:q(.95),max:q(1)},frameBoundEpsilonMs:frameEpsilon,ambiguousTicks:counts.filter(n=>n>1).length,
 referenceHistory:{qualifiedOver10mps:steady.length,bestRelativeSpread:spreads[0]??null,p50RelativeSpread:spreads[Math.floor((spreads.length-1)*.5)]??null,withinFivePercent:spreads.filter(x=>x<=.05).length},
 analysis:{status:out.status,withinTarget:out.withinTarget,sampleCount:out.sampleCount,incompleteIntervals:out.incompleteIntervals,
 conservativeP05:out.conservativeP05,conservativeP95:out.conservativeP95,excluded:out.excluded,invalid:out.invalid}};
await writeFile('/private/tmp/tesland-continuity-evidence/native-candidate-02/hypothetical-hull-analysis.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
