// Local test fixture only. Never load into a production Worker. Record every
// successful workerd CLOCK_REALTIME call alongside the host Mach clock.
#include <time.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#define CAPACITY 100000u
#define MAGIC UINT64_C(0x5445534c4d414348)
typedef struct { uint64_t magic, version, pid, numer, denom, capacity; _Atomic uint64_t count, dropped; } Header;
typedef struct { uint64_t before, after; int64_t sec, nsec; uint64_t thread; _Atomic uint64_t committed; } Record;
static Header *header;
static Record *records;
static _Thread_local int nested;
__attribute__((constructor)) static void init_probe(void) {
  const char *dir=getenv("TESLAND_NATIVE_TRACE_DIR");
  if(!dir || !getprogname() || strcmp(getprogname(),"workerd")) return;
  char path[1024];
  int n=snprintf(path,sizeof(path),"%s/clock-%ld.bin",dir,(long)getpid());
  if(n<0 || (size_t)n>=sizeof(path)) return;
  int fd=open(path,O_RDWR|O_CREAT|O_EXCL,0600); if(fd<0) return;
  size_t size=sizeof(Header)+(size_t)CAPACITY*sizeof(Record);
  if(ftruncate(fd,(off_t)size)){close(fd);return;}
  void *map=mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);close(fd);
  if(map==MAP_FAILED) return;
  header=map;records=(Record *)(header+1);
  mach_timebase_info_data_t t;
  if(mach_timebase_info(&t)!=KERN_SUCCESS || !t.numer || !t.denom){header=NULL;records=NULL;return;}
  header->magic=MAGIC;header->version=1;header->pid=(uint64_t)getpid();header->numer=t.numer;header->denom=t.denom;header->capacity=CAPACITY;
}
static int observed_clock_gettime(clockid_t id, struct timespec *value) {
  if(nested || !header || id!=CLOCK_REALTIME) return clock_gettime(id,value);
  nested=1;
  uint64_t before=mach_absolute_time();int result=clock_gettime(id,value);uint64_t after=mach_absolute_time();
  if(result==0) {
    uint64_t index=atomic_fetch_add_explicit(&header->count,1,memory_order_relaxed);
    if(index>=CAPACITY) atomic_fetch_add_explicit(&header->dropped,1,memory_order_relaxed);
    else {
      Record *r=&records[index];uint64_t tid=0;
      if(pthread_threadid_np(NULL,&tid)!=0) tid=0;
      r->before=before;r->after=after;r->sec=value->tv_sec;r->nsec=value->tv_nsec;r->thread=tid;
      atomic_store_explicit(&r->committed,1,memory_order_release);
    }
  }
  nested=0;return result;
}
__attribute__((used)) static const struct { const void *replacement, *replacee; } interpose[]
__attribute__((section("__DATA,__interpose"))) = {{(const void *)observed_clock_gettime,(const void *)clock_gettime}};
