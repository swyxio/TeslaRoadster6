import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNativeClock, matchAuthorityMarks, matchBrowserMarkers } from './scripts/native-clock.mjs';
const fixture = entries => {
 const b=Buffer.alloc(64+48*8);
 [0x5445534c4d414348n,1n,9n,125n,3n,8n,BigInt(entries.length),0n].forEach((x,i)=>b.writeBigUInt64LE(x,i*8));
 entries.forEach(([before,after,ms,tid],j)=>{
  const p=64+j*48;
  [BigInt(before),BigInt(after),BigInt(Math.floor(ms/1000)),BigInt((ms%1000)*1000000),BigInt(tid),1n].forEach((x,i)=>b.writeBigUInt64LE(x,p+i*8));
 });
 return b;
};
test('unique same-thread ordered clock observations are bounded with conservative rounding',()=>{
 const n=parseNativeClock(fixture([[100,101,1234,1],[104,105,1234,1],[300,302,2234,2],[306,309,2235,2]]));
 assert.equal(n.valid,true);
 const out=matchAuthorityMarks(n,[{tick:1,nativeBeforeMs:1234,nativeAfterMs:1234},{tick:2,nativeBeforeMs:2234,nativeAfterMs:2235}]);
 assert.equal(out.valid,true);assert.deepEqual(out.matches.map(x=>[x.minNs,x.maxNs]),[['4166','4375'],['12500','12875']]);
});
test('missing, duplicated, reused and wrong-thread matches fail closed',()=>{
 const a=parseNativeClock(fixture([[100,101,1234,1],[104,105,1234,1],[110,111,1234,1]]));
 assert.equal(matchAuthorityMarks(a,[{tick:1,nativeBeforeMs:1234,nativeAfterMs:1234}]).reason,'ambiguous-authority-mark');
 const b=parseNativeClock(fixture([[100,101,1234,1],[104,105,1234,2]]));
 assert.equal(matchAuthorityMarks(b,[{tick:1,nativeBeforeMs:1234,nativeAfterMs:1234}]).reason,'missing-native-authority-mark');
 const c=parseNativeClock(fixture([[100,101,1234,1],[104,105,1234,1]]));
 assert.equal(matchAuthorityMarks(c,[{tick:1,nativeBeforeMs:1234,nativeAfterMs:1234},{tick:2,nativeBeforeMs:1234,nativeAfterMs:1234}]).reason,'reused-native-record');
});
test('native overflow and incomplete records fail closed',()=>{
 const a=fixture([]);a.writeBigUInt64LE(1n,56);assert.equal(parseNativeClock(a).reason,'invalid-or-overflowed-native-log');
 const b=fixture([[100,101,1234,1]]);b.writeBigUInt64LE(0n,64+40);assert.equal(parseNativeClock(b).reason,'incomplete-native-record');
});
test('wall-clock reversal is paired using ordering without assuming monotone epoch',()=>{
 const n=parseNativeClock(fixture([[100,101,5000,1],[104,105,4999,1]]));
 assert.equal(matchAuthorityMarks(n,[{tick:1,nativeBeforeMs:5000,nativeAfterMs:4999}]).valid,true);
});
test('overlapping tick brackets are not silently assigned an order',()=>{
 const n=parseNativeClock(fixture([[100,120,5000,1],[300,320,5001,1],[200,220,6000,2],[400,420,6001,2]]));
 const r=matchAuthorityMarks(n,[{tick:1,nativeBeforeMs:5000,nativeAfterMs:5001},{tick:2,nativeBeforeMs:6000,nativeAfterMs:6001}]);
 assert.equal(r.reason,'overlapping-or-out-of-order-native-ticks');
});
test('browser marker completeness and duplicate detection are enforced',()=>{
 const e=(message,ts)=>({name:'TimeStamp',ts,pid:1,tid:2,args:{data:{message}}});
 const one=[e('tesland-frame-start:0',100),e('tesland-frame-end:0',101)];
 assert.equal(matchBrowserMarkers(one,[{}]).valid,true);
 assert.equal(matchBrowserMarkers(one,[{},{}]).valid,false);
 assert.equal(matchBrowserMarkers([...one,one[0]],[{}]).valid,false);
 assert.equal(matchBrowserMarkers([one[1],one[0]],[{}]).valid,true);
 assert.equal(matchBrowserMarkers([e('tesland-frame-start:0',101),e('tesland-frame-end:0',100)],[{}]).valid,false);
 assert.equal(matchBrowserMarkers([{...one[0],name:'other'},one[1]],[{}]).valid,false);
});
