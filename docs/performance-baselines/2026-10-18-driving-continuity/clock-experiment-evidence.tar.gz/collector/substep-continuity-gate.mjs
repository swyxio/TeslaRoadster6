// Experimental offline analysis. Browser-clock polling brackets discrete DO
// tick completions; it does not measure Worker CPU time. The reference is the
// explicitly defined piecewise-linear path through authoritative substep poses.
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const finite = Number.isFinite;
const pose = p => p && ['x', 'y', 'z'].every(k => finite(p[k]));
const distance = (a, b) => Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
const percentile = (values, p) => {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted.length ? sorted[Math.floor((sorted.length - 1) * p)] : null;
};
const prior = (items, time) => {
  let lo = 0, hi = items.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (items[mid].atMs <= time) lo = mid + 1; else hi = mid; }
  return lo - 1;
};
const fail = invalid => ({ status: 'unavailable', withinTarget: null, invalid, samples: [], gateEligible: false });

export function bracketPolls(polling) {
  const invalid = [], polls = Array.isArray(polling?.events) ? polling.events : [];
  const epsilon = polling?.clockResolutionBoundMs;
  if (polling?.complete !== true || polling?.dropped !== 0 || polling?.errors !== 0 ||
      polling?.sameAuthoritativeObject !== true || polling?.serialTickReadsVerified !== true || polling?.clockBoundVerified !== true ||
      !finite(epsilon) || epsilon < 0 || polls.length < 2) invalid.push('unproven-poll-provenance');
  for (let i = 0; i < polls.length; i++) {
    const p = polls[i], prev = polls[i - 1];
    if (!finite(p?.sentAtMs) || !finite(p?.receivedAtMs) || p.receivedAtMs < p.sentAtMs ||
        !Number.isSafeInteger(p?.tick) || !Number.isSafeInteger(p?.poseRevision) ||
        (prev && (p.sentAtMs < prev.receivedAtMs || p.tick < prev.tick))) invalid.push('invalid-or-overlapping-polls');
    if (prev && p.tick - prev.tick > 1) invalid.push('skipped-poll-ticks');
    if (prev && p.poseRevision !== prev.poseRevision) invalid.push('poll-pose-revision-changed');
  }
  if (invalid.length) return { invalid: [...new Set(invalid)], bounds: new Map(), statistics: null };
  const bounds = new Map();
  for (let i = 1; i < polls.length; i++) {
    const before = polls[i - 1], after = polls[i];
    if (after.tick === before.tick + 1)
      bounds.set(after.tick, { min: before.sentAtMs - epsilon, max: after.receivedAtMs + epsilon });
  }
  const span = polls.at(-1).receivedAtMs - polls[0].sentAtMs;
  const latency = polls.map(p => p.receivedAtMs - p.sentAtMs);
  return { invalid: [], bounds, statistics: { requests: polls.length, spanMs: span,
    requestsPerSecond: span > 0 ? 1000 * polls.length / span : null,
    requestLatencyP95Ms: percentile(latency, .95), maximumBracketWidthMs: bounds.size ? Math.max(...[...bounds.values()].map(x => x.max - x.min)) : null } };
}

// This compares observed metrics. A single pair cannot establish that polling
// has no overhead, so no threshold or equivalence conclusion is invented.
export function pollingOverhead(comparison) {
  const a = comparison?.unpolled, b = comparison?.polled;
  if (!a || !b || !['revision', 'profile', 'scenario', 'environment'].every(k => typeof a[k] === 'string' && a[k] === b[k]) ||
      ![a.elapsedMs, a.simulationSeconds, a.frameP95Ms, b.elapsedMs, b.simulationSeconds, b.frameP95Ms].every(finite) ||
      a.elapsedMs <= 0 || b.elapsedMs <= 0)
    return { status: 'unavailable', note: 'No matched unpolled comparison; probe perturbation is uncharacterized.' };
  return { status: 'observed', unpolledSimulationRate: a.simulationSeconds * 1000 / a.elapsedMs,
    polledSimulationRate: b.simulationSeconds * 1000 / b.elapsedMs,
    simulationRateDelta: b.simulationSeconds * 1000 / b.elapsedMs - a.simulationSeconds * 1000 / a.elapsedMs,
    unpolledFrameP95Ms: a.frameP95Ms, polledFrameP95Ms: b.frameP95Ms, frameP95DeltaMs: b.frameP95Ms - a.frameP95Ms,
    note: 'Observed difference only; an isolated pair cannot prove polling has no effect.' };
}

export function analyzeSubstepContinuity({ trace, authority, polling, window, overheadComparison } = {}) {
  const polled = bracketPolls(polling), overhead = pollingOverhead(overheadComparison);
  if (polled.invalid.length) return { ...fail(polled.invalid), polling: polled.statistics, overhead };
  const frames = trace?.frames, controls = trace?.controls;
  const polls = polling.events, firstObservedTick = polls[0].tick, lastObservedTick = polls.at(-1).tick;
  const ticks = Array.isArray(authority?.ticks) ? authority.ticks.filter(t => t?.tick >= firstObservedTick && t?.tick <= lastObservedTick) : null;
  const ordered = a => Array.isArray(a) && a.every((x, i) => finite(x?.atMs) && (!i || x.atMs >= a[i - 1].atMs));
  const invalid = [];
  if (!window || !finite(window.startMs) || !finite(window.endMs) || window.endMs <= window.startMs) invalid.push('invalid-window');
  if (!ordered(frames) || !ordered(controls)) invalid.push('invalid-browser-timelines');
  if (trace?.errors !== 0 || ['frames', 'states', 'sent', 'controls', 'events', 'marks', 'turnarounds'].some(k => trace?.dropped?.[k] !== 0)) invalid.push('incomplete-browser-trace');
  if (authority?.format !== 'substep-v1' || authority?.complete !== true || authority?.dropped !== 0 ||
      authority?.collisionCoverage !== 'grounded-path-v1' || !Array.isArray(ticks) || ticks.length < 2) invalid.push('incomplete-substep-authority');
  if (invalid.length) return { ...fail(invalid), polling: polled.statistics, overhead };
  for (let i = 0; i < ticks.length; i++) {
    const t = ticks[i], prev = ticks[i - 1];
    if (!Number.isSafeInteger(t?.tick) || !Number.isSafeInteger(t?.poseRevision) || t.poseRevision !== polls[0].poseRevision || !pose(t?.start) ||
        !Array.isArray(t?.substeps) || t.substeps.length < 1 || t.substeps.length > 8 ||
        t.substeps.some(s => !pose(s) || typeof s.supportId !== 'string') || typeof t.start.supportId !== 'string' ||
        !Array.isArray(t.contactReasons) || t.contactReasons.some(x => typeof x !== 'string') ||
        (prev && (t.tick !== prev.tick + 1 || !Array.isArray(prev.substeps) || !pose(prev.substeps.at(-1)) ||
          t.start.supportId !== prev.substeps.at(-1).supportId || distance(t.start, prev.substeps.at(-1)) > 1e-8)))
      invalid.push('invalid-or-discontinuous-authority');
  }
  if (invalid.length) return { ...fail([...new Set(invalid)]), polling: polled.statistics, overhead };
  const epsilon = polling.clockResolutionBoundMs;
  const excluded = { outside: 0, control: 0, missingBrackets: 0, invalidFrame: 0, nonGroundOrContact: 0, unsteady: 0, uncertainReference: 0 };
  const samples = [];
  for (let i = 1; i < frames.length; i++) {
    const a = frames[i - 1], b = frames[i], dt = b.atMs - a.atMs;
    if (a.atMs < window.startMs || b.atMs > window.endMs) { excluded.outside++; continue; }
    if (!pose(a.visual) || !pose(b.visual) || a.menu !== false || b.menu !== false || !(dt > 2 * epsilon)) { excluded.invalidFrame++; continue; }
    // A control-change timestamp and a frame timestamp can each be off by
    // epsilon. Select only intervals whose entire expanded time range has
    // the same control and whose 500 ms settling period is proven complete.
    const control = prior(controls, a.atMs - epsilon), c = controls[control];
    if (control < 0 || prior(controls, b.atMs + epsilon) !== control || c.throttle !== 1 || c.steer !== 0 || c.brake !== false || c.boost !== false || c.hover !== false || c.atMs > a.atMs - 500 - 2 * epsilon) { excluded.control++; continue; }
    const low = a.atMs - epsilon - 500, high = b.atMs + epsilon;
    let first = -1, last = -1;
    for (let j = 0; j < ticks.length; j++) {
      const bounds = polled.bounds.get(ticks[j].tick);
      if (bounds && bounds.max <= low) first = j;
      if (bounds && bounds.min >= high) { last = j; break; }
    }
    if (first < 0 || last <= first) { excluded.missingBrackets++; continue; }
    let bad = false, outOfScope = false, historyMin = Infinity, historyMax = 0;
    const relevant = [];
    for (let j = first + 1; j <= last; j++) {
      const previous = ticks[j - 1], tick = ticks[j], prevTime = polled.bounds.get(previous.tick), nextTime = polled.bounds.get(tick.tick);
      if (!prevTime || !nextTime || tick.poseRevision !== previous.poseRevision) { bad = true; break; }
      const minDuration = nextTime.min - prevTime.max, maxDuration = nextTime.max - prevTime.min;
      if (!(minDuration > 0) || !(maxDuration >= minDuration)) { bad = true; break; }
      const count = tick.substeps.length, nodes = [tick.start, ...tick.substeps];
      for (let s = 0; s < count; s++) {
        const startU = s / count, endU = (s + 1) / count;
        const earliestStart = (1 - startU) * prevTime.min + startU * nextTime.min;
        const latestEnd = (1 - endU) * prevTime.max + endU * nextTime.max;
        if (earliestStart > high || latestEnd < low) continue;
        if (tick.contactReasons.length || nodes[s].supportId !== 'ground' || nodes[s + 1].supportId !== 'ground') { outOfScope = true; continue; }
        const dx = nodes[s + 1].x - nodes[s].x, dy = nodes[s + 1].y - nodes[s].y, dz = nodes[s + 1].z - nodes[s].z;
        const length = Math.hypot(dx, dy, dz), minSpeed = 1000 * count * length / maxDuration, maxSpeed = 1000 * count * length / minDuration;
        historyMin = Math.min(historyMin, minSpeed); historyMax = Math.max(historyMax, maxSpeed);
        if (earliestStart <= b.atMs + epsilon && latestEnd >= a.atMs - epsilon) relevant.push({ dx, dy, dz, count, minDuration, maxDuration });
      }
    }
    if (bad) { excluded.missingBrackets++; continue; }
    if (outOfScope) { excluded.nonGroundOrContact++; continue; }
    if (!relevant.length || !finite(historyMin) || !(historyMin > 10) || historyMax - historyMin > Math.max(1, .05 * historyMin)) { excluded.uncertainReference++; continue; }
    const main = relevant.reduce((best, v) => Math.hypot(v.dx, v.dy, v.dz) > Math.hypot(best.dx, best.dy, best.dz) ? v : best);
    const magnitude = Math.hypot(main.dx, main.dy, main.dz);
    if (!(magnitude > 0)) { excluded.uncertainReference++; continue; }
    const u = { x: main.dx / magnitude, y: main.dy / magnitude, z: main.dz / magnitude };
    let minProjection = Infinity, maxMagnitude = 0;
    for (const v of relevant) {
      const projection = v.count * (u.x * v.dx + u.y * v.dy + u.z * v.dz);
      minProjection = Math.min(minProjection, projection / (projection >= 0 ? v.maxDuration : v.minDuration));
      maxMagnitude = Math.max(maxMagnitude, v.count * Math.hypot(v.dx, v.dy, v.dz) / v.minDuration);
    }
    const referenceMin = Math.max(0, minProjection) * (dt - 2 * epsilon), referenceMax = maxMagnitude * (dt + 2 * epsilon);
    if (!(referenceMin > 0) || !(referenceMax > 0)) { excluded.uncertainReference++; continue; }
    const displayed = distance(a.visual, b.visual);
    samples.push({ atMs: b.atMs, frameMs: dt, displayedM: displayed, referenceMinM: referenceMin, referenceMaxM: referenceMax,
      lowerRatio: displayed / referenceMax, upperRatio: displayed / referenceMin });
  }
  const p05 = percentile(samples.map(s => s.lowerRatio), .05), p95 = percentile(samples.map(s => s.upperRatio), .95);
  const p05Upper = percentile(samples.map(s => s.upperRatio), .05), p95Lower = percentile(samples.map(s => s.lowerRatio), .95);
  const incomplete = excluded.invalidFrame + excluded.missingBrackets + excluded.uncertainReference;
  const result = samples.length < 30 || incomplete ? null : p05 >= .9 && p95 <= 1.1 ? true : p05Upper < .9 || p95Lower > 1.1 ? false : null;
  return { status: result === null ? 'unavailable-uncertain-or-insufficient-bounds' : 'measured', withinTarget: result, gateEligible: false,
    invalid: [], sampleCount: samples.length, incompleteIntervals: incomplete, conservativeP05: p05, conservativeP95: p95,
    excluded, samples, polling: polled.statistics, overhead,
    note: 'Reference is a declared substep-linear numerical interpolation mapped to bounded browser-time tick endpoints. This local instrumented scenario is not the complete release gate.' };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length !== 1 && !(args.length === 3 && args[1] === '--assume-clock-error-ms'))
    throw new Error('Usage: node substep-continuity-gate.mjs CAPTURE.json [--assume-clock-error-ms NUMBER]');
  const input = JSON.parse(await readFile(resolve(args[0]), 'utf8'));
  if (args.length === 3) {
    const assumed = Number(args[2]);
    if (!finite(assumed) || assumed < 0 || !input.polling) throw new Error('Expected a nonnegative clock assumption and polling data');
    input.polling.clockResolutionBoundMs = assumed;
    input.polling.clockBoundVerified = true;
  }
  const report = analyzeSubstepContinuity(input);
  if (args.length === 3) report.diagnosticAssumptions = ['Browser clock error was assumed for sensitivity analysis and is not verified.'];
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href)
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
