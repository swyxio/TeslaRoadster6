## Tesland performance observation

Base: HOLD (report missing)  
Candidate: 0.0.33-alpha · 84f9cf3268b2

| Metric | Base | Candidate | Change |
| --- | ---: | ---: | ---: |
| Browser animation interval p95 | HOLD ms | 133.3 ms | HOLD |
| Modeled display / body speed p05–p95 | HOLD | 0.897–1.021× | HOLD |
| Modeled steering onset left / right | HOLD | 8.333 / 8.333 ms | HOLD |
| Room simulated / wall seconds | HOLD× | 1× | HOLD |

Bunched 150 ms synthetic speed ratio: base HOLD, candidate 0.862–1.019×.
Browser renderer: ANGLE (Apple, ANGLE Metal Renderer: Apple Paravirtual device, Unspecified Version). Route: target identity missing; path difference p95 HOLD m, max HOLD m.

Path difference by leg (p95 / max, m): HOLD.

Required observations: HOLD (one or more metrics are missing or unavailable).

Animation intervals are browser callback timing, not GPU completion or actual display presentation. Motion and steering are synthetic at 120 Hz with simulated latency. Room progress is observed from received ticks during one delivery and flight in one local room. Video capture: base HOLD, candidate off; video observations do not produce performance deltas.
A single paired run is descriptive, not a regression verdict; repeat on the same quiet hardware before setting thresholds. Frame and room deltas are held if environments or initial delivery targets differ, video is enabled, milestones are missing, or the three sampled paths diverge beyond the documented tolerances. Five-leg reports are incompatible with this three-leg scenario. Raw traces and conditions are in the uploaded artifact.
