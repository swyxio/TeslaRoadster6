import test from 'node:test';
import assert from 'node:assert/strict';
import {makeEntity} from './base/shared/game';
import {updateRocketPickup as baseline} from './base/shared/rocket';
import {updateRocketPickup as candidate} from './candidate/shared/rocket';

function runPair(pad:any,entities:any[],time:number,denied:string[]=[]){
  const p1=structuredClone(pad),p2=structuredClone(pad);
  const e1=structuredClone(entities),e2=structuredClone(entities);
  const calls1:string[]=[],calls2:string[]=[];
  const a=baseline(p1,e1,time,id=>(calls1.push(id),!denied.includes(id)));
  const b=candidate(p2,e2,time,id=>(calls2.push(id),!denied.includes(id)));
  assert.deepStrictEqual({a,p1,e1,calls1},{a:b,p1:p2,e1:e2,calls1:calls2});
  return {result:a,pad:p1,entities:e1,calls:calls1};
}
function car(id:string,x:number,z:number){const e=makeEntity(id,'model-3',0,0,id);e.x=x;e.z=z;e.y=0;e.supportId='ground';e.air=1;return e;}
const p=()=>({x:0,z:0,active:true,readyAt:0});

test('distance guard preserves boundary, exceptional numeric behavior, and eligibility calls',()=>{
  for(const x of [-Infinity,-Number.MAX_VALUE,-4,-4+Number.EPSILON*2,-3.999,-Number.MIN_VALUE,0,Number.MIN_VALUE,3.999,4-Number.EPSILON*2,4,Number.MAX_VALUE,Infinity,NaN])
    for(const z of [-Infinity,-Number.MAX_VALUE,-4,-3.999,-3.2,0,3.2,3.999,4,Number.MAX_VALUE,Infinity,NaN])
      runPair(p(),[car('a',x,z)],10);
  for(const [x,z] of [[2.4,3.2],[-2.4,3.2],[2.4,-3.2],[3,4],[-4,0]])runPair(p(),[car('a',x,z)],10);
});

test('winner tie-break, eligibility, cooldown and refresh match exactly',()=>{
  const first=runPair(p(),[car('b',1,0),car('a',-1,0),car('denied',2,0)],20,['denied']);
  assert.equal(first.result,'a');assert.deepEqual(first.calls,['b','a','denied']);assert.equal(first.pad.readyAt,40);
  assert.equal(runPair(p(),[car('a',-1,0),car('b',1,0)],20).result,'a');
  assert.equal(runPair(first.pad,first.entities,39.999).result,null);
  assert.equal(runPair(first.pad,first.entities,40).result,'b');
});

test('eligibility callback mutations to later candidates are observed in order',()=>{
  const original=[car('a',0,0),car('b',20,0)];
  function exercise(fn:typeof baseline){
    const entities=structuredClone(original),pad=p(),calls:string[]=[];
    const result=fn(pad,entities,10,id=>{
      calls.push(id);
      if(id==='a'){entities[1].x=1;entities.push(car('c',-1,0));return false;}
      return true;
    });
    return {result,pad,entities,calls};
  }
  const base=exercise(baseline),next=exercise(candidate);
  assert.deepStrictEqual(next,base);assert.equal(base.result,'b');assert.deepEqual(base.calls,['a','b','c']);
});

test('unavailable pads and excluded bodies preserve scan semantics',()=>{
  const parked=car('parked',0,0);parked.driver=null;
  const airborne=car('airborne',0,0);airborne.supportId=null;
  const person=makeEntity('person','person',0,0,'person');
  const high=car('high',0,0);high.y=4;
  const full=car('full',0,0);full.air=100;full.upgrades.rocket=true;
  assert.equal(runPair(p(),[parked,airborne,person,high,full],1).result,null);
  const noTerrain={x:0,z:-500,active:true};const underwater=car('water',0,-500);
  assert.equal(runPair(noTerrain,[underwater],1).result,null);
});
