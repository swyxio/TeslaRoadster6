# Rocket pickup scan: isolated candidate at 38f56a0

This is an unshipped, diagnostic-only patch based on `38f56a0b082c46fc931735d560aedc3c2900a39a` (protocol 49). Its only runtime change is `shared/rocket.ts`: a finite-coordinate axis-distance rejection skips `Math.hypot` for cars definitely at least four metres from a pad. Nearby and non-finite coordinates still use the original `Math.hypot`, and selection, eligibility, lexicographic winner, cooldown and mutations remain unchanged. Baseline file SHA-256 is `7b1c931e0815b5ca0300794c14e786e5c5638fd874891b18fbd7fe863ce80ae9`; candidate file SHA-256 is `b5b75181e1cb50afe153d3020a05181bd23064bf894da4c1c54e08f49120433d`. Check the current target before applying. `pickup-optimization.patch` and `pickup-tests.patch` both passed a clean dry-run against the baseline. This package changes no production worktree and does not authorize deployment.

## Validation

- `evidence/focused-tests.log`: 17/17 pass. It combines original rocket and pickup identity tests with the new standalone integration test and a direct baseline-versus-candidate comparison. Coverage includes ±4 boundaries and adjacent representable values, diagonal boundaries, tiny/large finite values, NaN/infinities, eligibility-call order, equal-distance ID tie and reversed order, excluded/parked/flying/full vehicles, cooldown/reactivation, a callback denying one vehicle while moving another and appending a third, and full final mutation equality. `evidence/types.log` is the successful targeted TypeScript check.
- `evidence/parity-250.jsonl`: deterministic, seed-zero pure shared simulation with 64 normal default player cars, normal seeded ambient traffic and all pickups. Two separately cloned scenarios (normal city spawns and 64 preflighted static open-lane starts) were advanced 30 warmup ticks then 250 x 50 ms ticks. The complete world compared equal on every tick in both scenarios; 250-tick final hashes also match in every paired timing sample and CPU profile. No `EconomySession`, Worker, WebSocket, hosted runtime or durable writes were exercised. City only had 63/64 cars displace at least 1 m, and open-lane static samples do not prove continuously unobstructed paths. These are simulation parity and workload probes, not sustained playable occupancy.
- `evidence/bench-250.jsonl` stores all six alternating baseline/candidate CPU and wall-time pairs per scenario, total substeps, movement and hashes. Paired run was 02:24:30.575–02:24:50.997 UTC, 2026-10-19. On an 18-logical-CPU Mac the one-minute load rose 8.87→12.94 (five-minute 12.03→12.74, fifteen-minute 21.89→21.92). Median process CPU for 250 ticks was city 1,038.13→624.29 ms and lanes 555.63→276.71 ms; candidate was lower in all 12 pairs. Process CPU includes all process threads and GC, and host contention/JIT can skew results. The paired data supports an optimization candidate, not deployed throughput or causal proof for late inputs.
- `evidence/*cpuprofile` contains separate Node inspector profiles of the 250-tick phases; matching results and capture window are in `evidence/profile-250.jsonl`. `updateRocketPickup` had 65→14 sampled self hits in the city profiles and 49→14 in open lanes; sample totals and duration differ, and Node sampling includes runtime activity. These are local profiling leads, not Worker CPU, per-tick p95 or a normalized production contribution.

The existing archived distributed room runs had rejected inputs, missing complete movement coverage and no per-tick CPU attribution. This optimization may help simulation, but no end-to-end release gate has passed as a result. A matched representative isolated 64-driver room run, exact-frame ACK, complete contact/queue coverage, Worker identity/overhead and validated CPU evidence remain required.

## Reproduce in a disposable directory

Requires the exact commit and its locked dependencies, Node `v22.22.2`, pnpm `10.33.1`. Keep user/release worktrees unchanged. From this extracted package root:

```sh
mkdir -p base candidate
# Point REPO at a checkout holding the exact commit.
git -C "$REPO" archive 38f56a0 shared | tar -xf - -C base
git -C "$REPO" archive 38f56a0 shared src tests/rocket.test.ts tests/pickup-identity.test.ts | tar -xf - -C candidate
patch -d candidate -p1 < pickup-optimization.patch
patch -d candidate -p1 < pickup-tests.patch
# Install or link the exact checkout's locked node_modules at this package root.
pnpm exec tsx --test pickup-parity.test.ts candidate/tests/rocket-distance.test.ts candidate/tests/rocket.test.ts candidate/tests/pickup-identity.test.ts
pnpm exec tsc --noEmit --target ES2022 --module ESNext --moduleResolution Bundler --skipLibCheck --allowSyntheticDefaultImports --resolveJsonModule --types node candidate/shared/rocket.ts candidate/tests/rocket-distance.test.ts
PICKUP_TICKS=250 PICKUP_PAIRS=6 pnpm exec tsx simulation.ts parity
PICKUP_TICKS=250 PICKUP_PAIRS=6 pnpm exec tsx simulation.ts bench
PICKUP_TICKS=250 PICKUP_PAIRS=6 pnpm exec tsx simulation.ts profile
```

The profile command writes files into `evidence/`; preserve old raw files before rerunning. Record host context, coordinate the timing window and expect variable samples. `lanes.json` is the earlier 2 m sampled static corridor preflight, not proof of contact-free motion. No credentials or runtime state are included.
