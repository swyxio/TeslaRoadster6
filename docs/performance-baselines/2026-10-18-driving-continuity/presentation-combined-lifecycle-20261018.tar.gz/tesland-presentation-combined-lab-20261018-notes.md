# Combined presentation and entity-identity experiment

Status: experimental; do not merge or deploy. No performance, browser, network integration, or production claims. The driving-continuity and room-throughput release gates remain HOLD.

The patch and counts below describe the tested isolated snapshot. Functional tests and typechecking ran only after the independent timing reservation ended; they are not performance evidence.

Base: d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31.
Lab: /private/tmp/tesland-presentation-combined-lab-20261018.
Patch: /private/tmp/tesland-presentation-combined-lab-20261018.patch, SHA-256 9f6094a51e99f8a0922bb27b36a63be9ac2dfc975b9d149716937a7c2cffc195. The patch passes whitespace checking, applies with git apply to a clean base, and reproduces all 32 changed/new files byte-for-byte. It is uncommitted and has not been applied to the release checkout.

## Verification performed

The following focused combined unit suite passed 209/209. Its 1.8-second snapshot-burst case explicitly asserts disconnection; it is not a sustained-connection or release-gate pass. Output: /private/tmp/tesland-presentation-combined-lifecycle-final-suite-20261018.log.

    ./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/authoritative-relocation-lab.test.ts tests/market-hold.test.ts tests/remote-presentation.test.ts tests/snapshot.test.ts tests/no-spawn.test.ts tests/session.test.ts tests/tick-prediction.test.ts tests/session-motion.test.ts tests/motion-clock.test.ts tests/presentation-contact.test.ts tests/building-sweep-proofs.test.ts tests/building-sweep-lab.test.ts tests/presentation-roster-regression-lab.test.ts tests/scene-frozen-lab.test.ts tests/controls-lifecycle-lab.test.ts

    ./node_modules/.bin/tsc --noEmit

Client TypeScript passed; tracked diff and patch whitespace checks passed. An initial lifecycle run passed 207/208 and exposed an existing wallet-preservation assertion after fatal close; its output is retained at /private/tmp/tesland-presentation-combined-lifecycle-suite-20261018.log. The current code preserves the last validated wallet and the assertion now passes. These tests combine the contact lab's pinned-jump/wall and contact fixtures with the identity lab's authoritative relocation, short teleport, ID-reuse, prediction/control fence, snapshot parity, unattended ferry relocation, failed action and roster tests. They do not prove actual WebGL/scene behavior, relative dynamic swept-contact safety, physical-device behavior, room throughput, or protocol deployment. The protocol increases from v47 to v48: run the required live room and chat integrations and review reconnect/version-rollout behavior before any release.

## Preserved boundary history

The older building-sweep-lab assertion rejected an upright roadster moving from x=-351.2505 to -351.2504 by a wall whose west face is x=-349. This is 0.5 mm to 0.4 mm clearance. The newer preserved remote-path test requires acceptance of a 1 mm to 0.2 mm approach, which contains the older segment. The old expectation encoded the preceding conservative margin rather than physical penetration; after independent parent review it was updated to accept the separated approach. Existing crossing, rotation and initial-penetration checks were kept. New tests cover four wall faces at five yaws, tangency, crossing, starting penetration and opposite-side endpoints. The sweep SAT uses the same rectangle axes and projection radii as shared/physics.ts. Shared physics returns null for zero overlap; this sweep intentionally blocks tangency using 1e-9 m positive separation.

## Exhaustion finding and disconnected fallback

The pre-fallback Session regression /private/tmp/tesland-roster-before-disconnected-20261018.test.ts is preserved. In the prior combined code, its 18-snapshot, 1.8-second delayed burst moved a fast local car 94.7819765 m when a far new ambient entity appeared: exhausted history rejected the stale roster and returned latest authority as an online visual frame. The original unchanged-roster control held the old world. Its prior full-suite result was 196/197; that failure was reported to the parent when observed. The older wall-expectation failure was resolved separately as described above.

The exact pre-fallback source and failing regression are also preserved as /private/tmp/tesland-presentation-combined-before-freeze-20261018.patch (SHA-256 733b8d423f12675b1e3c8ea11804bde16db8fe6083f512f98f9b1658deddc8a6). It applies cleanly to d05d6f4 and was verified against all 29 component files. After applying to a disposable base checkout with the project's dependencies available, reproduce the old two-case test with `./node_modules/.bin/tsx --test --test-concurrency=1 tests/presentation-roster-regression-lab.test.ts`.

The new prototype detects bounded-history exhaustion, synchronously disconnects, detaches the socket before close, rejects queued packets and input, and keeps a latched presentationFrozen state. Unexpected closes, local fatal closes, stale input and queued packets are fenced synchronously; a shared six-second freshness check runs before control callbacks and sends. The main loop closes game dialogs while retaining identity/chat, draws the existing scene graph/camera without further updates behind a disconnected/rejoin message, then reinitializes meshes, camera and ferry from the first fresh room snapshot on a new connection. A connection generation allows controls to resume even when reconnection completes between animation frames. Unit tests cover the addition arriving on the exhausting snapshot, late messages and close events, jump/action rejection, new-room ID reuse, scene redraw without transform changes and fresh-scene reset. This is an explicit interruption and the 1.8-second burst still loses the driving connection. Live browser validation is required to establish the real overlay, the still-preserved identity/chat dialogs, WebGL redraw, camera/resize, input callbacks and reconnect behavior. The tests exercise control-generation logic and scene methods in isolation, not the real browser or full DOM lifecycle.

## Remaining safety and performance gaps

- Moving-ferry presentation mixes replay hull x/z with latest phase, remaining time and membership, and shifts current ferry-supported entities by the hull delta. Existing two-passenger coverage uses stationary deck riders; boarding, disembarking, independent passenger movement and GameScene smoothing are not proven coherent. A coherent frame through hull/passenger/shore interactions is still needed.
- The static building SAT proof does not prove relative swept paths of two moving peers, all 3-D/dome transitions, or safety after collisions and future roster changes. Endpoint contact checks alone cannot rule out cars crossing between frames. No distance-only exemption for a new entity has been justified.
- Playback retains up to 16 full structured-cloned worlds and allocates per-peer maps/sets; the added single-digit incarnation/revision keys cost approximately 53 uncompressed JSON bytes per entity in the earlier example. At 64 bodies allocation, CPU, network compression and throughput impact remain unmeasured. Do not infer capacity or a performance budget from functional tests or a contended host.
- No browser, load, build, live Wrangler integration, physical-device or deployed production verification was run for this combined patch. Final full pnpm test/build and independently collected paired browser and room throughput gate evidence remain necessary.
