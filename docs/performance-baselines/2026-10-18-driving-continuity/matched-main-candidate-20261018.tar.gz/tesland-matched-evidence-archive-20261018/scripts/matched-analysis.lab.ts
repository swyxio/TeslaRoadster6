import { readFileSync, writeFileSync } from 'node:fs';
import { body, contact } from '../shared/physics';
const dir='/private/tmp/tesland-matched-driving-20261018/evidence';
const load=(name:string)=>JSON.parse(readFileSync(`${dir}/${name}.json`,'utf8'));
const same=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b);
const distance=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
function metrics(trace:any){
  let maxStep=0,maxStepFrame=0,maxPeerStep=0,maxPeerStepFrame=0,depth=0,depthFrame=-1,maxAuthorityDepth=0,longest=0,current=0;
  let prev:any,priorPeer:any,firstImpact:number|null=null,largestBackward=0,backwardAt=-1;
  const snaps:number[]=[],statuses=new Set<string>(),localMissing:number[]=[],peerMissing:number[]=[],closed:number[]=[];
  for(const f of trace.frames){
    statuses.add(f.status);if(f.socketClosed)closed.push(f.frame);if(f.presentationSnapTaken)snaps.push(f.frame);
    const local=f.displayed.entities.find((e:any)=>e.driver==='p'),peer=f.displayed.entities.find((e:any)=>e.driver==='q');
    if(!local){localMissing.push(f.frame);continue;}
    const auth=f.authority.entities.find((e:any)=>e.driver==='p'),authPeer=f.authority.entities.find((e:any)=>e.driver==='q');
    if(firstImpact===null&&auth&&auth.health<100)firstImpact=f.frame;
    if(prev){const d=distance(local,prev);if(d>maxStep){maxStep=d;maxStepFrame=f.frame;}const back=prev.x-local.x;if(back>largestBackward){largestBackward=back;backwardAt=f.frame;}}
    if(trace.scenario==='peer-fifo'){
      if(!peer){peerMissing.push(f.frame);continue;}
      if(priorPeer){const d=distance(peer,priorPeer);if(d>maxPeerStep){maxPeerStep=d;maxPeerStepFrame=f.frame;}}
      const hit=contact(body(local),body(peer)),actual=auth&&authPeer?contact(body(auth),body(authPeer)):null;
      const penetration=hit?.depth??0;if(penetration>depth){depth=penetration;depthFrame=f.frame;}
      maxAuthorityDepth=Math.max(maxAuthorityDepth,actual?.depth??0);current=hit?current+1:0;longest=Math.max(longest,current);priorPeer=peer;
    }
    prev=local;
  }
  const last=trace.frames.at(-1);
  return {frameCount:trace.frames.length,statuses:[...statuses],closedCount:closed.length,firstClosed:closed[0]??null,
    localMissing,peerMissing,firstAuthorityImpactFrame:firstImpact,maxLocalStep:maxStep,maxLocalStepFrame:maxStepFrame,
    maxPeerStep,maxPeerStepFrame,maxBackwardX:largestBackward,backwardAt,maxDisplayedContactDepth:depth,depthFrame,
    maxAuthorityContactDepth:maxAuthorityDepth,longestDisplayedContactFrames:longest,snaps,
    finalStatus:last?.status,finalError:last?.error,localPresentationActiveFrames:trace.frames.filter((f:any)=>f.localPresentationActive).length};
}
const summary:any={};
for(const scenario of ['local','peer']){
  const fixture=load(`${scenario}-fixture`),cal=load(`${scenario}-calibration`),baseline=load(`${scenario}-baseline`),candidate=load(`${scenario}-candidate`);
  const n=baseline.frames.length;
  const mismatch=(key:string)=>baseline.frames.flatMap((f:any,i:number)=>same(f[key],candidate.frames[i]?.[key])?[]:[i]);
  const frameErrors=baseline.frames.flatMap((f:any,i:number)=>same(f,cal.frames[i])?[]:[i]);
  summary[scenario]={integrity:{frameCounts:[n,candidate.frames.length],calibrationVsBaselineFramesMismatch:frameErrors.slice(0,20),
    calibrationVsBaselineOutboundSame:same(cal.outbound,baseline.outbound),authorityMismatches:mismatch('authority').slice(0,20),
    inputMismatches:mismatch('input').slice(0,20),deliveryMismatches:mismatch('events').slice(0,20),
    receivedWorldMismatches:mismatch('lastReceived').slice(0,20),outboundSame:same(baseline.outbound,candidate.outbound),
    baselineProtocol:baseline.protocol,candidateProtocol:candidate.protocol,initialPacketLength:fixture.initialRaw.length,
    injectionCount:fixture.injected.length,authorityTicks:fixture.authority.length-1},
    baseline:metrics(baseline),candidate:metrics(candidate)};
  if(scenario==='local'){
    const p=(trace:any,i:number)=>trace.frames[i].displayed.entities.find((e:any)=>e.driver==='p');
    summary.local.lastGapFrame={baselineFrom:p(baseline,36),baselineTo:p(baseline,37),candidateFrom:p(candidate,36),candidateTo:p(candidate,37)};
  }
  const sent=(trace:any)=>trace.outbound.map((s:string)=>JSON.parse(s)).filter((v:any)=>v.type==='input');
  const bs=sent(baseline),cs=sent(candidate);let firstDiff=-1;
  for(let i=0;i<Math.max(bs.length,cs.length);i++)if(!same(bs[i],cs[i])){firstDiff=i;break;}
  summary[scenario].outboundInputs={counts:[bs.length,cs.length],firstDiff,firstBaseline:bs[firstDiff]??null,firstCandidate:cs[firstDiff]??null};
}
writeFileSync(`${dir}/comparison.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
