import json, sys
from pathlib import Path
original, replay = map(Path, sys.argv[1:])
failed = False
for case in ('local', 'peer'):
    for name in ('fixture', 'calibration', 'baseline', 'candidate', 'candidate-repeat'):
        expected = json.loads((original / f'{case}-{name}.json').read_text())
        observed = json.loads((replay / f'{case}-{name}.json').read_text())
        ok = expected == observed
        failed |= not ok
        print(f'{case}-{name}:', 'identical' if ok else 'DIFFERENT')
    if case == 'peer':
        expected = json.loads((original / f'{case}-candidate.json').read_text())
        instrumented = json.loads((replay / f'{case}-candidate-instrumented.json').read_text())
        ok = expected['frames'] == instrumented['frames'] and expected['outbound'] == instrumented['outbound']
        failed |= not ok
        print(f'{case}-instrumented frames/outbound:', 'identical' if ok else 'DIFFERENT')
if failed:
    raise SystemExit(1)
