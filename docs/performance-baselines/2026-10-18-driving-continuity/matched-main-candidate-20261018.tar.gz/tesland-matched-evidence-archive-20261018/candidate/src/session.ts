import { playtestMode } from '../shared/playtest';
import { MAX_PUBLIC_OVERFLOW, roomPath } from './room-address';
export { validRoom } from './room-address';
import type { VehicleId } from '../shared/vehicles';
import { NEUTRAL, PROTOCOL_VERSION, ROOM_FULL_CODE, ROOM_NO_SPAWN_CODE, createEmptyWorld, type World, type Input } from '../shared/game';
import type { UpgradeId } from '../shared/upgrades';
import type { PaintId, StyleChoice } from '../shared/vehicle-style';
import type { CybercabFleet } from '../shared/cybercabs';
import type { AchievementId } from '../shared/achievements';
import { isAchievementTierProgress, type AchievementTierProgress } from '../shared/achievement-tiers';
import { isVehicleCollections, type VehicleCollections } from '../shared/vehicle-collections';
import type { LuxuryVehicleId } from '../shared/luxury';
import { TickPrediction } from './tick-prediction';
import { MotionClock } from './motion-clock';
import { RemotePresentation } from './remote-presentation';
import { validStarshipStatus, validStarshipTime, type StarshipRoomStatus } from './starship-model';
import type { EarningsBonusView } from './earnings-bonus-ui';
import type { MarketRequest, MarketResultView, MarketState } from '../shared/market-protocol';
import type { DriveMode } from '../shared/drive-mode';
import type { DeliveryReward } from '../shared/delivery';
type MarketClientRequest<T=MarketRequest> = T extends MarketRequest ? Omit<T,'type'|'requestId'> : never;
export const DEFAULT_ROOM = 'bay';
export type SessionStatus = 'connecting' | 'online' | 'disconnected';
export type WalletStatus = 'guest' | 'connecting' | 'syncing' | 'ready' | 'failed';
const WALLET_TIMEOUT_MS=15_000;
const NETWORK_ERROR='Could not reach the room server. Try again or choose another room.';
export type WalletView = {cash:number;earned:number;eligibleIncome:number;level:number;unlocked:AchievementId[];achievementTiers:AchievementTierProgress;vehicleCollections:VehicleCollections;ownedLuxury:LuxuryVehicleId[];cybercabs:CybercabFleet};
export type LuxuryResult = {requestId:number;action:'buy'|'collect';vehicle:LuxuryVehicleId;ok:boolean;reason?:string;awards?:AchievementId[]};
export class Session {
  world: World = createEmptyWorld();
  id = '';
  status: SessionStatus = 'disconnected';
  capacity = 0;
  snapshotVersion = 0;
  connectionGeneration = 0;
  walletStatus:WalletStatus = 'guest';
  walletError = '';
  private socket?: WebSocket;
  private connectTimeout?: number;
  private walletTimeout?: number;
  private walletSnapshot=0;
  private startingVehicle?:VehicleId;
  private sendTime = 0;
  private lastState = 0;
  private name = 'Driver';
  private identityCode?: string;
  private identityRequestId = 0;
  private rewardId=0;
  private rewards:DeliveryReward[]=[];
  private nextUpgradeRequest = 0;
  private inputSeq = 0;
  private actionSeq = 0;
  private syncToken = 0;
  private edgeQueue:{kind:'jump'|'flip';id:number;at:number;revision:number}[]=[];
  private sentEdges:Pick<Input,'jump'|'flip'>={jump:0,flip:0};
  droppedInputEdges=0;
  private lastInput:Input = {...NEUTRAL};
  private pendingVehicle?: {kind:VehicleId;previousId:string|undefined;token:number};
  private prediction = new TickPrediction();
  private clock = new MotionClock();
  private remote = new RemotePresentation();
  localPresentationActive=false;
  remotePresentationActive=false;
  private roomEpoch = '';
  private controlRevision = 0;
  private lastTargetTick = 0;
  private lastSentInput:Input|null = null;
  private lastSentAt = -Infinity;
  private sentAt = new Map<number,number>();
  upgradeResult: {requestId:number;upgrade:UpgradeId;ok:boolean}|null = null;
  vehicleStyleResult: ({requestId:number;ok:boolean}&StyleChoice)|null = null;
  otaResult: {requestId:number;enabled:boolean;ok:boolean}|null = null;
  destinationResult: {requestId:number;ok:boolean}|null = null;
  marsResult: {requestId:number;action:'board'|'contribute';ok:boolean;amount:number;available?:number}|null = null;
  starshipStatus:StarshipRoomStatus|null = null;
  starshipContextVersion=0;
  starshipNameResult:{requestId:number;ok:boolean;publicName:string|null}|null = null;
  earningsBonus:EarningsBonusView|null = null;
  private starshipStatusRequest=0;
  identityResult: {requestId:number;ok:boolean;message:string;levelBaseline:{level:number;eligibleIncome:number;afterSnapshot:number}|null}|null = null;
  wallet: WalletView|null = null;
  luxuryResult: LuxuryResult|null = null;
  cabBuyResult: {requestId:number;action:'buy';ok:boolean;reason?:string}|null = null;
  cabPaintResult: {requestId:number;action:'paint';assetId:string;paint:PaintId;ok:boolean;reason?:string}|null = null;
  marketState:MarketState|null=null;
  marketResult:MarketResultView|null=null;
  vehicleResult: {kind:VehicleId;ok:boolean}|null = null;
  error = '';
  room = '';
  roomFull = false;
  findingRoom = false;
  onRoomJoined?: (room:string)=>void;
  constructor(private now:()=>number=()=>performance.now(),private edgeCounters?:()=>Pick<Input,'jump'|'flip'>) {}
  get playtest(){return playtestMode(this.room);}
  get sandbox(){return this.playtest==='sandbox';}
  teleportResult:{requestId:number;ok:boolean}|null=null;
  get walletBlocked():boolean {return this.walletStatus==='connecting'||this.walletStatus==='syncing'||this.walletStatus==='failed';}
  private waitForWallet(requestId:number):void {
    clearTimeout(this.walletTimeout);this.walletStatus='connecting';this.walletError='';this.prediction.reset();
    this.droppedInputEdges+=this.edgeQueue.length;this.edgeQueue=[];this.lastSentInput=null;this.lastTargetTick=0;
    this.walletTimeout=window.setTimeout(()=>{
      if(this.identityRequestId!==requestId||!this.walletBlocked)return;
      this.walletStatus='failed';this.walletError='Your saved driver is taking too long to connect.';
      this.error=this.walletError;this.socket?.close();
    },WALLET_TIMEOUT_MS);
  }
  join(room: string, name: string,kind?:VehicleId,automatic=false) {
    if (this.status === 'online' && this.room === room) {
      this.setName(name);
      const player = this.world.players.find(player => player.id === this.id);
      const vehicle = this.world.entities.find(entity => entity.id === player?.entityId);
      if (kind && (vehicle?.kind !== kind || vehicle.owner !== this.id)) this.selectVehicle(kind);
      return;
    }
    kind ??= 'roadster';
    automatic=automatic&&room===DEFAULT_ROOM;
    this.connectionGeneration++;
    this.name = name;
    this.disconnect(); this.room = room; this.roomFull = false; this.status = 'connecting'; this.error = ''; this.id = ''; this.capacity = 0;this.snapshotVersion=0;this.walletStatus=this.identityCode&&!this.playtest?'connecting':'guest';this.walletError='';this.startingVehicle=undefined; this.sendTime = 0; this.upgradeResult=null;this.vehicleStyleResult=null;this.otaResult=null;this.destinationResult=null;this.marsResult=null;this.identityResult=null;this.wallet=null;this.luxuryResult=null;this.cabBuyResult=null;this.cabPaintResult=null;this.world = createEmptyWorld();
    const deadline=this.now()+20_000;
    let candidate=0;
    this.findingRoom=automatic;
    const connect=(target:string)=>{
    this.room=target;
    const socket = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}${roomPath(target)}`);
    this.socket = socket;
    const timeout = window.setTimeout(() => { if (this.socket === socket && this.status === 'connecting') { this.error = 'Connection timed out. Try again or choose another room.'; socket.close(); } }, Math.max(0,Math.min(10_000,deadline-this.now())));
    this.connectTimeout=timeout;
    socket.onmessage = event => {
      if (this.socket !== socket) return;
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'welcome') {
          if (message.version !== PROTOCOL_VERSION) { this.error = 'Game updated. Reload to reconnect.'; socket.close(); return; }
          if(typeof message.roomEpoch!=='string'||!Number.isSafeInteger(message.tick)||!Number.isSafeInteger(message.poseRevision))throw new Error('Invalid room clock');
          this.id = message.id; this.capacity = message.capacity; this.roomEpoch=message.roomEpoch;this.lastState = this.now();this.findingRoom=false;this.onRoomJoined?.(target);
          socket.send(JSON.stringify({type:'name',name:this.name}));
          if(!this.identityRequestId)this.identityRequestId=++this.nextUpgradeRequest;
          if(this.identityCode&&!this.playtest)this.waitForWallet(this.identityRequestId);
          socket.send(JSON.stringify({type:'identity',code:this.playtest?null:this.identityCode??null,requestId:this.identityRequestId}));
          if(kind!=='roadster'){if(this.walletBlocked)this.startingVehicle=kind;else this.actionWithBarrier({type:'selectVehicle',kind});}
        }
        if (message.type === 'state' && this.id) {
          const now=this.now();
          if(message.roomEpoch!==this.roomEpoch||!message.control||!Number.isSafeInteger(message.control.revision)||
             !Number.isSafeInteger(message.control.receivedSeq)||!Number.isSafeInteger(message.control.actionSeq)||
             !Number.isSafeInteger(message.control.edgeFloorRevision)||!Number.isSafeInteger(message.poseRevision)||
             !Number.isInteger(message.substeps)||message.substeps<1||message.substeps>8||
             !this.clock.observe(message.tick,now))throw new Error('Invalid room state');
          const sent=this.sentAt.get(message.control.receivedSeq);
          if(sent!==undefined)this.clock.observeTurnaround(now-sent);
          for(const seq of this.sentAt.keys())if(seq<=message.control.receivedSeq)this.sentAt.delete(seq);
          // A spontaneous relocation invalidates even presses captured before
          // its snapshot arrived. Explicit actions leave this floor unchanged.
          const queued=this.edgeQueue.length;
          this.edgeQueue=this.edgeQueue.filter(edge=>edge.revision>=message.control.edgeFloorRevision);
          this.droppedInputEdges+=queued-this.edgeQueue.length;
          if(message.control.revision!==this.controlRevision){this.controlRevision=message.control.revision;this.lastTargetTick=0;this.lastSentInput=null;}
          this.world = message.world;this.snapshotVersion++; this.status = 'online'; this.lastState = now; clearTimeout(timeout);if(this.connectTimeout===timeout)this.connectTimeout=undefined;
          // This is also the radius used for peer physics in local replay.
          // Keep one fast timeline when a body may enter that contact region.
          const controlled=this.world.entities.find(entity=>entity.driver===this.id);
          this.clock.prioritizeContacts(!controlled||this.world.entities.some(entity=>entity.id!==controlled.id&&
            Math.hypot(entity.x-controlled.x,entity.z-controlled.z)<160));
          if(this.walletStatus==='syncing'&&this.snapshotVersion>this.walletSnapshot){
            this.walletStatus='ready';clearTimeout(this.walletTimeout);this.walletTimeout=undefined;
            // Discard presses from before/during recovery; start at the server's
            // observed edge counters so they cannot be replayed after binding.
            this.sentEdges={jump:message.control.jump.seen,flip:message.control.flip.seen};
            this.lastSentInput=null;
          }
          this.remote.snapshot(this.world,this.id,message.tick);
          this.prediction.snapshot(this.world,this.id,message.tick,message.control,message.poseRevision,message.substeps,this.lastState);
          if(!this.walletBlocked&&this.startingVehicle){const starting=this.startingVehicle;this.startingVehicle=undefined;this.actionWithBarrier({type:'selectVehicle',kind:starting});}
          if(this.pendingVehicle&&Number.isSafeInteger(message.sync)&&message.sync>=this.pendingVehicle.token){
            const {kind,previousId}=this.pendingVehicle;
            const player=this.world.players.find(player=>player.id===this.id);
            const vehicle=this.world.entities.find(entity=>entity.id===player?.entityId);
            this.vehicleResult={kind,ok:vehicle?.kind===kind&&vehicle.owner===this.id&&vehicle.id!==previousId};
            this.pendingVehicle=undefined;
          }
        }
        // Rejected controls retry on the regular heartbeat. Forcing an early
        // unchanged send for every rejection can amplify a delayed connection.
        if(message.type==='inputRejected'&&Number.isSafeInteger(message.seq))this.prediction.reject(message.seq,message.reason);
        if(message.type==='inputEdge'&&(message.kind==='jump'||message.kind==='flip')&&Number.isSafeInteger(message.id)&&
          Number.isSafeInteger(message.targetTick)&&['accepted','rescheduled','processed','expired','superseded'].includes(message.status))
          this.prediction.edgeOutcome(message.kind,message.id,message.status,message.targetTick);
        if (message.type === 'identityResult' && message.requestId===this.identityRequestId && this.walletStatus!=='failed' && !this.playtest) {
          const levelBaseline=message.ok&&this.identityCode&&this.wallet?{level:this.wallet.level,eligibleIncome:this.wallet.eligibleIncome,afterSnapshot:this.snapshotVersion}:null;
          this.identityResult={requestId:message.requestId,ok:message.ok,message:message.message,levelBaseline};
          if(this.identityCode){
            if(message.ok){this.walletStatus='syncing';this.walletSnapshot=this.snapshotVersion;}
            else{clearTimeout(this.walletTimeout);this.walletTimeout=undefined;this.walletStatus='failed';this.walletError=message.message;}
          }
        }
        if (message.type === 'wallet') {
          if(!isAchievementTierProgress(message.achievementTiers))throw new Error('Invalid achievement tier progress');
          if(!isVehicleCollections(message.vehicleCollections))throw new Error('Invalid vehicle collection progress');
          this.wallet = message;
        }
        if(message.type==='reward'){
          const reward=message.reward as DeliveryReward;
          if(!reward||!Number.isSafeInteger(reward.id)||reward.id<1||!Number.isSafeInteger(reward.amount)||reward.amount<1||
             !['pickup','delivery','pickup-research','delivery-research','supply-repair','supply-air','research'].includes(reward.kind))throw new Error('Invalid reward');
          if(reward.id>this.rewardId){this.rewardId=reward.id;this.rewards.push(reward);}
        }
        if (message.type === 'luxuryResult') this.luxuryResult = message;
        if (message.type === 'cabResult' && message.action === 'buy') this.cabBuyResult = message;
        if (message.type === 'cabResult' && message.action === 'paint') this.cabPaintResult = message;
        if (message.type === 'marketState'&&Number.isSafeInteger(message.requestId)&&Array.isArray(message.listings)&&Array.isArray(message.owned)&&Array.isArray(message.shop))this.marketState=message;
        if (message.type === 'marketResult'&&Number.isSafeInteger(message.requestId)&&typeof message.operationId==='string'&&['not-found','pending','completed','rejected'].includes(message.status))this.marketResult=message;
        if (message.type === 'vehicleStyleResult') this.vehicleStyleResult = message;
        if (message.type === 'upgradeResult') this.upgradeResult = message;
        if (message.type === 'otaResult') this.otaResult = message;
        if (message.type === 'teleportResult') this.teleportResult=message;
        if (message.type === 'destinationResult') this.destinationResult = message;
        if (message.type === 'marsResult') this.marsResult = message;
        if(message.type==='starshipStatus'&&message.requestId===this.starshipStatusRequest&&
          validStarshipStatus(message.status)&&validStarshipTime(message.serverTime)&&
          (message.publicName===null||typeof message.publicName==='string')&&typeof message.privacyPending==='boolean'){
          this.starshipStatus={status:message.status,publicName:message.publicName,privacyPending:message.privacyPending,serverTime:message.serverTime,receivedAt:this.now()};
        }
        if(message.type==='starshipNameResult'&&Number.isSafeInteger(message.requestId)&&typeof message.ok==='boolean'&&
          (message.publicName===null||typeof message.publicName==='string'))this.starshipNameResult=message;
        if(message.type==='earningsStatus'){
          if(message.events&&Array.isArray(message.events.room)&&Array.isArray(message.events.global)&&
             validStarshipTime(message.serverTime)&&Number.isSafeInteger(message.validForMs)&&message.validForMs>0)
            this.earningsBonus={events:message.events,serverTime:message.serverTime,validForMs:message.validForMs,receivedAt:this.now()};
          else this.earningsBonus=null;
        }
      } catch (error) { console.error('Room message processing failed:',error);this.error = 'Invalid server message. Please reconnect.'; socket.close(); }
    };
    socket.onclose = event => {
      clearTimeout(timeout);if(this.connectTimeout===timeout)this.connectTimeout=undefined;
      if(this.socket!==socket)return;
      if(automatic&&!this.id&&(!this.error||this.error===NETWORK_ERROR)&&event.code===ROOM_FULL_CODE&&candidate<MAX_PUBLIC_OVERFLOW&&this.now()<deadline){
        this.error='';candidate++;console.info('Public Bay full; trying next room.',{candidate});connect(`public:${candidate}`);return;
      }
      clearTimeout(this.walletTimeout);this.walletTimeout=undefined;this.prediction.reset();this.status='disconnected';this.findingRoom=false;this.starshipStatus=null;this.starshipNameResult=null;this.starshipStatusRequest=0;this.earningsBonus=null;
      if(event.code===ROOM_FULL_CODE&&(!this.error||this.error===NETWORK_ERROR)){
        this.roomFull=true;
        this.error=automatic&&!this.id?'The Bay is busy. Try again or choose another room.':'This room is full. Try again or choose another room.';
        if(automatic&&!this.id)console.warn('Public Bay placement exhausted.',{candidates:candidate+1});
      } else if(event.code===ROOM_NO_SPAWN_CODE)this.error='No safe starting space is available right now. Try again or choose another room.';
      else if((event.code===1011||event.code===1008)&&['Award could not be saved. Rejoin.','Wallet delayed. Rejoin to recover.','Economy interrupted. Rejoin to recover.','Property not found. Return to Bay.','Property service unavailable. Retry or return to Bay.'].includes(event.reason))this.error=event.reason;
      else this.error ||= 'Room disconnected. Rejoin or choose another room.';
    };
    socket.onerror = () => { if(this.socket === socket) this.error ||= NETWORK_ERROR; };
    };
    connect(room);
  }
  queueEdge(kind:'jump'|'flip',id:number) {
    if(this.status!=='online'||this.walletBlocked)return;
    // A bounded queue preserves distinct presses; never replay an old press
    // after a long interruption or let bursts grow without bound.
    if(this.edgeQueue.length>=16){this.droppedInputEdges++;return;}
    this.edgeQueue.push({kind,id,at:this.now(),revision:this.controlRevision});
  }
  takeRewards():DeliveryReward[] {return this.walletBlocked?[]:this.rewards.splice(0);}
  tick(dt: number, input: Input) {
    this.lastInput={...input};
    if (this.status === 'online') {
      const now=this.now();
      if (now - this.lastState > 6000) { this.error = 'Connection stalled. Rejoin to continue.'; this.socket?.close(); return; }
      if(this.walletBlocked)return;
      this.sendTime += dt;
      while(this.edgeQueue.length&&now-this.edgeQueue[0].at>300){this.edgeQueue.shift();this.droppedInputEdges++;}
      const edge=this.edgeQueue[0];
      // Counters advance only as their actual press events are sent. Reading
      // the latest counters here would silently collapse rapid presses.
      const outgoing={...input,...this.sentEdges,...(edge?{[edge.kind]:edge.id}:{})};
      const before=this.lastSentInput;
      const changed=!before||Object.keys(outgoing).some(key=>outgoing[key as keyof Input]!==before[key as keyof Input]);
      if ((this.sendTime >= .05 || changed || edge) && now-this.lastSentAt>=20) {
        if(!this.sendInput(outgoing,now))return;
        if(edge){this.edgeQueue.shift();this.sentEdges[edge.kind]=edge.id;}
        // Preserve the frame's fractional remainder so a 60 Hz render loop
        // does not quantize a 20 Hz input stream down to roughly 15 Hz.
        // Missed intervals are dropped, not burst-sent after a slow frame.
        this.sendTime %= .05;
      }
    }
  }
  renderWorld():World {
    this.localPresentationActive=false;this.remotePresentationActive=false;
    if(this.status!=='online'||this.walletBlocked)return this.world;
    const now=this.now(),display=this.remote.render(this.world,this.id,this.clock.remote(now));
    // With only one snapshot the remote buffer holds its last known poses;
    // the scene and local collision checks must use those same held poses.
    this.remotePresentationActive=true;
    const predicted=this.prediction.renderWorld(now,this.clock.target(now),this.clock.estimate(now),this.clock.alpha(now),display,this.remote.ready);
    this.localPresentationActive=!!predicted;
    if(predicted)return predicted;
    // Ferry passengers share the authoritative deck while shore traffic plays
    // back normally. Other unsafe replay states must keep every car on one
    // authoritative frame. Keep remotePresentationActive so the scene does not
    // extrapolate those peers away from it.
    const onFerry=this.world.entities.some(entity=>entity.driver===this.id&&entity.supportId==='ferry');
    return onFerry?display:this.world;
  }
  takePresentationSnap():boolean {return this.prediction.takeSnap();}
  takeCameraSnap():boolean {return this.prediction.takeCameraSnap();}
  selectVehicle(kind:VehicleId){
    this.vehicleResult=null;
    const player=this.world.players.find(player=>player.id===this.id);
    if(this.status==='online'&&this.actionWithBarrier({type:'selectVehicle',kind})){
      this.pendingVehicle={kind,previousId:player?.entityId,token:this.syncToken};
    }else this.vehicleResult={kind,ok:false};
  }
  parkingAction(action:'park'|'queue'|'start'|'leave'){this.actionWithBarrier({type:'parking',action},false);}
  raceAction(action:'join'|'start'|'leave',courseId:'short'|'oval'){this.actionWithBarrier({type:'race',action,courseId},action==='join');}
  enterMinigame(game:'park'|'queue'|'short'|'oval'){if(this.status!=='online'||!this.actionWithBarrier({type:'minigame',game}))return false;}
  setDestination(x:number,z:number,mode:DriveMode='road'){
    const requestId=++this.nextUpgradeRequest;this.destinationResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'destination',x,z,mode,requestId}))this.destinationResult={requestId,ok:false};
    return requestId;
  }
  setDeliveryDestination(mode:DriveMode='road'){
    const requestId=++this.nextUpgradeRequest;this.destinationResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'deliveryDestination',mode,requestId}))this.destinationResult={requestId,ok:false};
    return requestId;
  }
  setName(name:string) {
    this.name = name;
    if (this.id) this.send({type:'name',name});
  }
  /** Recovery codes are sent only to the room and never added to snapshots. */
  setIdentity(code?:string) {
    // Chat can reconnect independently of the room. Rebinding the same
    // in-flight or confirmed driver would suspend an active route for no
    // reason; a new room still sends its own identity on welcome.
    if(code&&code===this.identityCode&&this.id&&this.socket?.readyState===WebSocket.OPEN&&this.walletStatus!=='failed')return this.identityRequestId;
    const requestId=++this.nextUpgradeRequest;
    this.rewards=[];
    this.starshipContextVersion++;
    this.starshipStatus=null;this.starshipNameResult=null;this.starshipStatusRequest=0;this.earningsBonus=null;
    this.identityCode=code;this.identityRequestId=requestId;this.identityResult=null;
    if(!this.playtest&&this.id&&this.socket?.readyState===WebSocket.OPEN){
      if(code)this.waitForWallet(requestId);
      else if(this.walletStatus!=='guest'){clearTimeout(this.walletTimeout);this.walletTimeout=undefined;this.walletStatus='failed';this.walletError='Rejoin to start a new guest driver.';}
      this.send({type:'identity',code:code??null,requestId});
    }
    return requestId;
  }
  luxury(action:'buy'|'collect',vehicle:LuxuryVehicleId) {
    const requestId=++this.nextUpgradeRequest;this.luxuryResult=null;
    const message={type:'luxury',action,vehicle,requestId};
    const sent=this.status==='online'&&!this.walletBlocked&&(action==='collect'?this.actionWithBarrier(message):this.send(message));
    if(!sent)this.luxuryResult={requestId,action,vehicle,ok:false,reason:'Connection lost. Rejoin and try again.'};
    return requestId;
  }
  buyCab():number|null {
    const requestId=++this.nextUpgradeRequest;this.cabBuyResult=null;
    return this.status==='online'&&this.walletStatus==='ready'&&this.send({type:'cab',action:'buy',requestId})?requestId:null;
  }
  paintCab(assetId:string,paint:PaintId):number|null {
    const requestId=++this.nextUpgradeRequest;this.cabPaintResult=null;
    return this.status==='online'&&this.walletStatus==='ready'&&this.send({type:'cab',action:'paint',assetId,paint,requestId})?requestId:null;
  }
  market(request:MarketClientRequest):number|null {
    const requestId=++this.nextUpgradeRequest;
    if(this.status!=='online'||this.walletStatus!=='ready')return null;
    try{return this.send({type:'market',...request,requestId})?requestId:null;}catch{return null;}
  }
  teleport(x:number,z:number){
    const requestId=++this.nextUpgradeRequest;this.teleportResult=null;
    if(!this.sandbox||!this.actionWithBarrier({type:'teleport',x,z,requestId}))this.teleportResult={requestId,ok:false};
    return requestId;
  }
  buyUpgrade(upgrade:UpgradeId){
    const requestId=++this.nextUpgradeRequest;this.upgradeResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'upgrade',upgrade,requestId},false))this.upgradeResult={requestId,upgrade,ok:false};
    return requestId;
  }
  buyVehicleStyle(selection:StyleChoice){
    const requestId=++this.nextUpgradeRequest;this.vehicleStyleResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'vehicleStyle',...selection,requestId},false))this.vehicleStyleResult={requestId,...selection,ok:false};
    return requestId;
  }
  mars(){
    const requestId=++this.nextUpgradeRequest;this.marsResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'mars',action:'board',requestId},false))this.marsResult={requestId,action:'board',ok:false,amount:0};
    return requestId;
  }
  contributeMars(amount:number){
    const requestId=++this.nextUpgradeRequest;this.marsResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'mars',action:'contribute',amount,requestId},false))this.marsResult={requestId,action:'contribute',ok:false,amount:0};
    return requestId;
  }
  requestStarshipStatus():boolean {
    if(this.status!=='online'||this.walletBlocked)return false;
    const requestId=++this.nextUpgradeRequest;
    if(!this.send({type:'starship',action:'status',requestId}))return false;
    this.starshipStatusRequest=requestId;return true;
  }
  setStarshipName(name:string|null):number {
    const requestId=++this.nextUpgradeRequest;this.starshipNameResult=null;
    this.starshipStatusRequest=0;
    if(this.status!=='online'||this.walletBlocked||!this.send({type:'starship',action:'name',name,requestId}))
      this.starshipNameResult={requestId,ok:false,publicName:null};
    return requestId;
  }
  setOta(enabled:boolean){
    const requestId=++this.nextUpgradeRequest;this.otaResult=null;
    if(this.status!=='online'||!this.actionWithBarrier({type:'ota',enabled,requestId},false))this.otaResult={requestId,enabled,ok:false};
    return requestId;
  }
  action(type: 'interact' | 'reset' | 'autopilot' | 'dome') {
    this.actionWithBarrier({type});
  }
  private actionWithBarrier(value:Record<string,unknown>,invalidates=true):boolean {
    if(this.walletBlocked)return false;
    // The baseline is captured at the action itself, including gamepad
    // actions fired during Controls.read(), without an extra simulation frame.
    const actionSeq=this.actionSeq+1;
    const action=invalidates?{...value,actionSeq,edgeBaseline:this.edgeCounters?.()??{jump:this.lastInput.jump,flip:this.lastInput.flip}}:value;
    if(!this.send(action))return false;
    if(invalidates)this.actionSeq=actionSeq;
    const token=++this.syncToken;
    return this.send({type:'sync',token});
  }
  private sendInput(input:Input,now:number):boolean {
    const estimated=this.clock.inputTarget(now);
    if(estimated===null)return false;
    const targetTick=Math.max(this.lastTargetTick,estimated),seq=this.inputSeq+1;
    const command={seq,targetTick,controlRevision:this.controlRevision,actionSeq:this.actionSeq,input:{...input}};
    if(!this.send({type:'input',...command,roomEpoch:this.roomEpoch}))return false;
    this.inputSeq=seq;this.lastTargetTick=targetTick;this.lastSentInput={...input};this.lastSentAt=now;
    this.sentAt.set(seq,now);if(this.sentAt.size>64)this.sentAt.delete(this.sentAt.keys().next().value!);
    this.prediction.input(command,this.clock.target(now)??targetTick);return true;
  }
  private send(value: unknown):boolean { if (this.socket?.readyState !== WebSocket.OPEN)return false;this.socket.send(JSON.stringify(value));return true; }
  disconnect() { this.findingRoom=false;const socket = this.socket; this.socket = undefined;clearTimeout(this.connectTimeout);this.connectTimeout=undefined;clearTimeout(this.walletTimeout);this.walletTimeout=undefined; socket?.close(); this.prediction.reset();this.clock.reset();this.remote.reset();this.localPresentationActive=false;this.remotePresentationActive=false;this.roomEpoch='';this.controlRevision=0;this.lastTargetTick=0;this.lastSentInput=null;this.lastInput={...NEUTRAL};this.lastSentAt=-Infinity;this.sentAt.clear();this.inputSeq=0;this.actionSeq=0;this.syncToken=0;this.edgeQueue=[];this.sentEdges={jump:0,flip:0};this.droppedInputEdges=0;this.rewardId=0;this.rewards=[];this.pendingVehicle=undefined;this.startingVehicle=undefined;this.vehicleResult=null;this.wallet=null;this.luxuryResult=null;this.marketState=null;this.marketResult=null;this.starshipStatus=null;this.starshipNameResult=null;this.starshipStatusRequest=0;this.starshipContextVersion++;this.earningsBonus=null;this.sendTime=0;this.status='disconnected'; }
}
