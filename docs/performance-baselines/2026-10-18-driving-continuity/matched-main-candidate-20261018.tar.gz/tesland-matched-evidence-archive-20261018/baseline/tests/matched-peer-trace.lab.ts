import { writeFileSync, readFileSync } from 'node:fs';
import { addPlayer, createEmptyWorld, NEUTRAL, PROTOCOL_VERSION, step, type World } from '../shared/game';
import { ScheduledInput } from '../shared/tick-input';
import { Session } from '../src/session';

class Socket {
  static OPEN=1;static last:Socket;readyState=Socket.OPEN;sent:string[]=[];closed=false;
  onmessage?:(event:{data:string})=>void;onclose?:(event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}
  send(value:string){this.sent.push(value);}
  close(){this.readyState=3;this.closed=true;}
  messageRaw(data:string){this.onmessage?.({data});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});
const clone=<T>(value:T):T=>JSON.parse(JSON.stringify(value));
type Event={at:number;raw:string};
type Plan={frame:number;now:number;authorityTick:number;tickSession:boolean;events:Event[]};
type Fixture={scenario:string;input:typeof NEUTRAL;welcome:Record<string,unknown>;initialRaw:string;clockTurnaround:number|null;
  plans:Plan[];authority:World[];authorityTickTimes:number[];injected:{frame:number;at:number;tick:number}[]};
const [mode,scenario,fixturePath,outputPath]=process.argv.slice(2);
if(!['generate','replay'].includes(mode)||!['local-gap','peer-fifo'].includes(scenario))throw new Error('usage: generate|replay local-gap|peer-fifo fixture.json trace.json');
let now=0;const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
const welcome={type:'welcome',id:'p',capacity:64,roomEpoch:'room',tick:0,poseRevision:0};
socket.messageRaw(JSON.stringify({...welcome,version:PROTOCOL_VERSION}));
const frames:unknown[]=[];let sentIndex=0;
function sample(plan:Plan,authority:World,shown:World,snap:boolean|null){
  const clock=Reflect.get(session,'clock');
  const prediction=Reflect.get(session,'prediction');
  frames.push({frame:plan.frame,now:plan.now,authorityTick:plan.authorityTick,events:plan.events.map(event=>({at:event.at,tick:JSON.parse(event.raw).tick})),
    authority:clone(authority),lastReceived:clone(session.world),displayed:clone(shown),input:clone(input),
    status:session.status,error:session.error,socketClosed:socket.closed,localPresentationActive:session.localPresentationActive,
    remotePresentationActive:session.remotePresentationActive,presentationHistoryExhausted:Reflect.get(session,'presentationHistoryExhausted')??null,
    presentationSnapTaken:snap,pendingSnap:Reflect.get(prediction,'snap')??null,cameraSnap:Reflect.get(prediction,'cameraSnap')??null,
    clock:clone(clock),outbound:socket.sent.slice(sentIndex).map(value=>JSON.parse(value))});
  sentIndex=socket.sent.length;
}
let input={...NEUTRAL,throttle:1,boost:scenario==='local-gap'};
const output:{scenario:string;mode:string;protocol:number;frames:unknown[];outbound:string[];metadata:Record<string,unknown>}={scenario,mode,protocol:PROTOCOL_VERSION,frames,outbound:[],metadata:{}};
if(mode==='generate'){
  const world=createEmptyWorld();addPlayer(world,'p','Player');if(scenario==='peer-fifo')addPlayer(world,'q','Other');
  const local=world.entities.find(entity=>entity.driver==='p')!;
  const peer=world.entities.find(entity=>entity.driver==='q');world.entities=peer?[local,peer]:[local];world.pickups=[];
  Object.assign(local,{x:scenario==='local-gap'?-300:-400,z:-2050,y:0,yaw:-Math.PI/2,speed:scenario==='local-gap'?72:50,vx:scenario==='local-gap'?72:50,vz:0,supportId:'ground'});
  if(peer)Object.assign(peer,{x:-180,z:-2050,y:0,yaw:Math.PI/2,speed:50,vx:-50,vz:0,supportId:'ground'});
  const control=new ScheduledInput(input).snapshot();control.heldUntilTick=10000;
  const packet=(tick:number)=>JSON.stringify({type:'state',world:clone(world),roomEpoch:'room',tick,control:clone(control),poseRevision:0,substeps:5});
  const initialRaw=packet(0);socket.messageRaw(initialRaw);
  const clockTurnaround=scenario==='peer-fifo'?350:null;
  if(clockTurnaround!==null)Reflect.get(session,'clock').observeTurnaround(clockTurnaround);
  const plans:Plan[]=[],authority:World[]=[clone(world)],authorityTickTimes:number[]=[0],injected:Fixture['injected']=[];
  let tick=0,lastRelease=0;const pending:{at:number;raw:string}[]=[];
  const end=scenario==='local-gap'?37:480;
  for(let frame=0;frame<=end;frame++){
    now=frame*1000/120;const events:Event[]=[];
    if(scenario==='local-gap'&&frame===37){
      now=301;for(let i=1;i<=12;i++){step(world,new Map([['p',input]]),.05,{substeps:5});tick++;authority.push(clone(world));authorityTickTimes.push(now);}
      const raw=packet(tick);events.push({at:now,raw});socket.messageRaw(raw);injected.push({frame,at:now,tick});now=frame*1000/120;
    }
    if(scenario==='peer-fifo'){
      while((tick+1)*50<=now+1e-8){
        tick++;step(world,new Map([['p',input],['q',input]]),.05,{substeps:5});authority.push(clone(world));authorityTickTimes.push(now);
        if(tick%2===0){
          const sent=socket.sent.map(value=>JSON.parse(value)).filter(value=>value.type==='input');control.receivedSeq=sent.at(-1)?.seq??0;
          const delay=tick*50<700?200:tick*50<1500?500:0;
          lastRelease=Math.max(lastRelease,tick*50+delay);pending.push({at:lastRelease,raw:packet(tick)});
        }
      }
      while(pending.length&&pending[0].at<=now+1e-8){const event=pending.shift()!;events.push({at:now,raw:event.raw});socket.messageRaw(event.raw);injected.push({frame,at:now,tick:JSON.parse(event.raw).tick});}
    }
    const tickSession=scenario==='peer-fifo'||frame<=36;
    if(tickSession)session.tick(1/120,input);
    const shown=session.renderWorld();
    const snap=scenario==='peer-fifo'||frame===37?session.takePresentationSnap():null;
    const plan={frame,now,authorityTick:tick,tickSession,events};plans.push(plan);sample(plan,world,shown,snap);
  }
  const fixture:Fixture={scenario,input:clone(input),welcome,initialRaw,clockTurnaround,plans,authority,authorityTickTimes,injected};
  writeFileSync(fixturePath,JSON.stringify(fixture));
  output.metadata={authorityTicks:tick,initialStateProtocol:PROTOCOL_VERSION,injections:injected.length};
}else{
  const fixture=JSON.parse(readFileSync(fixturePath,'utf8')) as Fixture;
  if(fixture.scenario!==scenario)throw new Error('fixture scenario mismatch');
  input=fixture.input;socket.messageRaw(fixture.initialRaw);
  if(fixture.clockTurnaround!==null)Reflect.get(session,'clock').observeTurnaround(fixture.clockTurnaround);
  for(const plan of fixture.plans){
    for(const event of plan.events){now=event.at;socket.messageRaw(event.raw);}
    now=plan.now;if(plan.tickSession)session.tick(1/120,input);
    const shown=session.renderWorld();
    const snap=scenario==='peer-fifo'||plan.frame===37?session.takePresentationSnap():null;
    sample(plan,fixture.authority[plan.authorityTick],shown,snap);
  }
  output.metadata={authorityTicks:fixture.authority.length-1,injections:fixture.injected.length};
}
output.outbound=socket.sent;session.disconnect();writeFileSync(outputPath,JSON.stringify(output));
