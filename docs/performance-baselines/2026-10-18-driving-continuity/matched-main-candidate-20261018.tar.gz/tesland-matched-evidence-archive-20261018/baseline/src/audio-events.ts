import { nearbyBuildings, terrainHeight } from '../shared/map';
import { VEHICLES } from '../shared/vehicles';
import type { Entity, World } from '../shared/game';

export type SoundCue = 'jump' | 'land' | 'boost' | 'crash' | 'pickup' | 'delivery' | 'repair' | 'air' | 'rocket' | 'refill' | 'pursuit' | 'ticket' | 'achievement' | 'ferry';
export type SoundEvent = { cue: SoundCue; strength?: number };

type Sample = {
  playerId: string; entityId: string; time: number; x: number; z: number; y: number; vy: number;
  speed: number; health: number; air: number; grounded: boolean; jumpBurstUntil: number; stage: 'pickup' | 'dropoff';
  completed: number; tickets: number; achievementEventId: number; pursued: boolean; refilling: boolean;
  ferryPhase:World['ferry']['phase'];
  pickups: Map<string, boolean>;
};

function grounded(e: Entity): boolean { return e.supportId!==null; }

/** Derives local presentation cues from authoritative snapshots; never mutates the world. */
export class SoundEventTracker {
  private previous?: Sample;
  private lastCrash = -Infinity;
  reset(): void { this.previous=undefined; this.lastCrash=-Infinity; }

  update(world: World, playerId: string, atStation: boolean): SoundEvent[] {
    const p=world.players.find(player=>player.id===playerId);
    const e=world.entities.find(entity=>entity.id===p?.entityId);
    if(!p||!e){this.reset();return [];}
    const previous=this.previous;
    // A near-full tank can reach 100% between observations, so include a measured increase.
    const refilling=atStation&&(e.air<99.8||(previous?.entityId===e.id&&e.air>previous.air+.01));
    const sample:Sample={playerId,entityId:e.id,time:world.time,x:e.x,z:e.z,y:e.y,vy:e.vy,speed:e.speed,health:e.health,air:e.air,
      grounded:grounded(e),jumpBurstUntil:e.jumpBurstUntil,stage:p.delivery.order.stage,completed:p.delivery.completed,
      tickets:p.delivery.tickets,achievementEventId:p.achievements.lastUnlock?.id??0,pursued:world.entities.some(car=>car.police?.targetId===playerId),
      refilling,ferryPhase:world.ferry.phase,pickups:new Map(world.pickups.map(pickup=>[pickup.id,pickup.active]))};
    this.previous=sample;
    if(!previous||previous.playerId!==playerId||sample.time<previous.time){this.lastCrash=-Infinity;return [];}
    if(sample.time===previous.time)return sample.achievementEventId>previous.achievementEventId?[{cue:'achievement'}]:[];
    const events:SoundEvent[]=[];
    if(sample.completed>previous.completed)events.push({cue:'delivery'});
    else if(previous.stage==='pickup'&&sample.stage==='dropoff')events.push({cue:'pickup'});
    if(sample.tickets>previous.tickets)events.push({cue:'ticket'});
    if(sample.achievementEventId>previous.achievementEventId)events.push({cue:'achievement'});
    if(sample.pursued&&!previous.pursued)events.push({cue:'pursuit'});
    if(sample.refilling&&!previous.refilling)events.push({cue:'refill'});
    if(sample.ferryPhase!==previous.ferryPhase&&Math.hypot(e.x-world.ferry.x,e.z-world.ferry.z)<120)events.push({cue:'ferry'});
    if(sample.entityId!==previous.entityId)return events;
    const elapsed=sample.time-previous.time;
    const teleported=Math.hypot(sample.x-previous.x,sample.z-previous.z)>Math.max(15,Math.abs(previous.speed)*elapsed*2+5);
    if(teleported)return events;
    if(sample.jumpBurstUntil>previous.jumpBurstUntil)events.push({cue:'jump'});
    if(!previous.grounded&&sample.grounded&&previous.vy< -1.5)events.push({cue:'land',strength:Math.min(1,Math.max(.25,-previous.vy/14))});
    // At the damage floor, a sharp speed loss beside an obstacle can still signal a crash.
    const damage=previous.health-sample.health;
    const abrupt=elapsed<=.25&&Math.abs(previous.speed)-Math.abs(sample.speed)>8&&sample.tickets===previous.tickets;
    const nearBuilding=abrupt&&nearbyBuildings(e.x,e.z,8).some(b=>e.y<b.h&&Math.abs(e.x-b.x)<b.w/2+5&&Math.abs(e.z-b.z)<b.d/2+5);
    const nearCar=abrupt&&world.entities.some(other=>other.id!==e.id&&Math.abs(other.y-e.y)<3&&Math.hypot(other.x-e.x,other.z-e.z)<(e.kind==='person'?2:VEHICLES[e.kind].length/2)+(other.kind==='person'?2:VEHICLES[other.kind].length/2)+3);
    if((damage>.05||nearBuilding||nearCar)&&sample.time-this.lastCrash>.3){events.push({cue:'crash',strength:Math.min(1,Math.max(.3,damage/5,(Math.abs(previous.speed)-Math.abs(sample.speed))/20))});this.lastCrash=sample.time;}
    for(const pickup of world.pickups){
      if(previous.pickups.get(pickup.id)&&!pickup.active&&e.supportId==='ground'&&Math.abs(e.y-(terrainHeight(pickup.x,pickup.z)??0))<2&&Math.hypot(e.x-pickup.x,e.z-pickup.z)<7)events.push({cue:pickup.kind});
    }
    return events;
  }
}
