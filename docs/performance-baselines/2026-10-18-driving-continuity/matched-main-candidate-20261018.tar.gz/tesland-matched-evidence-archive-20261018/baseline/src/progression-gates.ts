import * as T from 'three';
import { ACCESS_BOUNDARIES, LEVELS } from '../shared/delivery';
import { ACCESS_ROAD_GATES } from '../shared/service-areas';
import { BRIDGES, HIGHWAYS, terrainHeight, type MapPoint } from '../shared/map';
import { FLIGHT_CEILING } from '../shared/sky-currents';

type GateLevel = 1|2|3|4|5|6;
type Placement = { x:number; z:number; yaw:number; width:number };

// Intersect the road with the shared Z boundary, not a perpendicular road
// segment: the physical access boundary is a line of constant world Z.
function crossings(points:MapPoint[], z:number):Placement[] {
  const result:Placement[]=[];
  for(let i=1;i<points.length;i++){
    const a=points[i-1],b=points[i],dz=b.z-a.z;
    if(!dz||z<Math.min(a.z,b.z)||z>Math.max(a.z,b.z))continue;
    const t=(z-a.z)/dz,dx=b.x-a.x;
    const x=a.x+dx*t;
    // Highway rectangles are 32 m wide; an oblique crossing needs a wider
    // plane to span the road at this exact Z. Do not duplicate a shared vertex.
    const width=32*Math.hypot(dx,dz)/Math.abs(dz)+4;
    if(!result.some(point=>Math.abs(point.x-x)<.01))result.push({x,z,yaw:0,width});
  }
  return result;
}

function requirementMaterial(level:GateLevel):T.SpriteMaterial {
  const goal=LEVELS[level];
  const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=256;
  const ctx=canvas.getContext('2d')!;
  ctx.fillStyle='rgba(25,38,43,.94)';ctx.beginPath();ctx.roundRect(8,8,1008,240,24);ctx.fill();
  ctx.strokeStyle='#ffc777';ctx.lineWidth=7;ctx.stroke();
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillStyle='#ffcc83';ctx.font='bold 52px system-ui';ctx.fillText(`LEVEL ${level}  ·  ${goal.name.toUpperCase()}`,512,64,950);
  ctx.fillStyle='#fff7e7';ctx.font='bold 40px system-ui';
  ctx.fillText(`$${goal.cash.toLocaleString()} AVAILABLE CASH`,512,137,950);
  ctx.fillStyle='#ffcc83';ctx.font='bold 33px system-ui';ctx.fillText('LOCKED ON THE ROAD AND IN THE AIR',512,205,950);
  const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
  return new T.SpriteMaterial({map:texture,transparent:true,depthWrite:false,depthTest:false});
}

/** Visual-only checkpoints. Caller adds each group and sets its visibility per local player. */
export function createProgressionGates():Record<GateLevel,T.Group> {
  const groups:Record<GateLevel,T.Group>={1:new T.Group(),2:new T.Group(),3:new T.Group(),4:new T.Group(),5:new T.Group(),6:new T.Group()};
  const fieldGeometry=new T.PlaneGeometry(1,1),railGeometry=new T.BoxGeometry(1,1,1);
  const fieldMaterial=new T.MeshBasicMaterial({color:0xffc56f,transparent:true,opacity:.14,depthWrite:false,side:T.DoubleSide});
  const railMaterial=new T.MeshBasicMaterial({color:0xffc56f,transparent:true,opacity:.8,depthWrite:false});
  // Thin dashed guides mark the same full-height boundary used by flyers,
  // without placing an opaque wall over the road or scenery.
  const airGuidePoints:number[]=[];
  for(const x of [-.5,.5])for(let y=12;y<FLIGHT_CEILING;y+=12)airGuidePoints.push(x,y,0,x,Math.min(y+7,FLIGHT_CEILING),0);
  const airGuideGeometry=new T.BufferGeometry();
  airGuideGeometry.setAttribute('position',new T.Float32BufferAttribute(airGuidePoints,3));
  const airGuideMaterial=new T.LineBasicMaterial({color:0xffc56f,transparent:true,opacity:.65,depthWrite:false});
  const requirements:Record<GateLevel,T.SpriteMaterial>={1:requirementMaterial(1),2:requirementMaterial(2),3:requirementMaterial(3),4:requirementMaterial(4),5:requirementMaterial(5),6:requirementMaterial(6)};

  function add(level:GateLevel, placement:Placement) {
    const group=new T.Group();group.name=`level-${level}-checkpoint`;
    group.position.set(placement.x,terrainHeight(placement.x,placement.z)??0,placement.z);
    group.rotation.y=placement.yaw;
    const field=new T.Mesh(fieldGeometry,fieldMaterial);field.position.y=5;field.scale.set(placement.width,10,1);group.add(field);
    for(const x of [-placement.width/2,placement.width/2]){
      const rail=new T.Mesh(railGeometry,railMaterial);rail.position.set(x,5,0);rail.scale.set(.3,10,.3);group.add(rail);
    }
    const top=new T.Mesh(railGeometry,railMaterial);top.position.y=10;top.scale.set(placement.width,.3,.3);group.add(top);
    const label=new T.Sprite(requirements[level]);label.position.y=12.7;label.scale.set(30,7.5,1);group.add(label);
    const airGuide=new T.LineSegments(airGuideGeometry,airGuideMaterial);airGuide.scale.x=placement.width;group.add(airGuide);
    const airLabel=new T.Sprite(requirements[level]);airLabel.position.y=62;airLabel.scale.set(24,6,1);group.add(airLabel);
    const highLabel=new T.Sprite(requirements[level]);highLabel.position.y=150;highLabel.scale.set(24,6,1);group.add(highLabel);
    groups[level].add(group);
  }

  const bridge=BRIDGES.find(item=>item.id==='bay-bridge');
  if(bridge&&bridge.axis==='x'&&ACCESS_BOUNDARIES.oaklandX>=bridge.start&&ACCESS_BOUNDARIES.oaklandX<=bridge.end){
    add(1,{x:ACCESS_BOUNDARIES.oaklandX,z:bridge.center,yaw:Math.PI/2,width:bridge.width+4});
  }
  for(const gate of ACCESS_ROAD_GATES){
    const highway=HIGHWAYS.find(road=>road.id===gate.road);
    if(highway)for(const placement of crossings(highway.points,gate.z))add(gate.level,placement);
  }
  return groups;
}
