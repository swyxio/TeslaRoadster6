# Tesland matched deterministic driving evidence — 2026-10-18

Status: **unshipped evidence; continuity gate fails**. This archive preserves the original matched runs and a reproduction, not a release or performance claim.

## Source and provenance

- Baseline: commit `e07f0bec4e62737fedcfc72ab9714f4dd4e7a1bf`, tree `4a3eb03d6c110ba4288e746b7a45de62a19ed876`, protocol 48.
- Candidate: commit `020f25b40696608e7e7285fc74adf6f52c4c3d42`, tree `eca1b0923db617d9a70ff9d90021ad00b0cc542d`, protocol 49; includes the then-current main merge.
- `baseline/` and `candidate/` contain `shared/`, `src/`, and package/lock/config files extracted from those exact Git commits. Their `shared/` and `src/` were recursively compared byte-for-byte to the original frozen capture sources. The two copies of `tests/matched-peer-trace.lab.ts` are the identical supplemental, uncommitted harness used for capture. `scripts/matched-analysis.lab.ts` is the original supplemental analyzer; it hardcodes the original evidence directory and must not be run against that directory when preserving the capture.
- `evidence/*-fixture.json` includes the full authority worlds for every simulation tick, all raw initial and injected state packets, delivery plans and constant input. The calibration/generation, baseline, candidate and candidate-repeat JSON contain complete rendered-world, received-world, clock, input, authority and outbound records. Empty logs are retained as emitted. `comparison.json` and `comparison.log` preserve the original analyzer output.
- Baseline generates the fixture and is then replayed from it. Candidate receives the very same initial/state packet bytes, recorded event times and local input. Only the welcome protocol version is selected from the respective source (48 vs 49); welcome fields are otherwise identical. This is a deterministic matched replay, not a mixed-version live-server test.
- Reproduction environment: macOS, Node v22.22.2, pnpm 10.33.1 and the installed project lockfile's `tsx`; no browser, live room, network or load generator. `SHA256SUMS` records every other file's contents. Original source, fixture and captures remain in `/private/tmp/tesland-matched-driving-20261018`; this archive contains copies.

## Reproduce without overwriting evidence

With dependencies installed using the included lockfile, provide an absolute path to `tsx` and a new output directory:

```sh
./reproduce.sh /absolute/path/to/node_modules/.bin/tsx /absolute/path/to/new-output-directory
```

For the capture host the tested command was:

```sh
./reproduce.sh /private/tmp/tesland-continuity-throughput/node_modules/.bin/tsx /private/tmp/tesland-matched-evidence-reproduction-diag-20261018
```

The script regenerates each baseline fixture/calibration, replays the saved fixture through both versions twice where applicable, runs an isolated candidate diagnostic patch, compares the diagnostic log, and compares the results to the archived JSON using structural equality. `evidence/reproduction.log` records the successful local result; original outputs were not rewritten. An arbitrary platform/dependency version may differ, so verify the generated outputs rather than assuming bit-for-bit portability. All generated data goes to the specified output directory.

`instrumentation/reconciliation-diagnostic.patch` adds three console logs only; applied to a disposable candidate copy, its frame and outbound arrays match the uninstrumented candidate exactly. `evidence/peer-candidate-instrumented.log` records its output.

## Findings

Peer fixture: at frame 228 (1900 ms), FIFO snapshots for ticks 28, 30, 32, 34, 36 and 38 arrive together. Authority peer x changes smoothly by 2.8 m from tick 37 to 38, with first impact at tick 39 (frame 234). Both versions display a 39.5782996 m peer step at frame 228; local steps are 19.4997430 m baseline and 19.7010264 m candidate, and both flag a presentation snap. The candidate's recorded visual clock moves from 30.9639 to 38, and remote clock from 23.8649 to 34, due to latest-snapshot floors.

Diagnostic branch details: local rebase expects x = -313.644894 versus goal -294.643868; the 19.001 m correction exceeds the 12 m bound and cuts. Remote playback computes peer x = -274.156132 at tick 34, but near-contact blending selects the prediction forecast x = -285.356132; expected x = -246.477832 is 38.878 m away, so the separate 12 m peer offset bound drops it. These branches explain the observed presentation snap; do not interpret the authority movement as a 39.578 m teleport.

On this trace the maximum sampled planar displayed-contact depth is 0.23396 m baseline and 0.23392 m candidate; longest consecutive sampled contact is 72 frames, while sampled authority contact depth is zero. The 481 captured frames remain online. The local-gap case flags a 13.9680642 m baseline and 14.1871097 m candidate step at frame 37. The local-gap harness advances twelve 50 ms simulation ticks at one recorded 301 ms arrival; it is a deterministic sparse-state stress fixture, not proof that a live room can simulate 600 ms in 301 ms.

## Safety and measurement limits

The peer fixture applies synthetic constant throttle to both players in shared simulation; it uses a control snapshot with `heldUntilTick=10000` and synthesizes `receivedSeq` from the latest sent command. It does not reproduce actual Worker scheduling, acknowledgements, watch­dogs or real network input age. Identical input and packet traces isolate the compared implementations, but do not prove production timing or input responsiveness.

The analyzer samples returned world positions and planar OBB contact at 120 Hz. It is not a swept collision proof, scene-rendered mesh or GPU measurement, physical-device test, room throughput benchmark, or evidence that a visual/performance gate passes. It does not prove safe ferry/deck, airborne, dome, dynamic peer trajectories, static walls, roster changes, or relocation/reuse.

A history-based candidate must use matching historical world, control snapshot, substeps, local commands and accepted edge outcomes for each playback base, while keeping fresh authoritative UI/wire state and fencing room epoch, entity incarnation/relocation, action and revision changes immediately. Nearby displayed bodies and moving supports require a coherent time base and verified swept dynamic/static geometry; endpoint clearance or removing the 12 m bound alone does not prove safety. Remote playback's existing eight-frame history and `last.tick - 4` floor can independently discard prior presentation time. Exercise burst/loss and history exhaustion, moving contacts, walls, jumps/dome/ferry, real short relocation and reused IDs, and immediate press/release/edge fencing. Re-run the same retained trace plus relevant suite, browser/scene and room-performance gates before release.
