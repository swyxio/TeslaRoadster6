#!/bin/sh
set -eu
# Use a tsx executable installed from this project's pnpm lockfile.
if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then
  echo 'usage: ./reproduce.sh /absolute/path/to/tsx [/absolute/output/directory]' >&2
  exit 2
fi
TSX=$1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUT=${2:-$(mktemp -d "${TMPDIR:-/tmp}/tesland-matched-repro.XXXXXX")}
mkdir -p "$OUT"
OUT=$(CDPATH= cd -- "$OUT" && pwd)
if [ "$OUT" = "$ROOT/evidence" ] || [ "$OUT" = /private/tmp/tesland-matched-driving-20261018/evidence ]; then
  echo 'Refusing to overwrite original evidence.' >&2
  exit 2
fi
for CASE in local peer; do
  if [ "$CASE" = local ]; then SCENARIO=local-gap; else SCENARIO=peer-fifo; fi
  "$TSX" "$ROOT/baseline/tests/matched-peer-trace.lab.ts" generate "$SCENARIO" "$OUT/$CASE-fixture.json" "$OUT/$CASE-calibration.json" > "$OUT/$CASE-generation.log" 2>&1
  "$TSX" "$ROOT/baseline/tests/matched-peer-trace.lab.ts" replay "$SCENARIO" "$ROOT/evidence/$CASE-fixture.json" "$OUT/$CASE-baseline.json" > "$OUT/$CASE-baseline.log" 2>&1
  "$TSX" "$ROOT/candidate/tests/matched-peer-trace.lab.ts" replay "$SCENARIO" "$ROOT/evidence/$CASE-fixture.json" "$OUT/$CASE-candidate.json" > "$OUT/$CASE-candidate.log" 2>&1
  "$TSX" "$ROOT/candidate/tests/matched-peer-trace.lab.ts" replay "$SCENARIO" "$ROOT/evidence/$CASE-fixture.json" "$OUT/$CASE-candidate-repeat.json" > "$OUT/$CASE-candidate-repeat.log" 2>&1
done
cp -R "$ROOT/candidate" "$OUT/diagnostic-candidate"
(cd "$OUT/diagnostic-candidate" && patch -p1 < "$ROOT/instrumentation/reconciliation-diagnostic.patch") > "$OUT/patch.log" 2>&1
"$TSX" "$OUT/diagnostic-candidate/tests/matched-peer-trace.lab.ts" replay peer-fifo "$ROOT/evidence/peer-fixture.json" "$OUT/peer-candidate-instrumented.json" > "$OUT/peer-candidate-instrumented.log" 2>&1
cmp "$ROOT/evidence/peer-candidate-instrumented.log" "$OUT/peer-candidate-instrumented.log"
python3 "$ROOT/scripts/verify-replay.py" "$ROOT/evidence" "$OUT"
echo "Reproduced files: $OUT"
