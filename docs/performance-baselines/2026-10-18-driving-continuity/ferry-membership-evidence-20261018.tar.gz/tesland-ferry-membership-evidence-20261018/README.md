# Ferry membership and wire diagnostic, 2026-10-18

**Unsafe diagnostic; not a fix and not a deployment candidate.** Test fixtures and IDs are synthetic. This experiment was isolated from #109 release code. It retains failed assertions and does not prove driving continuity, ferry safety, or room throughput.

## Reproduction

Use the adjacent `tesland-confirmed-ferry-diagnostic-20261018.tar.gz` (SHA-256 `86b9e1a9b51fa01b28be3bdff0fdf12fdd005b8a71ec82667377dfd468f0599d`) to reconstruct the v50 identity/history `token` lab, following that package's README. The prototype is based on integrated candidate 020f25b, itself v49. In the reconstructed token directory apply the adjacent `airborne-solid-signal-followup-20261018.tar.gz` patch (SHA-256 `c9eef44f8a3d1176ff442359a273fc69b5dfbce8ba2d67d25654cfd639719edc`), then this bundle's `ferry-component-followup.patch`; copy this bundle's `ferry-membership-wire-size.lab.ts` to `tests/`. Install dependencies as described by the predecessor.

```
git apply --check /ABSOLUTE/PATH/ferry-component-followup.patch
git apply /ABSOLUTE/PATH/ferry-component-followup.patch
cp /ABSOLUTE/PATH/ferry-membership-wire-size.lab.ts tests/
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/interaction-components.lab.test.ts tests/stable-ferry-candidate.lab.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/ferry-filtered-membership.lab.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec tests/distant-ferry-component.lab.test.ts
./node_modules/.bin/tsx --test --test-concurrency=1 --test-reporter=spec --test-name-pattern 'ferry phase and membership|shore driver stays clear|moving local and remote riders|confirmed boarding under' tests/ferry-transition.lab.test.ts
./node_modules/.bin/tsx tests/ferry-membership-wire-size.lab.ts
./node_modules/.bin/tsc --noEmit
```

The first diagnostic pair passes 10/10; typecheck passed before the later wire-count script was added. The following three test commands intentionally retain failures; see the included logs.

## Membership failure

The broad-phase component code partitions caller-declared bounded pivot paths. The stable-transit code screens only fixed-manifest, mid-water cases. Neither is a safety certificate. The current `worker/snapshot.ts` filter hides unowned driverless ambient bodies more than 1,400 m from a recipient, although ferry-supported bodies and driven bodies remain visible. The retained `ferry-filtered-membership.lab.test.ts` uses that real filter with a synthetic undriven object near the ferry and a recipient far away. Full room input is unavailable because the body can interact; the filtered input incorrectly returns candidate. Thus equal visible rosters and ferry manifests cannot certify completeness. The predictor further restricts replay peers to 160 m, and the real scene independently smooths hull, rider positions and rider yaw. No diagnostic candidate is consumed.

A plausible authoritative change would have to establish complete relevant body coverage for every affected interval, preserve ordered support/phase/identity/relocation events, and provide enough path or conservative reach information to check all potentially interacting bodies, including unseen future inputs. A full roster at each snapshot alone does not provide this interval history. A credible solution also needs co-timed scene placement, responsiveness, bounded history and actual Worker/browser/performance tests; feasibility against the strict trace remains unproved. No protocol or production implementation is proposed by this archive.

## Raw application payload estimate

The static v50 synthetic byte-count script constructs 64 players at two coincident centers (32 Bay, 32 distant), 86 entities total. This is not a playable occupancy or realistic distribution. It serializes the existing 10 Hz state shape and compares the filtered message with the same message carrying the full roster, without simulating game ticks. One broadcast contains 7,282,528 filtered versus 7,820,864 full-roster raw JSON bytes, +538,336 (+7.39%); at 10 Hz that arithmetic difference is 5,383,360 bytes/s. The one-player sample and per-recipient ranges are in the raw log. These numbers exclude WebSocket framing, compression, transport, CPU and Cloudflare throughput, and do not estimate extra event-history or reachability data. They are not a performance gate or a capacity claim.

## Retained functional failures

The isolated moving-ferry/local-wall test holds an otherwise unrelated local frame. The strict ferry suite remains 0/6: departure/arrival both fail non-vacuity (`stable=0`), shore/deck overlap reaches 1.104 m while authority is clear, boarding reaches a 1.319 m frame step and 121 held frames, disembarking reaches 1.495 m, and confirmed boarding shows stale ground across seven sampled frames. No actual Worker, browser or physical-device test is represented here.
