import { addPlayer, createWorld, NEUTRAL } from '../shared/game';
import { ScheduledInput } from '../shared/tick-input';
import { prepareSnapshots } from '../worker/snapshot';

// Static byte-count diagnostic only. No transport, simulation throughput or
// compression is measured. Full roster does not prove substep trajectories.
for(const occupancy of [1,64]){
  const world=createWorld(0),ids:string[]=[];
  for(let i=0;i<occupancy;i++){
    const id=`synthetic-${i}`;ids.push(id);addPlayer(world,id,id);
    const car=world.entities.find(e=>e.driver===id)!;
    // Split the room between the Bay and a distant part of the large map.
    Object.assign(car,i%2?{x:1600,z:8800}:{x:0,z:0});
  }
  const control=new ScheduledInput(NEUTRAL).snapshot();
  const encode=prepareSnapshots(world,10,'synthetic-room',1);
  const samples=ids.map(id=>{
    const message=encode(id,control,0),parsed=JSON.parse(message);
    const canonical=JSON.stringify(parsed);
    if(message!==canonical)throw new Error('Unexpected serialization ordering');
    const filtered=Buffer.byteLength(message),count=parsed.world.entities.length;
    parsed.world.entities=world.entities;
    return {id,visibleEntities:count,filtered,full:Buffer.byteLength(JSON.stringify(parsed))};
  });
  const sum=(key:'filtered'|'full')=>samples.reduce((n,item)=>n+item[key],0);
  const filtered=sum('filtered'),full=sum('full');
  console.log('WIRE_SIZE_SYNTHETIC',JSON.stringify({occupancy,entities:world.entities.length,
    minVisible:Math.min(...samples.map(x=>x.visibleEntities)),maxVisible:Math.max(...samples.map(x=>x.visibleEntities)),
    filteredBytesPerBroadcast:filtered,fullBytesPerBroadcast:full,differenceBytesPerBroadcast:full-filtered,
    filteredBytesPerSecondAt10Hz:filtered*10,fullBytesPerSecondAt10Hz:full*10,
    minDifferencePerRecipient:Math.min(...samples.map(x=>x.full-x.filtered)),maxDifferencePerRecipient:Math.max(...samples.map(x=>x.full-x.filtered))}));
}
