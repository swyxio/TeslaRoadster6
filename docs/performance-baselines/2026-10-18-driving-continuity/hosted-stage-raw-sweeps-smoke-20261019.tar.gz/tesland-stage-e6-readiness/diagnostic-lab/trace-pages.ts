// Stream bounded pages after recording ends. Invalid or drifting pagination is
// an incomplete export; no missing observations are interpreted as zero.
export type TracePage={offset:number;summary:{poses:number;events:number};rawGround:{records:number;collectionComplete:boolean;invalid:boolean;overflow:boolean;coverageProven:boolean};poses:unknown[];events:unknown[];groundSweeps:unknown[]};
export async function* verifiedTracePages(fetchPage:(offset:number,limit:number)=>Promise<TracePage>,limit=1000):AsyncGenerator<string>{
  if(!Number.isInteger(limit)||limit<1||limit>1000)throw new Error('Invalid page limit');
  let total=1,signature:string|null=null;
  for(let offset=0;offset<total;offset+=limit){
    const page=await fetchPage(offset,limit),p=page?.summary?.poses,e=page?.summary?.events,r=page?.rawGround?.records;
    if(page?.offset!==offset||!Number.isSafeInteger(p)||p<0||p>1_048_576||!Number.isSafeInteger(e)||e<0||e>4096||
       !Number.isSafeInteger(r)||r<0||r>1_048_576||typeof page.rawGround.collectionComplete!=='boolean'||
       typeof page.rawGround.invalid!=='boolean'||typeof page.rawGround.overflow!=='boolean'||page.rawGround.coverageProven!==false||
       page.rawGround.collectionComplete&&(page.rawGround.invalid||page.rawGround.overflow)||
       !Array.isArray(page.poses)||!Array.isArray(page.events)||!Array.isArray(page.groundSweeps))throw new Error('Invalid trace page');
    const expected=(n:number)=>Math.max(0,Math.min(limit,n-offset));
    if(page.poses.length!==expected(p)||page.events.length!==expected(e)||page.groundSweeps.length!==expected(r))throw new Error('Incomplete trace page');
    const current=JSON.stringify([page.summary,page.rawGround]);
    if(signature!==null&&signature!==current)throw new Error('Trace changed between pages');
    signature=current;total=Math.max(p,e,r);
    yield JSON.stringify(page)+'\n';
  }
}
