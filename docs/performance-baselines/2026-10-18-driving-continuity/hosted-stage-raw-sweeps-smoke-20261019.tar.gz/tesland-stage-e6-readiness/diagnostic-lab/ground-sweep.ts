// Conservative diagnostic broadphase only. An overlap means "unproven",
// not actual contact; absent paths and other map collision types need guards.
import { MAP_BOUNDS,REGIONS,insidePolygon,nearbyBuildings,type MapPoint } from '../shared/map';
import { buildingBoundsOverlap } from '../shared/building-bounds';
import { dimensions,type Pose } from '../shared/physics';
export type Bounds={minX:number;maxX:number;minZ:number;maxZ:number};
export function groundSweep(kind:Pose['kind'],from:{x:number;z:number},to:{x:number;z:number}):Bounds|null {
  if(![from.x,from.z,to.x,to.z].every(Number.isFinite))return null;
  const shape=dimensions(kind),radius=Math.hypot(shape.width,shape.length)/2;
  if(!Number.isFinite(radius)||radius<=0)return null;
  return {minX:Math.min(from.x,to.x)-radius,maxX:Math.max(from.x,to.x)+radius,
    minZ:Math.min(from.z,to.z)-radius,maxZ:Math.max(from.z,to.z)+radius};
}
export function overlaps(a:Bounds,b:Bounds):boolean {
  return a.minX<=b.maxX&&b.minX<=a.maxX&&a.minZ<=b.maxZ&&b.minZ<=a.maxZ;
}
export function staticSweepProblem(box:Bounds):string|null {
  if(box.minX<MAP_BOUNDS.minX||box.maxX>MAP_BOUNDS.maxX||box.minZ<MAP_BOUNDS.minZ||box.maxZ>MAP_BOUNDS.maxZ)return 'swept-map-boundary';
  const x=(box.minX+box.maxX)/2,z=(box.minZ+box.maxZ)/2;
  const radius=Math.max((box.maxX-box.minX)/2,(box.maxZ-box.minZ)/2);
  return nearbyBuildings(x,z,radius).some(b=>buildingBoundsOverlap(b,box.minX,box.maxX,box.minZ,box.maxZ))?'possible-swept-building':null;
}
// Establish only that the center segment remains strictly in a single land
// polygon. Border touching, bridges and uncertain floating-point orientation
// all fail closed. Other authored geometry still requires separate coverage.
export function polygonContainsSegment(points:MapPoint[],from:MapPoint,to:MapPoint):boolean {
  if(![from.x,from.z,to.x,to.z].every(Number.isFinite)||!insidePolygon(from.x,from.z,points)||!insidePolygon(to.x,to.z,points))return false;
  const side=(a:MapPoint,b:MapPoint,p:MapPoint)=>{
    const u=(b.x-a.x)*(p.z-a.z),v=(b.z-a.z)*(p.x-a.x),value=u-v;
    const tolerance=Number.EPSILON*64*(Math.abs(u)+Math.abs(v)+1);
    return value>tolerance?1:value< -tolerance?-1:0;
  };
  for(let i=0;i<points.length;i++){
    const a=points[i],b=points[(i+1)%points.length];
    const eps=1e-9*Math.max(1,Math.abs(a.x),Math.abs(a.z),Math.abs(b.x),Math.abs(b.z),Math.abs(from.x),Math.abs(from.z),Math.abs(to.x),Math.abs(to.z));
    if(Math.max(from.x,to.x)+eps<Math.min(a.x,b.x)||Math.max(a.x,b.x)+eps<Math.min(from.x,to.x)||
      Math.max(from.z,to.z)+eps<Math.min(a.z,b.z)||Math.max(a.z,b.z)+eps<Math.min(from.z,to.z))continue;
    const c=side(from,to,a),d=side(from,to,b),e=side(a,b,from),f=side(a,b,to);
    if(c*d<=0&&e*f<=0)return false;
  }
  return true;
}
export function surfaceSweepProblem(from:MapPoint,to:MapPoint):string|null {
  return REGIONS.some(region=>polygonContainsSegment(region.points,from,to))?null:'surface-continuity-unproven';
}
