# Staged hosted-room prototype — deliberately disabled

**Current lab:** runtime source is aligned to candidate `e6ad3b7ebb2ba47b768eb738472e4eb6aeb1844f`, the pose trace now uses a larger packed bound, and the latest verified limitations and test results are in `../evidence/READINESS-e6.md`. The remainder of this file is the historical earlier prototype and does not describe the current source or trace cap. Hosted execution remains disabled.

This is a **nonproduction diagnostic prototype**, based on commit `a53d0998ef83ead142ca498d6bfbedc57d628c65` plus `input-rejection-preview-v2.patch`. Its gameplay candidate is `623884560ed3d902090c36ff04b790d1c714bb84`, older than current main. It is not a release change and is not ready for a hosted run. `hosted-stage-driver.ts` has an unconditional hard-off switch; the earlier GitHub workflow is disabled. Do not remove those guards or deploy until the remaining work below is completed and reviewed.

## What this adds

* The diagnostic-only wrapper allocates unique, non-reusable slots before serializing simultaneous joins. It keeps normal room, input, guest identity, economy session, traffic, snapshot and timer code, and stages the existing seed-0 Roadsters at the recorded corridors. A random bearer secret is required for every room socket and staging/status/export operation. Runtime routing checks the separate diagnostic Preview hostname and marker; only disposable `gha-<run>-<attempt>` rooms are accepted. The sample config is explicitly for `wrangler dev --local` and its repeated `a` token is not a live secret.
* Four independently runnable groups each use 16 real `Session` instances and header-bearing Node WebSockets. They wait until all 64 unique slots have joined and guest identities and economy sessions are ready. Begin fences controls and starts the existing scheduler. Each Session must observe fresh advancing ticks before a shared warmup/start tick. It uses a speed-bounded straight control and stores bounded raw input and snapshot observations; overflow is incomplete. Four groups signal completion before the first group exports bounded substep pose/event pages.
* Diagnostic-only hooks surround every authoritative `advance` substep and record real entity-contact, ground static-solid, progression, island-jump-wall and stunt-ramp-wall decisions, plus end-of-substep poses with tick, index and substep count. The hooks flag ferry-secured or out-of-corridor/special-surface states, identity/revision changes, gaps and overflow. Events may capture contacts that a tick snapshot would miss. This is still **incomplete**: for example ferry/deck blocking inside `followSupport`, dome constraints, some landing and post-separation special-wall handling, and any transient unsupported path require further audit. Begin/end state checks alone cannot rule those out. `ContactTrace` keeps `authoritativeCoverage=false`, and every driver reports `authoritative-substep-contact-coverage-unavailable`; no absence-of-contact claim follows from these records. An instrumentation exception marks the trace invalid, not complete.
* The 64 candidate lanes came from the local `d05d6f4` preflight. The committed `shared/` tree is unchanged between that revision and `a53d0998`, but the v2 diagnostic modifies `shared/tick-input.ts` and this does not verify a later release. Rerun static and spawn-fit checks against the final source; sampled surface checks do not prove uninterrupted support or dynamic traffic avoidance. Guest economy hooks are present; saved-driver writes, recovery and financial operations are not exercised by the workload.

## Focused verification

In the diagnostic checkout after applying v2 then this patch:

```sh
pnpm exec tsx --test diagnostic-lab/hosted-stage-core.test.ts
pnpm exec tsc -p diagnostic-lab/tsconfig.worker.json --noEmit
pnpm exec tsc -p diagnostic-lab/tsconfig.client.json --noEmit
# When coordinated, regenerate against the exact candidate and review the output:
pnpm exec tsx diagnostic-lab/hosted-stage-preflight.ts > /private/tmp/tesland-staged-preflight.json
```

Eight focused tests passed, covering duplicate slot reservations, sealed/invalid/missing/unsupported/overflow evidence, instrumented entity and static decisions and a progression gate, physics parity for a controlled two-substep run, advancing warmup, a real `Session` using a mock socket, and Node's header-bearing WebSocket handshake to an ephemeral loopback HTTP server. Worker and client lab typechecks passed.

The 2026-10-19 UTC two-Session functional smoke used loopback TLS and fresh local-only storage. It checked the wrong-host and unauthenticated denial, unique staged slots, duplicate-slot 409, normal economy sessions, advancing snapshots, actual movement for both cars, incomplete contact reporting, 409 before trace sealing, and successful sealing/export after four synthetic completion signals. It observed an adaptive tick with substep indexes 0 and 1; the Worker was stopped immediately afterwards. This is not capacity, timing, Cloudflare isolation, saved-driver, or full contact-coverage evidence.

To reproduce only the bounded smoke, start the Worker and wait for health on loopback:

```sh
pnpm exec wrangler dev --config diagnostic-lab/wrangler.local-smoke.jsonc --local --local-protocol https --ip 127.0.0.1 --port 19331 --inspector-port 0 --persist-to /private/tmp/tesland-staged-smoke-fresh --log-level warn
```

In a second terminal, from the same checkout, run and then stop Wrangler:

```sh
pnpm exec tsx diagnostic-lab/hosted-stage-local-smoke.ts
```

The smoke imports the existing `ws@8.21.0` pnpm store module for a loopback TLS override; reconstruct the exact dependencies from the lockfile. The staged hosted driver uses the Node 22/Undici header extension; its HTTP/Upgrade proxy and preview behavior remain unverified. Pin and verify the exact runner Node version before any future run.

## Blocking work before any hosted measurement

1. Select and rebase onto the exact final source, regenerate source-matched lanes and verify each initial placement and all relevant terrain/landmark geometry. Safely remove the staging relocation's potential impact on delivery initialization or document the altered normal workload.
2. Finish auditing and testing authoritative hooks at all relevant contact, solid, progression and special-surface decision points; prove event and time-window coverage and export all raw data. Every gap or overflow must remain incomplete. The current partial hooks and two-client smoke cannot establish lack of obstruction.
3. Adapt and independently review the separate fail-closed provider identity checker for the staging wrapper, preview-only token binding, full static asset graph and pre/post guards; read actual Preview deployment and each same-Worker Durable Object namespace. The present checker only has synthetic provider tests, rejects the added token/config, and is not wired into the workflow. A matching eight-hex hostname may denote a version URL and is not proof of isolated Preview resources. The pinned target should live outside the checkout to avoid a self-referential source commit. Use a fresh disposable room and no real users; no token or authorization headers in artifacts or logs.
4. Test the real four-runner barrier, disconnect/failure behavior, raw trace export and Node transport against a bounded isolated Preview smoke after separate coordination. Observe and report staging setup and diagnostic trace overhead with paired repeated baseline/instrumented trials before interpreting throughput. The trace uses bounded JavaScript object buffers (up to 200,000 poses plus 4,096 events), whose Worker memory and CPU costs are unmeasured; overflow is incomplete. At 64 drivers and eight substeps per tick, the pose budget covers at most 390 full ticks (19.5 simulated seconds), so it cannot cover the 57-second gate under those conditions. Longer recordings need a separately evaluated bounded streaming/export design; simply increasing the cap is not established safe. A failure before all groups signal done may leave the server-side trace unavailable; that is explicitly incomplete and must not be counted as zero contacts.
5. The fixture has **no valid per-tick production CPU timer**. Cloudflare Worker `Date.now()` and `performance.now()` can remain frozen during CPU execution, so their within-callback deltas are not tick CPU work; wall-time progression, client ACKs and runner CPU are separate measures. A validated provider-supported CPU/profiling source and its event scope/overhead are required before claiming p95 tick CPU, and sampled profiles or aggregate per-event CPU do not automatically prove per-tick p95. See https://developers.cloudflare.com/workers/reference/security-model/ and https://developers.cloudflare.com/workers/runtime-apis/performance/ .

The fixture is synthetic off-road staged motion, not representative dense-city traffic or production capacity. Retain the raw four-runner files and trace along with source, asset, provider, host-load and UTC/monotonic timing evidence. Do not infer absent data as zero.
