import {test} from 'node:test';
import assert from 'node:assert/strict';
import {RawGroundTrace,type GroundState} from './raw-ground-trace';
import {groundSweep,overlaps,staticSweepProblem} from './ground-sweep';
import {BUILDINGS} from '../shared/map';

const state=(id:string,x:number,z:number,slot:number|null=null):GroundState=>({id,kind:'roadster',slot,x,z,support:'ground',inDome:false,loop:false});
const move=(s:GroundState,x:number,z:number)=>({from:{x:s.x,z:s.z,support:s.support},state:{...s,x,z}});
const anonymous=(s:GroundState)=>{const {id:_,...rest}=s;return rest;};

test('anonymous raw paths reconstruct a crossing and preserve distinct endpoint states',()=>{
  const trace=new RawGroundTrace(4,2,1),a=state('secret-driver',-20,0,0),b=state('ambient-id',20,0);
  const am=move(a,20,0),bm=move(b,-20,0);
  trace.append(1,0,1,[a,b],[am,bm],[{...am.state,x:19},bm.state]);trace.seal(1);
  const [ar,br]=trace.page(0,2);
  assert.deepEqual(ar,{tick:1,substep:0,substeps:1,id:1,start:anonymous(a),attempt:{from:am.from,state:anonymous(am.state)},end:anonymous({...am.state,x:19})});
  assert.ok(overlaps(groundSweep(ar.start!.kind as 'roadster',ar.attempt!.from,ar.attempt!.state)!,groundSweep(br.start!.kind as 'roadster',br.attempt!.from,br.attempt!.state)!));
  assert.equal(JSON.stringify(trace.page(0,2)).includes('secret-driver'),false);
  assert.equal(trace.summary().collectionComplete,true);assert.equal(trace.summary().coverageProven,false);
});

test('a building crossing can be recomputed from raw attempted endpoints',()=>{
  const building=BUILDINGS[0],distance=building.w/2+20,s=state('one',building.x-distance,building.z,0),m=move(s,building.x+distance,building.z);
  const trace=new RawGroundTrace(1,1,1);trace.append(1,0,1,[s],[m],[m.state]);trace.seal(1);
  const r=trace.page(0,1)[0];
  assert.equal(staticSweepProblem(groundSweep('roadster',r.attempt!.from,r.attempt!.state)!), 'possible-swept-building');
});

test('missing paths, overflow, duplicate ids, bad numbers, and substep gaps fail closed',()=>{
  const s=state('one',0,0,0),m=move(s,1,0);
  const partial=new RawGroundTrace(1,1,1);partial.append(1,0,1,[s],[],[s]);partial.seal(1);
  assert.equal(partial.summary().partialRecords,1);assert.equal(partial.summary().collectionComplete,false);assert.equal(partial.page(0,1)[0].attempt,null);
  const overflow=new RawGroundTrace(1,1,1);overflow.append(1,0,1,[s,state('two',2,0)],[],[]);overflow.seal(1);
  assert.equal(overflow.summary().overflow,true);assert.equal(overflow.summary().collectionComplete,false);
  const duplicate=new RawGroundTrace(2,1,1);duplicate.append(1,0,1,[s,s],[m],[m.state]);assert.equal(duplicate.summary().invalid,true);
  const malformed=new RawGroundTrace(1,1,1);malformed.append(1,0,1,[{...s,x:NaN}],[m],[m.state]);assert.equal(malformed.summary().invalid,true);
  const gap=new RawGroundTrace(2,2,1);gap.append(1,0,2,[s],[m],[m.state]);gap.append(2,0,1,[s],[m],[m.state]);gap.seal(2);
  assert.equal(gap.summary().invalid,true);assert.equal(gap.summary().collectionComplete,false);
});

test('page boundaries preserve precise coordinates, support, slot and special-path state',()=>{
  const trace=new RawGroundTrace(1026,513,1),a=state('one',-0,1,0),b=state('two',3,4,63);
  for(let tick=1;tick<=513;tick++){
    const am=move(a,1/tick,tick/3),bm=move({...b,support:'ferry',inDome:true,loop:true},tick,-tick);
    trace.append(tick,0,1,[a,b],[am,bm],[am.state,bm.state]);
  }
  trace.seal(513);const page=trace.page(1023,3);
  assert.equal(page.length,3);assert.equal(page[0].tick,512);assert.equal(page[1].tick,513);
  assert.ok(Object.is(page[1].start!.x,-0));assert.equal(page[2].attempt!.state.slot,63);
  assert.equal(page[2].attempt!.from.support,'ferry');assert.equal(page[2].attempt!.state.inDome,true);assert.equal(page[2].attempt!.state.loop,true);
  page[1].start!.x=123;assert.ok(Object.is(trace.page(1024,1)[0].start!.x,-0));
  assert.throws(()=>trace.page(-1,1));assert.equal(trace.summary().collectionComplete,true);
});

test('real simulation hook records ferry motion as missing ground path without changing physics',async()=>{
  const {createEmptyWorld,makeEntity,step}=await import('../shared/game');
  const {FERRY_TRAVEL_SECONDS}=await import('../shared/ferry');
  const world=createEmptyWorld(),car=makeEntity('ground','roadster',-500,4100),ferry=makeEntity('passenger','roadster',0,-274);
  ferry.supportId='ferry';world.entities.push(car,ferry);
  world.ferry.phase='to-island';world.ferry.remaining=FERRY_TRAVEL_SECONDS;world.ferry.passengers=[{entityId:ferry.id,x:0,z:0}];
  const control=structuredClone(world),trace=new RawGroundTrace(4,2,1);
  const snap=(e:typeof car):GroundState=>({id:e.id,kind:e.kind,slot:null,x:e.x,z:e.z,support:e.supportId,inDome:e.inDome,loop:e.loopAngle!==null});
  let starts:GroundState[]=[],attempts:ReturnType<typeof move>[]=[];
  step(control,new Map(),.05,{substeps:1});
  step(world,new Map(),.05,{substeps:1,diagnostic:{
    begin:(_i,_n,w)=>{starts=w.entities.map(snap);attempts=[];},event:()=>{},
    groundMove:(_i,e,old)=>attempts.push({from:{x:old.x,z:old.z,support:old.supportId},state:snap(e)}),
    end:(_i,_n,w)=>trace.append(1,0,1,starts,attempts,w.entities.map(snap)),
  }});
  trace.seal(1);assert.deepEqual(world,control);assert.equal(trace.summary().collectionComplete,false);
  const passenger=trace.page(0,4).find(row=>row.start?.support==='ferry');
  assert.ok(passenger);assert.equal(passenger.attempt,null);assert.equal(passenger.end?.support,'ferry');
});
