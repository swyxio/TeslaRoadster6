import {test} from 'node:test';
import assert from 'node:assert/strict';
import {verifiedTracePages,type TracePage} from './trace-pages';

const raw=(records:number)=>({records,collectionComplete:true,invalid:false,overflow:false,coverageProven:false});
const page=(offset:number):TracePage=>({offset,summary:{poses:3,events:1},rawGround:raw(4),
  poses:[0,1,2].slice(offset,offset+2),events:['e'].slice(offset,offset+2),groundSweeps:[0,1,2,3].slice(offset,offset+2)});
const collect=async(fetch:(offset:number,limit:number)=>Promise<TracePage>)=>{const result:string[]=[];for await(const p of verifiedTracePages(fetch,2))result.push(p);return result;};

test('paged export streams each kind without omitting later sweep records',async()=>{
  const pages=(await collect(async offset=>page(offset))).map(line=>JSON.parse(line));
  assert.deepEqual(pages.map(p=>p.offset),[0,2]);
  assert.deepEqual(pages.flatMap(p=>p.groundSweeps),[0,1,2,3]);assert.deepEqual(pages.flatMap(p=>p.poses),[0,1,2]);
});
test('missing data, bad offsets, drifting counts and unbounded summaries reject the export',async()=>{
  await assert.rejects(()=>collect(async offset=>({...page(offset),groundSweeps:[]})),/Incomplete trace page/);
  await assert.rejects(()=>collect(async offset=>({...page(offset),offset:offset+1})),/Invalid trace page/);
  await assert.rejects(()=>collect(async offset=>offset?{...page(offset),rawGround:raw(3)}:page(offset)),/Incomplete trace page|changed between pages/);
  await assert.rejects(()=>collect(async offset=>({...page(offset),rawGround:raw(1_048_577)})),/Invalid trace page/);
  await assert.rejects(()=>collect(async offset=>({...page(offset),rawGround:{...raw(4),coverageProven:true}})),/Invalid trace page/);
  await assert.rejects(()=>collect(async offset=>({...page(offset),rawGround:{...raw(4),overflow:true}})),/Invalid trace page/);
});
