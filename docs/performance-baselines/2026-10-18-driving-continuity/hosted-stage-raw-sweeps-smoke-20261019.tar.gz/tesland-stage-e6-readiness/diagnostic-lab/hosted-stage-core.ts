// Dedicated-preview prototype only. No production routing or worker configuration.
export class SlotAdmissions {
  private readonly reserved=new Set<number>();
  private readonly staged=new Set<number>();
  private sealed=false;
  constructor(readonly expected=64){if(!Number.isInteger(expected)||expected<1||expected>64)throw new Error('Invalid slot count');}
  reserve(slot:number):boolean {
    if(this.sealed||!Number.isInteger(slot)||slot<0||slot>=this.expected||this.reserved.has(slot))return false;
    this.reserved.add(slot);return true;
  }
  stage(slot:number):boolean {
    if(this.sealed||!this.reserved.has(slot)||this.staged.has(slot))return false;
    this.staged.add(slot);return true;
  }
  get complete():boolean{return this.reserved.size===this.expected&&this.staged.size===this.expected;}
  seal():boolean{if(this.sealed||!this.complete)return false;this.sealed=true;return true;}
}

// Paused equal-tick heartbeats are intentionally not fresh observations.
export class WarmupGate {
  private readonly slots=new Map<number,{tick:number;at:number;advanced:boolean}>();
  constructor(readonly expected:number,readonly startTick:number,readonly minAdvance=3,readonly maxAgeMs=500){}
  observe(slot:number,tick:number,at:number):void {
    if(!Number.isInteger(slot)||slot<0||slot>=this.expected||!Number.isSafeInteger(tick)||tick<this.startTick||!Number.isFinite(at))return;
    const prior=this.slots.get(slot);
    if(prior&&(tick<prior.tick||at<prior.at||tick===prior.tick))return;
    this.slots.set(slot,{tick,at,advanced:!!prior&&tick>prior.tick});
  }
  ready(now:number):boolean {
    if(!Number.isFinite(now)||this.slots.size!==this.expected)return false;
    return [...this.slots.values()].every(s=>s.advanced&&s.tick>=this.startTick+this.minAdvance&&now>=s.at&&now-s.at<=this.maxAgeMs);
  }
}

export type TracePose={tick:number;substep:number;substeps:number;slot:number;x:number;y:number;z:number;speed:number;support:string|null};
export type TraceEvent={tick:number;substep:number;slot:number;kind:'entity'|'solid'|'progression'|'unsupported'|'other';reason?:string};
type PoseChunk={values:Float64Array;support:Uint8Array;tick:Float64Array;substep:Uint8Array;substeps:Uint8Array};
export function unsupportedPose(entity:{x:number;z:number;supportId:string|null;inDome:boolean;loopAngle:number|null},lane:{x:number},startZ:number,endZ:number):string|null {
  if(entity.inDome||entity.loopAngle!==null||entity.supportId!=='ground')return 'special-surface-or-flight';
  if(!Number.isFinite(entity.x)||!Number.isFinite(entity.z)||Math.abs(entity.x-lane.x)>3||entity.z>startZ+3||entity.z<endZ-3)return 'outside-staged-corridor';
  return null;
}
// Bounded raw observations, plus explicit audit gaps. This prototype is never
// evidence of a clean interval until authoritative per-substep hookup is proven.
export class ContactTrace {
  readonly events:TraceEvent[]=[];
  private readonly chunks:PoseChunk[]=[];
  private readonly supportCodes=new Map<string|null,number>([[null,0],['ground',1]]);
  private readonly supportValues:(string|null)[]=[null,'ground'];
  private readonly framesPerChunk=64;
  private frames=0;
  private bytes=0;
  overflow=false;
  invalid=false;
  unsupported=false;
  private lastTick:number|null=null;
  private lastSubstep=-1;
  private lastSubsteps=0;
  private sealed=false;
  constructor(readonly expected:number,readonly maxPoses:number,readonly maxEvents=4096,readonly authoritativeCoverage=false,readonly startTick:number|null=null){
    if(!Number.isInteger(expected)||expected<1||expected>64||!Number.isSafeInteger(maxPoses)||maxPoses<0||
      !Number.isSafeInteger(maxEvents)||maxEvents<0)throw new Error('Invalid trace bound');
  }
  get poseCount():number{return this.frames*this.expected;}
  private chunk(index:number):PoseChunk {
    const chunkIndex=Math.floor(index/this.framesPerChunk);
    let chunk=this.chunks[chunkIndex];if(chunk)return chunk;
    const frames=Math.min(this.framesPerChunk,Math.floor(this.maxPoses/this.expected)-chunkIndex*this.framesPerChunk);
    if(frames<1)throw new Error('Trace frame bound exhausted');
    const samples=frames*this.expected;
    chunk={values:new Float64Array(samples*4),support:new Uint8Array(samples),tick:new Float64Array(frames),
      substep:new Uint8Array(frames),substeps:new Uint8Array(frames)};
    this.bytes+=chunk.values.byteLength+chunk.support.byteLength+chunk.tick.byteLength+chunk.substep.byteLength+chunk.substeps.byteLength;
    this.chunks.push(chunk);return chunk;
  }
  posePage(offset:number,limit:number):TracePose[]{
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1)throw new Error('Invalid trace page');
    const page:TracePose[]=[];
    for(let n=offset;n<Math.min(this.poseCount,offset+limit);n++){
      const frame=Math.floor(n/this.expected),slot=n%this.expected,chunk=this.chunks[Math.floor(frame/this.framesPerChunk)];
      const local=frame%this.framesPerChunk,sample=local*this.expected+slot,index=sample*4;
      page.push({tick:chunk.tick[local],substep:chunk.substep[local],substeps:chunk.substeps[local],slot,
        x:chunk.values[index],y:chunk.values[index+1],z:chunk.values[index+2],speed:chunk.values[index+3],support:this.supportValues[chunk.support[sample]]});
    }
    return page;
  }
  substep(tick:number,substep:number,substeps:number,poses:TracePose[]):void {
    if(this.sealed||!Number.isSafeInteger(tick)||tick<1||!Number.isInteger(substeps)||substeps<1||substeps>8||
       !Number.isInteger(substep)||substep<0||substep>=substeps||poses.length!==this.expected){this.invalid=true;return;}
    if(this.lastTick===null?substep!==0||this.startTick===null||tick!==this.startTick:tick===this.lastTick
      ?substep!==this.lastSubstep+1||substeps!==this.lastSubsteps
      :tick!==this.lastTick+1||substep!==0||this.lastSubstep!==this.lastSubsteps-1){this.invalid=true;return;}
    const slots=new Set<number>();
    for(const p of poses){
      if(p.tick!==tick||p.substep!==substep||p.substeps!==substeps||!Number.isInteger(p.slot)||p.slot<0||p.slot>=this.expected||slots.has(p.slot)||
         ![p.x,p.y,p.z,p.speed].every(Number.isFinite)||
         !(p.support===null||(typeof p.support==='string'&&p.support.length<=80))){this.invalid=true;return;}
      slots.add(p.slot);
    }
    this.lastTick=tick;this.lastSubstep=substep;this.lastSubsteps=substeps;
    if(this.overflow||this.poseCount+poses.length>this.maxPoses){this.overflow=true;return;}
    for(const p of poses)if(!this.supportCodes.has(p.support)){
      if(this.supportValues.length>=256){this.overflow=true;return;}
      this.supportCodes.set(p.support,this.supportValues.length);this.supportValues.push(p.support);
    }
    const chunk=this.chunk(this.frames),local=this.frames%this.framesPerChunk;
    chunk.tick[local]=tick;chunk.substep[local]=substep;chunk.substeps[local]=substeps;
    for(const p of poses){
      const sample=local*this.expected+p.slot,index=sample*4;
      chunk.values[index]=p.x;chunk.values[index+1]=p.y;chunk.values[index+2]=p.z;chunk.values[index+3]=p.speed;
      chunk.support[sample]=this.supportCodes.get(p.support)!;
    }
    this.frames++;
  }
  event(event:TraceEvent):void {
    if(this.sealed||!Number.isSafeInteger(event.tick)||event.tick<1||!Number.isInteger(event.substep)||event.substep<0||!Number.isInteger(event.slot)||
       event.slot<0||event.slot>=this.expected||!['entity','solid','progression','unsupported','other'].includes(event.kind)||
       (event.reason!==undefined&&(typeof event.reason!=='string'||event.reason.length>80))){this.invalid=true;return;}
    if(event.kind==='unsupported')this.unsupported=true;
    if(this.events.length>=this.maxEvents){this.overflow=true;return;}this.events.push(event);
  }
  seal(endTick:number):void{
    if(!Number.isSafeInteger(endTick)||this.lastTick!==endTick||this.lastSubstep!==this.lastSubsteps-1)this.invalid=true;
    this.sealed=true;
  }
  summary(){
    const reasons:string[]=[];
    if(!this.authoritativeCoverage)reasons.push('authoritative-substep-hooks-unverified');
    if(this.startTick===null)reasons.push('missing-trace-start-tick');
    if(!this.poseCount)reasons.push('missing-pose-trace');
    if(!this.sealed)reasons.push('trace-not-sealed');
    if(this.invalid)reasons.push('invalid-or-missing-substep-data');
    if(this.overflow)reasons.push('trace-overflow');
    if(this.unsupported)reasons.push('unsupported-simulation-path');
    if(this.events.some(event=>event.kind==='entity'||event.kind==='solid'||event.kind==='progression'||
      event.kind==='other'&&event.reason==='damage-or-impulse'))reasons.push('obstruction-or-impulse-observed');
    if(this.events.some(event=>event.kind==='other'&&event.reason!=='damage-or-impulse'))reasons.push('possible-obstruction');
    return {complete:reasons.length===0,reasons,poses:this.poseCount,events:this.events.length,packedBytes:this.bytes};
  }
}
