# Wire-clock recovery experiment — unshipped

The source base is candidate `020f25b40696608e7e7285fc74adf6f52c4c3d42`.
Copy either included lab test into `tests/` on that source and run it with
`pnpm exec tsx --test tests/<name>`. For the variants, replace only
`src/motion-clock.ts` with the named source file. The pinned trace test writes
its complete synthetic frames and receipts when `TRACE_PATH` is set; its
unchanged collision and snap assertions fail on every candidate here.

`motion-clock-rebase.ts` resets only the input clock on every newer accepted
snapshot; visual timing remains separate. In the physically scheduled pinned
case, 25 baseline inputs were rejected late, last at 2383 ms; the rebase had
16 late rejections, last at 1933 ms. The trajectories differ because their
inputs reach authority at different ticks. Neither side passes the contact
checks. The traces, test and logs are included.

The independent `wire-recovery.lab.test.ts` models an 80 ms upstream delay and
FIFO downstream snapshots, with releases and separate jump and flip presses.
For the 500 ms delay variant, last rejection was 2383 ms on base versus
1933 ms on the rebase. At a half-speed room, base processed both edges once;
the rebase expired both, so it is unsafe. A separate `motion-clock-ratecap.ts`
limits input lead using measured room rate and the 300 ms horizon: all four
selected scenarios processed their post-outage edges and preserved release,
but late rejections increased (for example 25 to 27 at 500 ms, and zero to
17 in the slow-room case), and the rate estimate is not proof of future room
progress. It is not a proposed release fix.

These are synthetic Session/ScheduledInput simulations, not Worker, browser,
WAN, physical-device or playable-capacity measurements. They do not measure
sustained latency under actual room load or establish any release gate.
