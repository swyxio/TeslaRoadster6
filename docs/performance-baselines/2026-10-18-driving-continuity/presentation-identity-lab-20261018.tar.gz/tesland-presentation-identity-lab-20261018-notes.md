# Per-entity presentation identity prototype — 2026-10-18

STATUS: HOLD. This is an isolated, uncommitted experiment containing the prior presentation-history prototype and three failing motion tests. It is not release-approved. The release checkout was not modified.

- Exact base: `d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31`
- Isolated lab: `/private/tmp/tesland-presentation-contact-lab-20261018`
- Complete patch: `/private/tmp/tesland-presentation-identity-lab-20261018.patch`
- Patch SHA-256: `abc44d7678850c16cace48a27c95fd7ea360247f6bd33a9376e81a6f6b506164`
- Patch validation: checked and applied to a fresh archive of the exact base; 22 files match the lab byte for byte.
- Unit log: `/private/tmp/tesland-identity-lab-final-20261018.log`
- Typecheck: `pnpm exec tsc --noEmit` passed. Relevant unit suite below: **177/180 pass, 3 fail**. This is not a performance result. No browser, live room integration, load test, benchmark or release gate was run.

Reproduce from the lab or from a clean copy of the exact base after applying the patch and installing dependencies:

```sh
pnpm exec tsx --test --test-concurrency=1 --test-reporter=spec tests/authoritative-relocation-lab.test.ts tests/market-hold.test.ts tests/remote-presentation.test.ts tests/snapshot.test.ts tests/no-spawn.test.ts tests/session.test.ts tests/tick-prediction.test.ts tests/session-motion.test.ts tests/motion-clock.test.ts tests/building-sweep-lab.test.ts
pnpm exec tsc --noEmit
```

The meaningful passing checks include the real 0.5 m authoritative sandbox teleport, same-string-ID vehicle reselection and reconnect without any absent snapshot, initial vs optimized snapshot serialization, unattended ferry and water recovery, market-hold recovery, failed/blocked movement, room-epoch scoped safe-integer overflow, invalid/missing/duplicate tokens, retained delayed-impact playback, future peer relocation near local prediction, stale observed peer input, cached peer collision replay, and local control/edge fences. An integration assertion is added to `tests/room.integration.ts` for initial and periodic snapshot identities, but has not been run against Wrangler.

## Design and limits

Protocol prototype v48 adds `presentationIncarnation` and `presentationRevision` to every entity and `nextPresentationIncarnation` to the world. Insertions receive a deterministic positive counter scoped to `roomEpoch`; revisions advance only on committed non-continuous placements, including unattended ferry/water moves and market hold recovery. Counters fail before wrapping. Both server snapshot serializers emit those fields. Client receipt validates token range and uniqueness, rejects malformed state, fences older remote presentation, local prediction and peer observations, and removes changed peers from cached/replayed physics. A changed peer that overlaps the local predicted pose or another shown peer is rejected in favor of one authoritative frame. The existing owner control, action, edge and camera fences remain separately authoritative.

The real short-teleport fixture now passes. This establishes that explicit identity can distinguish a short relocation from ordinary movement; it does not establish that mixed or swept multi-body trajectories are safe. The existing experimental contact code uses 2-D bodies and therefore does not model the authority's vertical overlap, dome contact or secured-ferry exclusion. Endpoint checks do not establish safety between frames. Scene hull smoothing and passenger presentation are still on separate timelines. No code in this prototype should be shipped on these results.

Failures in the complete suite:

1. `a peer pinned near a wall remains safe through a snapshot burst`: complete world holds seven consecutive frames while safe peer correction cannot be established.
2. `a pinned-wall jump remains responsive during a snapshot burst`: existing contact handling gets stuck in a long hold and exhausts history. The token-aware frozen-world fallback also exposes a **7.400251 m displayed cut** when a new ambient entity enters the full test world's roster at 5.0 s. The diagnostic trace is `/private/tmp/tesland-token-cut-debug.log`. This remains a release blocker; the new-entity check was not disabled.
3. `a ferry passenger keeps the deck frame while other cars interpolate`: a shore car does not follow its required buffered timeline.

The additional entity in the cut case was far away, but distance alone is not a sufficient proof that it is independent of retained replay: shared simulation uses whole-world adaptive substeps, global ambient pool/spawn decisions, ferry/passenger state, and interactions among moving peers. A sound exception would require a defined bounded hold interval, matching IDs and creation history, authoritative dependency provenance, swept 3-D motion bounds and checks for the current shared support/geometry; the present snapshot contract does not supply that proof. Its absence and the other safety issues prevent a release-ready implementation.

## Performance risk, unmeasured

The prior experiment retains up to 16 structured-cloned full-world snapshots. Token validation adds an entity set per received state; immediate peer fencing adds maps per state and per replay/render. Each entity receives two additional JSON properties (53 bytes for single-digit values, before compression or framing). No throughput, allocation, host timing or 64-player performance conclusion follows from this arithmetic; integrated quiet-host and hosted gate measurements are still required.
