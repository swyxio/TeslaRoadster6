// Diagnostic-only bounded streaming buffer. The consumer must durably persist
// every page before acknowledging a segment. Missing/slow consumers overflow;
// neither acknowledgements nor complete records prove contact coverage.
import {RawGroundTrace,type GroundAttempt,type GroundRecord,type GroundState} from './raw-ground-trace';

type Segment={sequence:number;startTick:number;endTick:number;raw:RawGroundTrace;nextOffset:number};
export class RawGroundSegments {
  private readonly ids=new Map<string,number>();
  private readonly queue:Segment[]=[];
  private active:Segment|null=null;private pending:Segment|null=null;
  private nextSequence=1;private nextTick:number;private lastTick:number|null=null;private lastAck=0;
  private totalRecords=0;private totalFrames=0;private partialRecords=0;private acknowledgedRecords=0;private sealed=false;
  invalid=false;overflow=false;
  readonly ticksPerSegment=16;readonly maxBodies=128;readonly maxQueued=4;
  readonly recordsPerSegment=this.ticksPerSegment*8*this.maxBodies;
  readonly framesPerSegment=this.ticksPerSegment*8;
  constructor(startTick:number){if(!Number.isSafeInteger(startTick)||startTick<1)throw new Error('Invalid starting tick');this.nextTick=startTick;}
  append(tick:number,substep:number,substeps:number,starts:GroundState[],attempts:GroundAttempt[],ends:GroundState[]):void{
    if(this.sealed){this.invalid=true;return;}
    if(this.invalid||this.overflow)return;
    if(!Array.isArray(starts)||!Array.isArray(attempts)||!Array.isArray(ends)){this.invalid=true;return;}
    if(starts.length>this.maxBodies||attempts.length>this.maxBodies||ends.length>this.maxBodies){this.overflow=true;return;}
    if(starts.some(s=>!s||typeof s!=='object')||ends.some(s=>!s||typeof s!=='object')||
      attempts.some(a=>!a||typeof a!=='object'||!a.state||typeof a.state!=='object'||!a.from||typeof a.from!=='object')){
      this.invalid=true;return;
    }
    const ids=new Set([...starts.map(s=>s.id),...attempts.map(a=>a.state.id),...ends.map(s=>s.id)]);
    if(ids.size>this.maxBodies||[...ids].some(id=>typeof id!=='string'||!id||id.length>128)){this.overflow=true;return;}
    const fresh=[...ids].filter(id=>!this.ids.has(id));
    if(this.ids.size+fresh.length>this.maxBodies){this.overflow=true;return;}
    if(!this.active){
      if(tick!==this.nextTick||substep!==0){this.invalid=true;return;}
      this.active={sequence:this.nextSequence++,startTick:tick,endTick:tick,raw:new RawGroundTrace(this.recordsPerSegment,this.framesPerSegment,tick,this.ids),nextOffset:0};
    }
    for(const id of fresh)this.ids.set(id,this.ids.size+1);
    const segment=this.active,before=segment.raw.summary();
    segment.raw.append(tick,substep,substeps,starts,attempts,ends);
    const after=segment.raw.summary();
    this.totalRecords+=after.records-before.records;this.totalFrames+=after.frames-before.frames;this.partialRecords+=after.partialRecords-before.partialRecords;
    if(after.invalid){this.invalid=true;return;}if(after.overflow){this.overflow=true;return;}
    segment.endTick=tick;this.lastTick=tick;
    if(tick-segment.startTick+1===this.ticksPerSegment&&substep===substeps-1)this.finishActive();
  }
  private finishActive():void{
    const segment=this.active;if(!segment){this.invalid=true;return;}
    segment.raw.seal(segment.endTick);if(segment.raw.summary().invalid)this.invalid=true;
    this.active=null;this.nextTick=segment.endTick+1;
    if(this.queue.length===this.maxQueued){this.pending=segment;this.overflow=true;return;}
    this.queue.push(segment);
  }
  seal(endTick:number):void{
    if(this.sealed||this.lastTick!==endTick){this.invalid=true;this.sealed=true;return;}
    if(this.active)this.finishActive();this.sealed=true;
  }
  head(){
    const segment=this.queue[0];if(!segment)return null;
    return {sequence:segment.sequence,startTick:segment.startTick,endTick:segment.endTick,summary:segment.raw.summary()};
  }
  page(sequence:number,offset:number,limit:number):GroundRecord[]{
    const segment=this.queue[0];
    if(!segment||sequence!==segment.sequence||!Number.isSafeInteger(offset)||offset<0||offset>segment.nextOffset||
       !Number.isInteger(limit)||limit<1||limit>1000)throw new Error('Invalid segment page');
    const page=segment.raw.page(offset,limit);if(offset===segment.nextOffset)segment.nextOffset+=page.length;
    return page;
  }
  acknowledge(sequence:number):boolean{
    if(!Number.isSafeInteger(sequence)||sequence<1)return false;
    if(sequence===this.lastAck)return true;
    const segment=this.queue[0];if(!segment||sequence!==segment.sequence||segment.nextOffset!==segment.raw.summary().records)return false;
    this.queue.shift();this.lastAck=sequence;this.acknowledgedRecords+=segment.raw.summary().records;
    if(this.pending){this.queue.push(this.pending);this.pending=null;}
    return true;
  }
  summary(){
    const buffers=[...this.queue,...(this.active?[this.active]:[]),...(this.pending?[this.pending]:[])];
    return {records:this.totalRecords,frames:this.totalFrames,partialRecords:this.partialRecords,acknowledgedRecords:this.acknowledgedRecords,
      bufferedSegments:buffers.length,packedBytes:buffers.reduce((n,s)=>n+s.raw.summary().packedBytes,0),invalid:this.invalid,overflow:this.overflow,
      collectionComplete:this.sealed&&!this.invalid&&!this.overflow&&this.partialRecords===0,
      exportComplete:this.sealed&&!this.invalid&&!this.overflow&&this.partialRecords===0&&this.acknowledgedRecords===this.totalRecords,
      coverageProven:false};
  }
}
