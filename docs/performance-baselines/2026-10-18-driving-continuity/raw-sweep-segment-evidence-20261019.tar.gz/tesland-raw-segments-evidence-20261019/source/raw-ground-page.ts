// Diagnostic-only lossless JSON encoding for a bounded page. JSON's normal
// number encoding round-trips every finite IEEE-754 double except negative
// zero; use an unambiguous marker for that one value. Do not call JSON.stringify
// directly on records. This decoder rejects malformed or unbounded pages.
import type {GroundRecord} from './raw-ground-trace';

const marker='$teslandFloat64';
export function serializeRawGroundPage(records:GroundRecord[]):string{
  if(records.length>1000)throw new Error('Oversized raw page');
  return JSON.stringify(records,(_key,value)=>typeof value==='number'&&Object.is(value,-0)?{[marker]:'-0'}:value);
}
export function parseRawGroundPage(encoded:string):GroundRecord[]{
  if(encoded.length>8*1024*1024)throw new Error('Oversized encoded raw page');
  const result:unknown=JSON.parse(encoded,(_key,value)=>{
    if(value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&value[marker]==='-0')return -0;
    return value;
  });
  const object=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
  const string=(v:unknown):boolean=>typeof v==='string'&&v.length>0&&v.length<=128;
  const support=(v:unknown):boolean=>v===null||string(v);
  const number=(v:unknown):boolean=>typeof v==='number'&&Number.isFinite(v);
  const integer=(v:unknown,min:number,max:number):boolean=>number(v)&&Number.isSafeInteger(v)&&Number(v)>=min&&Number(v)<=max;
  const state=(v:unknown):boolean=>v===null||object(v)&&string(v.kind)&&support(v.support)&&
    (v.slot===null||integer(v.slot,0,63))&&number(v.x)&&number(v.z)&&typeof v.inDome==='boolean'&&typeof v.loop==='boolean';
  const attempt=(v:unknown):boolean=>v===null||object(v)&&v.state!==null&&state(v.state)&&object(v.from)&&
    number(v.from.x)&&number(v.from.z)&&support(v.from.support);
  if(!Array.isArray(result)||result.length>1000||!result.every(row=>object(row)&&integer(row.tick,1,Number.MAX_SAFE_INTEGER)&&
    integer(row.substeps,1,8)&&integer(row.substep,0,Number(row.substeps)-1)&&integer(row.id,1,65535)&&
    state(row.start)&&attempt(row.attempt)&&state(row.end)))throw new Error('Invalid raw page');
  return result as GroundRecord[];
}
