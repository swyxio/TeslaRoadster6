// Anonymous, bounded substep input archive. It records what the diagnostic
// saw; collection completeness is not proof of complete contact coverage.
export type GroundState={id:string;kind:string;slot:number|null;x:number;z:number;support:string|null;inDome:boolean;loop:boolean};
export type GroundAttempt={state:GroundState;from:{x:number;z:number;support:string|null}};
type Row={start?:GroundState;attempt?:GroundAttempt;end?:GroundState};
type Chunk={values:Float64Array;metadata:Uint8Array;ids:Uint16Array;frames:Uint32Array};
type Frame={tick:number;substep:number;substeps:number};
export type GroundRecord=Frame&{id:number;start:Omit<GroundState,'id'>|null;attempt:{from:GroundAttempt['from'];state:Omit<GroundState,'id'>}|null;end:Omit<GroundState,'id'>|null};

export class RawGroundTrace {
  private readonly chunks:Chunk[]=[];
  private readonly perChunk=1024;
  private readonly frames:Frame[]=[];
  private readonly ids:Map<string,number>;
  private readonly kinds=new Map<string,number>();
  private readonly kindValues:string[]=[];
  private readonly supports=new Map<string|null,number>([[null,0]]);
  private readonly supportValues:(string|null)[]=[null];
  private count=0;private bytes=0;private partial=0;private sealed=false;
  overflow=false;invalid=false;
  constructor(readonly maxRecords:number,readonly maxFrames:number,readonly startTick:number,ids?:Map<string,number>){
    if(!Number.isSafeInteger(maxRecords)||maxRecords<1||!Number.isSafeInteger(maxFrames)||maxFrames<1||maxFrames>0xffffffff||
      !Number.isSafeInteger(startTick)||startTick<1)throw new Error('Invalid raw trace bounds');
    this.ids=ids??new Map();
  }
  private chunk(index:number):Chunk{
    const n=Math.floor(index/this.perChunk);let chunk=this.chunks[n];if(chunk)return chunk;
    const capacity=Math.min(this.perChunk,this.maxRecords-n*this.perChunk);
    chunk={values:new Float64Array(capacity*8),metadata:new Uint8Array(capacity*13),ids:new Uint16Array(capacity),frames:new Uint32Array(capacity)};
    this.bytes+=chunk.values.byteLength+chunk.metadata.byteLength+chunk.ids.byteLength+chunk.frames.byteLength;
    this.chunks.push(chunk);return chunk;
  }
  append(tick:number,substep:number,substeps:number,starts:GroundState[],attempts:GroundAttempt[],ends:GroundState[]):void{
    if(this.sealed){this.invalid=true;return;}
    if(this.invalid||this.overflow)return;
    const previous=this.frames[this.frames.length-1];
    if(!Number.isSafeInteger(tick)||tick<1||!Number.isInteger(substeps)||substeps<1||substeps>8||
      !Number.isInteger(substep)||substep<0||substep>=substeps||
      (previous?tick===previous.tick?substep!==previous.substep+1||substeps!==previous.substeps:
        tick!==previous.tick+1||substep!==0||previous.substep!==previous.substeps-1:tick!==this.startTick||substep!==0)){
      this.invalid=true;return;
    }
    const rows=new Map<string,Row>();
    const validString=(s:unknown)=>typeof s==='string'&&s.length>0&&s.length<=128;
    const validSupport=(s:unknown)=>s===null||validString(s);
    const valid=(s:GroundState)=>!!s&&typeof s==='object'&&validString(s.id)&&validString(s.kind)&&validSupport(s.support)&&
      Number.isFinite(s.x)&&Number.isFinite(s.z)&&(s.slot===null||Number.isInteger(s.slot)&&!Object.is(s.slot,-0)&&s.slot>=0&&s.slot<64)&&
      typeof s.inDome==='boolean'&&typeof s.loop==='boolean';
    const put=(state:GroundState,part:'start'|'end')=>{
      if(!valid(state))return false;const row=rows.get(state.id)??{};if(row[part])return false;
      row[part]=state;rows.set(state.id,row);return true;
    };
    if(!Array.isArray(starts)||!Array.isArray(attempts)||!Array.isArray(ends)){this.invalid=true;return;}
    for(const s of starts)if(!put(s,'start')){this.invalid=true;return;}
    for(const attempt of attempts){
      if(!attempt||typeof attempt!=='object'||!attempt.from||typeof attempt.from!=='object'||!valid(attempt.state)||!Number.isFinite(attempt.from.x)||!Number.isFinite(attempt.from.z)||!validSupport(attempt.from.support)){this.invalid=true;return;}
      const row=rows.get(attempt.state.id)??{};if(row.attempt){this.invalid=true;return;}row.attempt=attempt;rows.set(attempt.state.id,row);
    }
    for(const s of ends)if(!put(s,'end')){this.invalid=true;return;}
    if(!rows.size){this.invalid=true;return;}
    if(rows.size>256||this.frames.length>=this.maxFrames||this.count+rows.size>this.maxRecords){this.overflow=true;return;}
    const ids=new Set<string>(),kinds=new Set<string>(),supports=new Set<string|null>();
    for(const [id,row] of rows){ids.add(id);for(const s of [row.start,row.attempt?.state,row.end])if(s){kinds.add(s.kind);supports.add(s.support);}if(row.attempt)supports.add(row.attempt.from.support);}
    if(this.ids.size+[...ids].filter(id=>!this.ids.has(id)).length>65535||
      this.kinds.size+[...kinds].filter(kind=>!this.kinds.has(kind)).length>256||
      this.supports.size+[...supports].filter(support=>!this.supports.has(support)).length>256){this.overflow=true;return;}
    for(const id of ids)if(!this.ids.has(id))this.ids.set(id,this.ids.size+1);
    for(const kind of kinds)if(!this.kinds.has(kind)){this.kinds.set(kind,this.kindValues.length);this.kindValues.push(kind);}
    for(const support of supports)if(!this.supports.has(support)){this.supports.set(support,this.supportValues.length);this.supportValues.push(support);}
    const frame=this.frames.length;this.frames.push({tick,substep,substeps});
    for(const [id,row] of rows){
      const chunk=this.chunk(this.count),local=this.count%this.perChunk,v=local*8,m=local*13;
      chunk.ids[local]=this.ids.get(id)!;chunk.frames[local]=frame;
      const write=(state:GroundState|undefined,where:number,value:number)=>{
        if(!state)return;chunk.values[v+value]=state.x;chunk.values[v+value+1]=state.z;
        chunk.metadata[m+where]=this.kinds.get(state.kind)!;chunk.metadata[m+where+1]=this.supports.get(state.support)!;
        chunk.metadata[m+where+2]=state.slot===null?0:state.slot+1;
        chunk.metadata[m+where+3]=1|(state.inDome?2:0)|(state.loop?4:0);
      };
      write(row.start,0,0);write(row.attempt?.state,4,4);write(row.end,8,6);
      if(row.attempt){chunk.values[v+2]=row.attempt.from.x;chunk.values[v+3]=row.attempt.from.z;chunk.metadata[m+12]=this.supports.get(row.attempt.from.support)!;}
      if(!row.start||!row.attempt||!row.end)this.partial++;
      this.count++;
    }
  }
  seal(tick:number):void{
    const last=this.frames[this.frames.length-1];
    if(this.sealed||!last||last.tick!==tick||last.substep!==last.substeps-1)this.invalid=true;
    this.sealed=true;
  }
  summary(){return {records:this.count,frames:this.frames.length,partialRecords:this.partial,packedBytes:this.bytes,
    collectionComplete:this.sealed&&!this.invalid&&!this.overflow&&this.partial===0,invalid:this.invalid,overflow:this.overflow,coverageProven:false};}
  page(offset:number,limit:number):GroundRecord[]{
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1)throw new Error('Invalid raw trace page');
    const result:GroundRecord[]=[];
    for(let i=offset;i<Math.min(this.count,offset+limit);i++){
      const chunk=this.chunks[Math.floor(i/this.perChunk)],local=i%this.perChunk,v=local*8,m=local*13;
      const read=(where:number,value:number):Omit<GroundState,'id'>|null=>{
        const flags=chunk.metadata[m+where+3];if(!(flags&1))return null;
        return {kind:this.kindValues[chunk.metadata[m+where]],support:this.supportValues[chunk.metadata[m+where+1]],
          slot:chunk.metadata[m+where+2]===0?null:chunk.metadata[m+where+2]-1,x:chunk.values[v+value],z:chunk.values[v+value+1],inDome:!!(flags&2),loop:!!(flags&4)};
      };
      const start=read(0,0),state=read(4,4),end=read(8,6);
      const attempt=state?{state,from:{x:chunk.values[v+2],z:chunk.values[v+3],support:this.supportValues[chunk.metadata[m+12]]}}:null;
      result.push({...this.frames[chunk.frames[local]],id:chunk.ids[local],start,attempt,end});
    }
    return result;
  }
}
