import {test} from 'node:test';
import assert from 'node:assert/strict';
import {RawGroundSegments} from './raw-ground-segments';
import type {GroundState} from './raw-ground-trace';

const body=(i:number):GroundState=>({id:`private-${i}`,kind:'roadster',slot:i<64?i:null,x:i*12,z:4100,support:'ground',inDome:false,loop:false});
const attempts=(bodies:GroundState[],tick:number,substep:number)=>bodies.map(s=>({from:{x:s.x+.125,z:s.z-.25,support:s.support},
  state:{...s,x:s.x+tick/7,z:s.z-substep-1,inDome:s.id==='private-127',loop:s.id==='private-126'}}));
const appendTick=(trace:RawGroundSegments,tick:number,bodies:GroundState[],substeps=1)=>{
  for(let substep=0;substep<substeps;substep++){
    const move=attempts(bodies,tick,substep);
    // These intentionally disagree with both the start and attempted endpoint,
    // as they can after support correction or contact separation.
    const ends=move.map((m,i)=>({...m.state,x:m.state.x-i/17,z:m.state.z+.5}));
    trace.append(tick,substep,substeps,bodies,move,ends);
  }
};
const drain=(trace:RawGroundSegments)=>{
  const head=trace.head();assert.ok(head);const rows=[];
  for(let offset=0;offset<head.summary.records;offset+=1000)rows.push(...trace.page(head.sequence,offset,1000));
  assert.equal(rows.length,head.summary.records);assert.equal(trace.acknowledge(head.sequence),true);return {head,rows};
};

test('adversarial motion roundtrips across page and segment boundaries with stable opaque ids',()=>{
  const trace=new RawGroundSegments(1),bodies=Array.from({length:128},(_,i)=>body(i));
  for(let tick=1;tick<=16;tick++)appendTick(trace,tick,bodies,8);
  const first=trace.head()!;assert.equal(first.summary.records,16_384);
  assert.equal(trace.acknowledge(first.sequence),false);assert.throws(()=>trace.page(first.sequence,1,1000));
  const firstPage=trace.page(first.sequence,0,1000);assert.deepEqual(trace.page(first.sequence,0,1000),firstPage);
  assert.equal(firstPage[0].id,1);assert.equal(firstPage[0].start!.x,0);assert.equal(firstPage[0].attempt!.from.x,.125);
  assert.equal(firstPage[0].attempt!.state.x,1/7);assert.equal(firstPage[0].end!.z,4099.5);
  assert.equal(JSON.stringify(firstPage).includes('private-'),false);
  for(let offset=1000;offset<first.summary.records;offset+=1000)trace.page(first.sequence,offset,1000);
  assert.equal(trace.acknowledge(first.sequence),true);assert.equal(trace.acknowledge(first.sequence),true);
  for(let tick=17;tick<=32;tick++)appendTick(trace,tick,[...bodies].reverse(),8);
  const second=trace.head()!,rows=trace.page(second.sequence,0,1000);
  assert.equal(rows[0].id,128);assert.equal(rows[127].id,1);assert.equal(rows[0].attempt!.state.inDome,true);
  assert.equal(rows[1].attempt!.state.loop,true);assert.ok(trace.summary().packedBytes<=6_799_360);
});

test('slow collectors, missing rows, and unsupported body counts fail closed without overwriting',()=>{
  const trace=new RawGroundSegments(1),bodies=[body(0)];
  for(let tick=1;tick<=80;tick++)appendTick(trace,tick,bodies);
  assert.equal(trace.summary().overflow,true);assert.equal(trace.summary().bufferedSegments,5);
  assert.equal(trace.head()!.sequence,1);
  assert.deepEqual([drain(trace).head.sequence,drain(trace).head.sequence,drain(trace).head.sequence,drain(trace).head.sequence,drain(trace).head.sequence],[1,2,3,4,5]);
  trace.seal(80);assert.equal(trace.summary().collectionComplete,false);assert.equal(trace.summary().exportComplete,false);
  const many=new RawGroundSegments(1),tooMany=Array.from({length:129},(_,i)=>body(i));appendTick(many,1,tooMany);
  assert.equal(many.summary().overflow,true);assert.equal(many.summary().records,0);
  const partial=new RawGroundSegments(1),one=body(0);partial.append(1,0,1,[one],[],[one]);partial.seal(1);
  assert.equal(partial.summary().partialRecords,1);assert.equal(partial.summary().collectionComplete,false);
  const row=drain(partial).rows[0];assert.equal(row.attempt,null);assert.equal(partial.summary().exportComplete,false);
});

test('substep gaps, malformed samples, late acknowledgements and identity churn remain incomplete',()=>{
  const one=body(0),gap=new RawGroundSegments(1);gap.append(1,0,2,[one],attempts([one],1,0),[one]);gap.append(2,0,1,[one],attempts([one],2,0),[one]);
  assert.equal(gap.summary().invalid,true);
  const malformed=new RawGroundSegments(1);malformed.append(1,0,1,[{...one,x:NaN}],[],[one]);assert.equal(malformed.summary().invalid,true);
  const structural=new RawGroundSegments(1);
  assert.doesNotThrow(()=>structural.append(1,0,1,[one],[null as never],[one]));assert.equal(structural.summary().invalid,true);
  const missingFrom=new RawGroundSegments(1);
  assert.doesNotThrow(()=>missingFrom.append(1,0,1,[one],[{state:one,from:null} as never],[one]));assert.equal(missingFrom.summary().invalid,true);
  const missingArray=new RawGroundSegments(1);
  assert.doesNotThrow(()=>missingArray.append(1,0,1,null as never,[],[one]));assert.equal(missingArray.summary().invalid,true);
  const churn=new RawGroundSegments(1);appendTick(churn,1,Array.from({length:128},(_,i)=>body(i)));
  appendTick(churn,2,[body(128)]);assert.equal(churn.summary().overflow,true);
  const ordered=new RawGroundSegments(1);for(let tick=1;tick<=32;tick++)appendTick(ordered,tick,[one]);
  assert.equal(ordered.acknowledge(2),false);drain(ordered);assert.equal(ordered.acknowledge(2),false);drain(ordered);
  assert.equal(ordered.acknowledge(1),false);assert.equal(ordered.acknowledge(2),true);
});

test('wire pages retain negative zero and extreme finite float64 values',async()=>{
  const {serializeRawGroundPage,parseRawGroundPage}=await import('./raw-ground-page');
  const trace=new RawGroundSegments(1),one=body(0);
  const start={...one,x:-0,z:Number.MIN_VALUE};
  const attempt={from:{x:Number.MAX_VALUE,z:-0,support:'ground'},state:{...one,x:-Number.MAX_VALUE,z:-Number.MIN_VALUE}};
  const end={...one,x:-0,z:Number.MAX_VALUE};
  trace.append(1,0,1,[start],[attempt],[end]);trace.seal(1);
  const original=trace.page(1,0,1000),encoded=serializeRawGroundPage(original),decoded=parseRawGroundPage(encoded);
  assert.deepEqual(decoded,original);assert.ok(Object.is(decoded[0].start!.x,-0));assert.ok(Object.is(decoded[0].attempt!.from.z,-0));
  assert.throws(()=>parseRawGroundPage('[{"tick":1}]'));
  assert.throws(()=>parseRawGroundPage(JSON.stringify(Array(1001).fill(decoded[0]))));
  assert.throws(()=>parseRawGroundPage(' '.repeat(8*1024*1024+1)));
  const invalidSlot=new RawGroundSegments(1);invalidSlot.append(1,0,1,[{...one,slot:-0}],[],[one]);
  assert.equal(invalidSlot.summary().invalid,true);
});

test('64 simulated seconds with 128 bodies roundtrip all records through bounded streaming pages',async()=>{
  const {serializeRawGroundPage,parseRawGroundPage}=await import('./raw-ground-page');
  const trace=new RawGroundSegments(1);
  const bodies=Array.from({length:128},(_,i)=>({...body(i),support:i%2?'ground':'ferry'}));
  let records=0,peakBytes=0,expectedSequence=1;
  const receive=()=>{
    const head=trace.head();assert.ok(head);assert.equal(head.sequence,expectedSequence++);
    let index=0;
    for(let offset=0;offset<head.summary.records;offset+=1000){
      const rows=parseRawGroundPage(serializeRawGroundPage(trace.page(head.sequence,offset,1000)));
      for(const r of rows){
        const tick=head.startTick+Math.floor(index/(8*128));
        const substep=Math.floor(index/128)%8,i=index%128,b=bodies[i];
        const start=r.start,from=r.attempt?.from,attempt=r.attempt?.state,end=r.end;
        if(r.tick!==tick||r.substeps!==8||r.substep!==substep||r.id!==i+1||!start||!from||!attempt||!end||
          start.kind!==b.kind||start.slot!==b.slot||start.support!==b.support||start.x!==b.x||start.z!==b.z||start.inDome||start.loop||
          from.x!==b.x+.125||from.z!==b.z-.25||from.support!==b.support||
          attempt.kind!==b.kind||attempt.slot!==b.slot||attempt.support!==b.support||attempt.x!==b.x+tick/7||attempt.z!==b.z-substep-1||
          attempt.inDome!==(i===127)||attempt.loop!==(i===126)||
          end.kind!==b.kind||end.slot!==b.slot||end.support!==b.support||end.x!==b.x+tick/7-i/17||end.z!==b.z-substep-.5||
          end.inDome!==(i===127)||end.loop!==(i===126))throw new Error(`Roundtrip mismatch at record ${records+index}`);
        index++;
      }
    }
    assert.equal(index,head.summary.records);records+=index;
    // This is a mock consumer, not proof that external export is durable.
    assert.equal(trace.acknowledge(head.sequence),true);
  };
  for(let tick=1;tick<=1280;tick++){
    for(let substep=0;substep<8;substep++){
      if(tick%16===0&&substep===7&&trace.summary().bufferedSegments===5)receive();
      const move=attempts(bodies,tick,substep),ends=move.map((m,i)=>({...m.state,x:m.state.x-i/17,z:m.state.z+.5}));
      trace.append(tick,substep,8,bodies,move,ends);
      if(tick%16===0&&substep===6)peakBytes=Math.max(peakBytes,trace.summary().packedBytes);
    }
  }
  trace.seal(1280);while(trace.head())receive();
  const summary=trace.summary();assert.equal(records,1280*8*128);assert.equal(expectedSequence,81);
  assert.equal(summary.records,records);assert.equal(summary.frames,1280*8);
  assert.equal(summary.collectionComplete,true);assert.equal(summary.exportComplete,true);assert.equal(summary.coverageProven,false);
  assert.equal(peakBytes,6_799_360);assert.equal(summary.packedBytes,0);
});
