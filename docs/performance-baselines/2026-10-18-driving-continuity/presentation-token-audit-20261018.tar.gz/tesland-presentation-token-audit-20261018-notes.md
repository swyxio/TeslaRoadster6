# Presentation token, ferry and contact audit — 2026-10-18

STATUS: HOLD. This is an experimental lab patch containing known failing tests and debug traces. It does not implement the authoritative token and is not a production change.

- Base: d05d6f4ce8b31010f42d32e46fbc8cf49d8d1d31
- Patch: /private/tmp/tesland-presentation-token-audit-20261018.patch
- SHA-256: 5cb4594ef536fbf2d93026b8ba19777c715760c297253c008e30ed23316db035
- Lab: /private/tmp/tesland-presentation-contact-lab-20261018
- Log: /private/tmp/tesland-presentation-contact-lab-suite-token-audit.log
- The patch was checked and applied to a fresh archive of the exact base; all 12 changed files match the lab byte-for-byte.
- Full relevant suite: 148/152 passed. Failing: short real sandbox teleport fence, seven-frame pinned-wall hold, jump falsely reports exhausted history, ferry shore interpolation. `pnpm exec tsc --noEmit` passed. The separate unattended-ferry relocation case passed and demonstrates an authority event that the existing driver callback cannot describe. No browser, live network, load or capacity gates were run.

Reproduce in the lab or after applying the patch to a clean copy of the base and installing the project dependencies:

```
pnpm exec tsx --test --test-concurrency=1 --test-reporter=spec tests/session.test.ts tests/audio.test.ts tests/motion-clock.test.ts tests/tick-prediction.test.ts tests/session-motion.test.ts tests/remote-presentation.test.ts tests/building-sweep-lab.test.ts
pnpm exec tsx --test tests/authoritative-relocation-lab.test.ts
pnpm exec tsc --noEmit
```

The short teleport test uses the real shared `teleportPlayer`, succeeds from x=-299.5 to x=-299, then receives a new snapshot; rendering the older interval still shows x=-299.75. Velocity/distance plausibility cannot establish that a short displacement is continuous, so the lab's lineage heuristic is not adequate.

The forced-ferry test uses an actual arriving car and driver who exits to a pedestrian. The server moves both car and pedestrian to the apron; its `onRelocation(playerId)` callback reports only `p`. A token derived only from the owner's top-level `poseRevision` consequently misses the unattended car and cannot be used as a peer contract.

Minimum wire semantics: in each entity snapshot include a server-issued incarnation unique within the room epoch and a revision for that incarnation's pose discontinuities. Allocate a new incarnation whenever an entity object is spawned or an ID is reused, even if the old object disappeared and the replacement appeared between broadcasts. Increment the pose revision on every committed forced relocation, including accepted sandbox teleport, reset, dome travel, race/minigame placement, water recovery, ferry-apron moves for driven AND unattended entities, and market-hold recovery. Failed actions must not advance it. Ordinary continuously simulated contact or health changes must not be mistaken for a relocation. The room epoch scopes resets/restarts; entity metadata and pose must be sent atomically in both the initial `snapshotFor` and optimized `prepareSnapshots` paths, with the protocol version and shared contract updated.

One candidate implementation to investigate is a room-scoped monotonically allocated object-identity token plus a deterministic per-entity relocation revision updated at authoritative simulation mutation sites. It needs a complete audit of creation/relocation paths, market remove-and-restore semantics, overflow/reset, failure/rollback, and tests that the initial and optimized serialized projections agree. Validate tokens at the client. On token change, immediately fence that entity's older presentation history; a client must also break its local observed segment after an entity is absent from an interest-filtered snapshot, even if its authoritative incarnation did not change. Preserve local action/control/edge fences and the separate camera semantics. An explicit token by itself does not guarantee a safe joint scene when a peer relocates next to an older locally predicted pose.

The current peer separator tests 2-D horizontal bodies. The authority first excludes secured ferry passengers; uses `domeContact` for in-dome pairs when either body is dome-supported; and otherwise checks vertical bounds before 2-D OBB contact. Dome contact returns either a surface-arc normal or a 3-D world normal, which cannot be passed to the ground x/z separator. Exposing the existing instantaneous authoritative predicate is possible, but it does not prove the relative swept paths between two clear endpoints. Safe reconciliation needs joint simultaneous poses and conservative swept checks, static geometry, rotations, transitions, bounded corrections and responsive local inputs. Reject/hold only when proof is unavailable, and then prove the hold meets the release gate.

Ferry is a separate temporal contract. The lab mixes the latest authoritative local deck/passengers with delayed shore peers on boarding; src/scene.ts also interpolates the hull and translates/smooths ferry cars independently. A safe implementation must keep hull, deck passengers and nearby shore entities on a compatible shared frame at both docks and throughout arrival/departure, then verify actual rendered geometry; the existing Session-only ferry test does not cover seam contact. Dome playback must project positions from the surface arc rather than linearly interpolating y/z or overlooking domeS; blanket-removing the existing dome-path rejection would be unsafe.

These cross-cutting protocol, simulation, collision and renderer requirements exceed a bounded safe correction. Existing lab tests were kept; no release checkout was changed. Prior cost probe remains in /private/tmp/tesland-presentation-contact-lab-20261018-notes.md and is not a performance-gate result.
