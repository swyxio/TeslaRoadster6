import test from 'node:test';
import assert from 'node:assert/strict';
import { addPlayer, createEmptyWorld, makeEntity, NEUTRAL, PROTOCOL_VERSION, step } from '../shared/game';
import { registerEntity } from '../shared/presentation-identity';
import { ScheduledInput } from '../shared/tick-input';
import { Session } from '../src/session';

class Socket {
  static OPEN=1;static last:Socket;readyState=Socket.OPEN;sent:string[]=[];
  onmessage?: (event:{data:string})=>void;onclose?: (event:{code:number})=>void;
  constructor(_url:string){Socket.last=this;}
  send(value:string){this.sent.push(value);}
  close(){this.readyState=3;}
  message(value:unknown){this.onmessage?.({data:JSON.stringify(value)});}
}
Object.assign(globalThis,{WebSocket:Socket,window:globalThis,location:{protocol:'https:',host:'example.com'}});

function exhaustedBurst(addLateEntity:boolean){
  let now=0;
  const session=new Session(()=>now);session.join('bay','Driver');const socket=Socket.last;
  socket.message({type:'welcome',id:'p',version:PROTOCOL_VERSION,capacity:64,roomEpoch:'room',tick:0,poseRevision:0});
  const world=createEmptyWorld(),player=addPlayer(world,'p','Player');
  const car=world.entities.find(entity=>entity.id===player.entityId)!;world.entities=[car];world.pickups=[];
  Object.assign(car,{x:-300,z:-2050,y:0,yaw:-Math.PI/2,speed:50,vx:50,vz:0,supportId:'ground'});
  const input={...NEUTRAL,throttle:1},control=new ScheduledInput(input).snapshot();control.heldUntilTick=10000;
  const packet=(tick:number)=>({type:'state',world:structuredClone(world),roomEpoch:'room',tick,control:structuredClone(control),poseRevision:0,substeps:1});
  socket.message(packet(0));session.tick(1/120,input);
  const prior=session.renderWorld().entities.find(entity=>entity.driver==='p')!;
  now=1800;
  for(let tick=1;tick<=36;tick++){
    step(world,new Map([['p',input]]),.05,{substeps:1});
    if(tick===36&&addLateEntity)world.entities.push(registerEntity(world,makeEntity('new-ambient','model-3',-525,4944)));
    if(tick%2===0)socket.message(packet(tick));
  }
  const shown=session.renderWorld().entities.find(entity=>entity.driver==='p')!;
  const stepSize=Math.hypot(shown.x-prior.x,shown.y-prior.y,shown.z-prior.z);
  const result={stepSize,exhausted:session.presentationHistoryExhausted,error:session.error,closed:socket.readyState!==Socket.OPEN};
  session.disconnect();return result;
}

test('exhausted history with an unchanged roster holds the last visual world',()=>{
  const result=exhaustedBurst(false);
  assert.equal(result.exhausted,true);assert.equal(result.closed,true);
  assert.ok(result.stepSize<1,`displayed step ${result.stepSize} m`);
});

test('an added entity cannot make exhausted history cut the local visual world',()=>{
  const result=exhaustedBurst(true);
  assert.equal(result.exhausted,true);assert.equal(result.closed,true);
  assert.ok(result.stepSize<1,`displayed step ${result.stepSize} m`);
});
